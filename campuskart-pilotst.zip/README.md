# CampusKart — Full-Stack Student Commerce Platform

## Architecture
- `backend/schema_sqlite.sql` — Relational SQLite schema (integer paise precision, foreign keys, check constraints).
- `backend/schema_postgres_supabase.sql` — Production PostgreSQL / Supabase schema with Row Level Security (RLS).
- `backend/server.py` — ACID-compliant HTTP REST API server using `sqlite3` (`BEGIN IMMEDIATE` transactions, PBKDF2-HMAC credential hashing, HMAC-SHA256 session tokens, idempotency keys).
- `backend/test_backend.py` — Automated integration test suite.
- `frontend/src/types/campuskart.ts` — Strict TypeScript domain models.
- `frontend/src/services/api.ts` — Typed API service client.

## Running Locally
1. Start the database-backed API server:
   ```bash
   cd backend
   python3 server.py
   ```
2. Run the automated integration test suite:
   ```bash
   cd backend
   python3 test_backend.py
   ```
3. Configure `VITE_API_URL=http://127.0.0.1:8080` in your React/Vite environment and run your frontend dev server.
