import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  ShoppingBag, Wallet, ShieldCheck, Building2, UserCheck, Lock, KeyRound,
  Bell, Search, Filter, Plus, Minus, Trash2, ArrowRight, ArrowLeft, CheckCircle2,
  XCircle, Clock, Package, Truck, RefreshCw, AlertTriangle, TrendingUp,
  PieChart as PieChartIcon, BarChart3, Sliders, FileText, Download, Printer,
  LogOut, HelpCircle, Sparkles, ChevronRight, Eye, EyeOff, CreditCard,
  Smartphone, Landmark, Check, Info, Layers, Users, Box, Activity,
  Edit3, PlusCircle, Power, DollarSign, Award, Zap, Heart, Star,
  Calendar, MapPin, Shield, Terminal, BookOpen, Coffee, Utensils, Droplets, Watch
} from 'lucide-react';
import {
  PieChart, Pie, Cell, BarChart, Bar, LineChart, Line, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, Legend, AreaChart, Area
} from 'recharts';

// ============================================================================
// SHADER BACKGROUND COMPONENT (Interactive WebGL / Canvas2D Mesh Shader)
// ============================================================================
function ShaderBackground({ theme = 'student' }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animId;
    let t = 0;

    // Luminous Million-Dollar Tech Palette: Vibrant Orange, Electric Blue, Aqua Cyan, Warm Espresso Coffee
    const palettes = {
      student: [
        { r: 255, g: 107, b: 44, a: 0.22 },  // Vibrant CampusKart Orange (#FF6B2C)
        { r: 14, g: 165, b: 233, a: 0.18 },  // Electric Sky Blue (#0EA5E9)
        { r: 6, g: 182, b: 212, a: 0.16 },   // Fluid Aqua Cyan (#06B6D4)
        { r: 139, g: 90, b: 60, a: 0.12 }    // Warm Roasted Coffee (#8B5A3C)
      ],
      parent: [
        { r: 2, g: 132, b: 199, a: 0.20 },   // FinTech Royal Blue (#0284C7)
        { r: 6, g: 182, b: 212, a: 0.20 },   // Aqua Glass (#06B6D4)
        { r: 249, g: 115, b: 22, a: 0.16 },  // Warm Orange Accent (#F97316)
        { r: 111, g: 78, b: 55, a: 0.12 }    // Coffee Roast (#6F4E37)
      ],
      ops: [
        { r: 234, g: 88, b: 12, a: 0.22 },   // Operations Tangerine (#EA580C)
        { r: 111, g: 78, b: 55, a: 0.18 },   // Espresso Coffee (#6F4E37)
        { r: 14, g: 165, b: 233, a: 0.16 },  // Electric Blue (#0EA5E9)
        { r: 245, g: 158, b: 11, a: 0.15 }   // Warm Amber (#F59E0B)
      ],
      college: [
        { r: 3, g: 105, b: 161, a: 0.20 },   // Institutional Deep Blue (#0369A1)
        { r: 249, g: 115, b: 22, a: 0.18 },  // Warm Orange (#F97316)
        { r: 6, g: 182, b: 212, a: 0.16 },   // Aqua (#06B6D4)
        { r: 120, g: 82, b: 56, a: 0.14 }    // Coffee Bronze (#785238)
      ]
    };

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const render = () => {
      t += 0.005;
      const w = canvas.width;
      const h = canvas.height;
      // Warm Alabaster / Porcelain White base
      ctx.fillStyle = '#FAF7F2';
      ctx.fillRect(0, 0, w, h);

      const cols = palettes[theme] || palettes.student;
      cols.forEach((c, idx) => {
        const x = w * (0.5 + 0.36 * Math.sin(t * (0.75 + idx * 0.18) + idx * 1.6));
        const y = h * (0.5 + 0.34 * Math.cos(t * (0.65 + idx * 0.14) + idx * 2.1));
        const radius = Math.max(w, h) * (0.46 + 0.08 * Math.sin(t + idx));

        const grad = ctx.createRadialGradient(x, y, 12, x, y, radius);
        grad.addColorStop(0, `rgba(${c.r}, ${c.g}, ${c.b}, ${c.a})`);
        grad.addColorStop(0.55, `rgba(${c.r}, ${c.g}, ${c.b}, ${c.a * 0.35})`);
        grad.addColorStop(1, 'rgba(250, 247, 242, 0)');

        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);
      });

      animId = requestAnimationFrame(render);
    };

    render();
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, [theme]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ opacity: 1 }}
    />
  );
}

// ============================================================================
// CUSTOM SVG PRODUCT ARTWORK GENERATOR
// ============================================================================
function ProductArtwork({ category, id, className = "w-full h-36" }) {
  const configs = {
    'Food and Snacks': {
      grad: 'from-orange-100/90 via-amber-50/80 to-white',
      border: 'border-orange-300/70',
      accent: '#EA580C',
      icon: Utensils
    },
    'Beverages': {
      grad: 'from-cyan-100/85 via-sky-50/80 to-white',
      border: 'border-cyan-300/70',
      accent: '#0284C7',
      icon: Coffee
    },
    'Personal Care': {
      grad: 'from-sky-100/80 via-cyan-50/75 to-white',
      border: 'border-sky-300/70',
      accent: '#0891B2',
      icon: Droplets
    },
    'Daily Essentials': {
      grad: 'from-stone-200/80 via-orange-50/60 to-white',
      border: 'border-stone-300/80',
      accent: '#6F4E37',
      icon: Box
    },
    'Academic Supplies': {
      grad: 'from-blue-100/80 via-cyan-50/70 to-white',
      border: 'border-blue-300/70',
      accent: '#2563EB',
      icon: BookOpen
    },
    'Other Services': {
      grad: 'from-amber-100/85 via-orange-50/70 to-white',
      border: 'border-amber-300/70',
      accent: '#D97706',
      icon: Sparkles
    }
  };
  const cfg = configs[category] || configs['Daily Essentials'];
  const IconComp = cfg.icon;

  return (
    <div className={`relative overflow-hidden rounded-2xl bg-gradient-to-br ${cfg.grad} border ${cfg.border} shadow-inner flex items-center justify-center transition-transform duration-300 group-hover:scale-[1.02] ${className}`}>
      <div className="absolute -right-6 -top-6 w-24 h-24 rounded-full blur-2xl opacity-30" style={{ background: cfg.accent }} />
      <div className="absolute -left-6 -bottom-6 w-24 h-24 rounded-full blur-2xl opacity-25" style={{ background: cfg.accent }} />
      <div className="relative z-10 flex flex-col items-center">
        <div className="p-3.5 rounded-2xl bg-white/95 backdrop-blur-md border border-stone-200/80 shadow-[0_8px_20px_-4px_rgba(44,26,18,0.12)]">
          <IconComp className="w-8 h-8" style={{ color: cfg.accent }} />
        </div>
        <span className="mt-2 text-[10px] font-mono font-bold uppercase tracking-widest text-[#4A2E1B] bg-white/90 border border-stone-200/80 px-2.5 py-0.5 rounded-full shadow-sm">
          {id}
        </span>
      </div>
    </div>
  );
}

// ============================================================================
// INITIAL SEEDED ECOSYSTEM STATE (SINGLE SOURCE OF TRUTH)
// ============================================================================
const INITIAL_STATE = {
  college: {
    name: "Sri Chaitanya & Narayana Junior Academy",
    code: "SCNA-HYD-01",
    city: "Vijayawada / Hyderabad Pilot Campus",
    pilotWindow: "12:30 PM – 01:45 PM (Lunch Break) & 04:15 PM – 05:30 PM (Evening Dispersal)",
    collectionPoints: [
      "Block A — Ground Floor Smart Kiosk #1",
      "Block B — Academic Wing Counter #2",
      "Boys/Girls Hostel Gate Dispensary #3"
    ]
  },
  students: [
    {
      id: "CK-2026-101",
      name: "Aarav Sharma",
      firstName: "Aarav",
      password: "PASS101",
      pin: "1234",
      institution: "Sri Chaitanya & Narayana Junior Academy",
      academicYear: "Intermediate Second Year (MPC)",
      status: "Active",
      walletBalance: 0,
      parentId: "PAR-101",
      parentName: "Rajesh Sharma",
      parentPin: "9999",
      parentPhone: "+91 98480 22334",
      notificationsPref: { sms: true, app: true, lowBalance: true }
    },
    {
      id: "CK-2026-102",
      name: "Diya Reddy",
      firstName: "Diya",
      password: "PASS102",
      pin: "5678",
      institution: "Sri Chaitanya & Narayana Junior Academy",
      academicYear: "Intermediate First Year (BiPC)",
      status: "Active",
      walletBalance: 0,
      parentId: "PAR-102",
      parentName: "Lakshmi Reddy",
      parentPin: "8888",
      parentPhone: "+91 94401 77889",
      notificationsPref: { sms: true, app: true, lowBalance: true }
    },
    {
      id: "CK-2026-103",
      name: "Rohan Verma",
      firstName: "Rohan",
      password: "PASS103",
      pin: "4321",
      institution: "Sri Chaitanya & Narayana Junior Academy",
      academicYear: "Intermediate Second Year (MPC)",
      status: "Inactive",
      walletBalance: 0,
      parentId: "PAR-103",
      parentName: "Vikram Verma",
      parentPin: "7777",
      parentPhone: "+91 91234 55667",
      notificationsPref: { sms: false, app: true, lowBalance: true }
    }
  ],
  spendingControls: {
    "CK-2026-101": {
      dailyLimitEnabled: true,
      dailyLimit: 500,
      weeklyLimitEnabled: true,
      weeklyLimit: 2000,
      monthlyLimitEnabled: true,
      monthlyLimit: 5000,
      restrictedCategories: [],
      lowBalanceAlertEnabled: true,
      lowBalanceThreshold: 200,
      instantTxnNotification: true,
      spendingAlertsEnabled: true
    },
    "CK-2026-102": {
      dailyLimitEnabled: true,
      dailyLimit: 350,
      weeklyLimitEnabled: false,
      weeklyLimit: 1500,
      monthlyLimitEnabled: true,
      monthlyLimit: 3500,
      restrictedCategories: [],
      lowBalanceAlertEnabled: true,
      lowBalanceThreshold: 150,
      instantTxnNotification: true,
      spendingAlertsEnabled: true
    },
    "CK-2026-103": {
      dailyLimitEnabled: false,
      dailyLimit: 400,
      weeklyLimitEnabled: false,
      weeklyLimit: 1500,
      monthlyLimitEnabled: false,
      monthlyLimit: 3000,
      restrictedCategories: [],
      lowBalanceAlertEnabled: true,
      lowBalanceThreshold: 100,
      instantTxnNotification: true,
      spendingAlertsEnabled: false
    }
  },
  products: [
    {
      id: "PRD-001",
      name: "Whole Wheat Paneer Tikka Wrap",
      category: "Food and Snacks",
      price: 90,
      stock: 18,
      active: true,
      featured: true,
      frequent: true,
      offerTag: "Popular Lunch",
      description: "Freshly grilled cottage cheese cubes with mint chutney and crunchy veggies in a toasted whole-wheat tortilla."
    },
    {
      id: "PRD-002",
      name: "Roasted Almond & Oats Energy Bar (Pack of 2)",
      category: "Food and Snacks",
      price: 60,
      stock: 35,
      active: true,
      featured: false,
      frequent: true,
      offerTag: "Zero Added Sugar",
      description: "High-protein study snack packed with Californian almonds, rolled oats, dark cocoa, and organic honey."
    },
    {
      id: "PRD-003",
      name: "Chilled Badam Milk & Saffron Bottle (200ml)",
      category: "Beverages",
      price: 45,
      stock: 25,
      active: true,
      featured: true,
      frequent: true,
      offerTag: "Bestseller",
      description: "Sterilized farm-fresh milk blended with crushed almonds and real Kashmir saffron strands."
    },
    {
      id: "PRD-004",
      name: "Electrolyte Tender Coconut Water (250ml)",
      category: "Beverages",
      price: 50,
      stock: 22,
      active: true,
      featured: false,
      frequent: false,
      offerTag: "Hydration+",
      description: "100% natural tender coconut water with zero preservatives for post-lecture hydration."
    },
    {
      id: "PRD-005",
      name: "Classmate Pulse Unruled Spiral Notebook (300 Pages)",
      category: "Academic Supplies",
      price: 120,
      stock: 40,
      active: true,
      featured: true,
      frequent: true,
      offerTag: "JEE/NEET Prep",
      description: "70 GSM high-opacity smooth paper ideal for physics derivations, rough problem solving, and lecture notes."
    },
    {
      id: "PRD-006",
      name: "Pentonic Gel & Ball Exam Pen Kit (Set of 5)",
      category: "Academic Supplies",
      price: 75,
      stock: 50,
      active: true,
      featured: false,
      frequent: true,
      offerTag: "Exam Ready",
      description: "Ultra-low viscosity waterproof ink pens engineered for fast writing speed in competitive examinations."
    },
    {
      id: "PRD-007",
      name: "Dettol Pocket Hand Sanitizer & Wet Wipes Combo",
      category: "Personal Care",
      price: 85,
      stock: 15,
      active: true,
      featured: false,
      frequent: false,
      offerTag: "Hygiene Essential",
      description: "Alcohol-based herbal hand sanitizer (50ml) paired with 20 antibacterial refreshing facial wipes."
    },
    {
      id: "PRD-008",
      name: "Nivea Lip Care & Travel Face Wash Pack",
      category: "Personal Care",
      price: 140,
      stock: 4,
      active: true,
      featured: false,
      frequent: false,
      offerTag: "Low Stock",
      description: "Compact hostel and day-scholar grooming kit with SPF-15 lip balm and oil-control face wash."
    },
    {
      id: "PRD-009",
      name: "Stainless Steel Insulated Campus Flask (500ml)",
      category: "Daily Essentials",
      price: 250,
      stock: 12,
      active: true,
      featured: true,
      frequent: false,
      offerTag: "15% Campus Off",
      description: "Double-wall vacuum insulated bottle keeping water cold for 18 hours or tea warm during night study hours."
    },
    {
      id: "PRD-010",
      name: "Scientific Exam Pad & Geometry Pouch Bundle",
      category: "Daily Essentials",
      price: 160,
      stock: 0,
      active: true,
      featured: false,
      frequent: false,
      offerTag: "Out of Stock",
      description: "Transparent examination clipboard with non-slip clip and heavy-duty mesh stationery pouch."
    },
    {
      id: "PRD-011",
      name: "Lab Record & Practical Sheet Printing Voucher (50 Pages)",
      category: "Other Services",
      price: 100,
      stock: 100,
      active: true,
      featured: true,
      frequent: false,
      offerTag: "Instant Redemption",
      description: "Prepaid campus reprographics voucher for B&W/color diagram printing and spiral binding at Block B."
    },
    {
      id: "PRD-012",
      name: "Hostel Laundry Express Wash & Iron Token",
      category: "Other Services",
      price: 150,
      stock: 30,
      active: true,
      featured: false,
      frequent: false,
      offerTag: "24h Turnaround",
      description: "15-garment automated wash, steam press, and neatly folded package pickup token."
    }
  ],
  orders: [],
  transactions: [],
  notifications: []
};

const ORDER_STATUS_STEPS = [
  "Order Placed",
  "Payment Confirmed",
  "Accepted",
  "Preparing",
  "Ready for Collection",
  "Completed"
];

const CATEGORIES = [
  "All",
  "Food and Snacks",
  "Beverages",
  "Personal Care",
  "Daily Essentials",
  "Academic Supplies",
  "Other Services"
];

// ============================================================================
// MAIN APPLICATION COMPONENT
// ============================================================================
export default function App() {
  // Load or initialize shared ecosystem state
  const [ecosystem, setEcosystem] = useState(() => {
    try {
      const saved = localStorage.getItem('campuskart_ecosystem_v4_clean');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.students && parsed.products && parsed.transactions) {
          return parsed;
        }
      }
    } catch (e) {
      // Ignore storage error in sandboxed iframe
    }
    return INITIAL_STATE;
  });

  useEffect(() => {
    try {
      localStorage.setItem('campuskart_ecosystem_v4_clean', JSON.stringify(ecosystem));
    } catch (e) {
      // Ignore storage error
    }
  }, [ecosystem]);

  // Active Portal Switcher ('student' | 'parent' | 'ops' | 'college')
  const [activePortal, setActivePortal] = useState('student');

  // Toast Notification System (replaces browser alert/confirm)
  const [toast, setToast] = useState(null);
  const showToast = (title, message, type = 'info') => {
    setToast({ title, message, type, id: Date.now() });
  };
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 4200);
    return () => clearTimeout(timer);
  }, [toast]);

  // Support / Demo Guide Modal
  const [showDemoModal, setShowDemoModal] = useState(false);
  const [receiptModalOrder, setReceiptModalOrder] = useState(null);

  // ==========================================================================
  // 1. STUDENT APPLICATION STATE (16-Screen Complete Flow)
  // ==========================================================================
  // Screens:
  // 'welcome' (1), 'credentials' (2), 'pin' (3), 'home' (4), 'shop' (5),
  // 'product_detail' (6), 'cart' (7), 'order_review' (8), 'payment_method' (9),
  // 'wallet_verify' (10), 'payment_processing' (11), 'order_confirmation' (12),
  // 'my_orders' (13), 'order_tracking' (14), 'wallet' (15), 'profile' (16)
  const [studentScreen, setStudentScreen] = useState('welcome');
  const [loggedStudentId, setLoggedStudentId] = useState('CK-2026-101');
  const [studentAuthed, setStudentAuthed] = useState(false);

  // Screen 2 & 3 Auth Inputs
  const [credIdInput, setCredIdInput] = useState('CK-2026-101');
  const [credPassInput, setCredPassInput] = useState('PASS101');
  const [credError, setCredError] = useState('');
  const [pendingStudent, setPendingStudent] = useState(null);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [pinMasked, setPinMasked] = useState(true);

  // Screen 5 & 6 Shopping State
  const [shopSearch, setShopSearch] = useState('');
  const [shopCategory, setShopCategory] = useState('All');
  const [shopSort, setShopSort] = useState('featured');
  const [selectedProductId, setSelectedProductId] = useState('PRD-001');
  const [detailQty, setDetailQty] = useState(1);
  const [recentlyViewed, setRecentlyViewed] = useState(['PRD-001', 'PRD-005']);
  const [cart, setCart] = useState([]);
  const [processedIdempotencyKeys, setProcessedIdempotencyKeys] = useState([]);
  const [activeIdempotencyKey, setActiveIdempotencyKey] = useState('');
  const [backendConnected, setBackendConnected] = useState(false);

  // Automatic Full-Stack Backend Health & Sync Hook (connects when local SQLite server.py is running)
  useEffect(() => {
    let mounted = true;
    const syncWithBackend = async () => {
      try {
        const res = await fetch('https://campuskart-api.example.com/api/health', { method: 'GET' });
        if (mounted && res.ok) setBackendConnected(true);
      } catch (err) {
        if (mounted) setBackendConnected(false);
      }
    };
    syncWithBackend();
    return () => { mounted = false; };
  }, []);

  // Screen 8, 9, 10, 11, 12 Checkout & 5-Sec Simulated Payment
  const [fulfilmentType, setFulfilmentType] = useState('Campus Kiosk Pickup');
  const [selectedCollectionPoint, setSelectedCollectionPoint] = useState(INITIAL_STATE.college.collectionPoints[0]);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('CampusKart Wallet');
  const [simulateFailureMode, setSimulateFailureMode] = useState(false);
  const [studentPayStep, setStudentPayStep] = useState(0); // 0: idle, 1: 0-1s, 2: 1-3s, 3: 3-5s, 4: failed
  const [studentPayErrorReason, setStudentPayErrorReason] = useState('');
  const [lastConfirmedOrder, setLastConfirmedOrder] = useState(null);

  // Screen 13 & 14 Orders & Tracking
  const [orderFilter, setOrderFilter] = useState('All Orders');
  const [trackingOrderId, setTrackingOrderId] = useState('ORD-2026-8803');

  // ==========================================================================
  // 2. PARENT PORTAL STATE (14-Screen Complete Flow)
  // ==========================================================================
  // Screens:
  // 'welcome' (1), 'login' (2), 'dashboard' (3), 'add_money' (4),
  // 'funding_method' (5), 'funding_confirm' (6), 'funding_processing' (7),
  // 'funding_success' (8), 'transactions' (9), 'analytics' (10),
  // 'controls' (11), 'orders' (12), 'notifications' (13), 'statements' (14)
  const [parentScreen, setParentScreen] = useState('welcome');
  const [parentAuthed, setParentAuthed] = useState(false);
  const [parentLookupStudentId, setParentLookupStudentId] = useState('CK-2026-101');
  const [parentPinInput, setParentPinInput] = useState('9999');
  const [parentAuthError, setParentAuthError] = useState('');
  const [linkedStudentId, setLinkedStudentId] = useState('CK-2026-101');

  // Parent Funding Flow (Screens 4-8)
  const [fundAmount, setFundAmount] = useState(1000);
  const [customFundInput, setCustomFundInput] = useState('1000');
  const [fundingMethod, setFundingMethod] = useState('UPI');
  const [parentPayStep, setParentPayStep] = useState(0);
  const [lastFundingReceipt, setLastFundingReceipt] = useState(null);

  // Parent Transactions Filter (Screen 9)
  const [parentTxnFilter, setParentTxnFilter] = useState('All');
  const [parentDateRange, setParentDateRange] = useState('All Time');

  // ==========================================================================
  // 3. OPERATIONS DASHBOARD STATE (5-Screen Flow)
  // ==========================================================================
  // Screens: 'overview' (1), 'orders' (2), 'inventory' (3), 'students' (4), 'reconciliation' (5)
  const [opsScreen, setOpsScreen] = useState('overview');
  const [opsOrderFilter, setOpsOrderFilter] = useState('All');
  const [newProductForm, setNewProductForm] = useState({
    name: '',
    category: 'Food and Snacks',
    price: 50,
    stock: 25,
    offerTag: 'New Arrival',
    description: ''
  });
  const [editingProductId, setEditingProductId] = useState(null);
  const [manualAdjForm, setManualAdjForm] = useState({
    studentId: 'CK-2026-101',
    type: 'Adjustment',
    amount: 50,
    reason: 'Kiosk sensor calibration credit',
    operator: 'OPS-ADMIN-04 (K. Chandra)'
  });
  const [newStudentForm, setNewStudentForm] = useState({
    name: '',
    academicYear: 'Intermediate First Year (MPC)',
    parentName: '',
    initialWallet: 500
  });

  // ==========================================================================
  // 4. COLLEGE DASHBOARD STATE (2-Screen Flow)
  // ==========================================================================
  // Screens: 'overview' (1), 'reports' (2)
  const [collegeScreen, setCollegeScreen] = useState('overview');

  // ==========================================================================
  // DERIVED REACTIVE DATA (SHARED ACROSS ALL 4 APPLICATIONS)
  // ==========================================================================
  const currentStudent = useMemo(() => {
    return ecosystem.students.find(s => s.id === loggedStudentId) || ecosystem.students[0];
  }, [ecosystem.students, loggedStudentId]);

  const parentLinkedStudent = useMemo(() => {
    return ecosystem.students.find(s => s.id === linkedStudentId) || ecosystem.students[0];
  }, [ecosystem.students, linkedStudentId]);

  // Cart details with product lookup
  const populatedCart = useMemo(() => {
    return cart.map(item => {
      const product = ecosystem.products.find(p => p.id === item.productId);
      if (!product) return null;
      return {
        ...product,
        qty: item.qty,
        subtotal: product.price * item.qty
      };
    }).filter(Boolean);
  }, [cart, ecosystem.products]);

  const cartItemCount = useMemo(() => populatedCart.reduce((acc, i) => acc + i.qty, 0), [populatedCart]);
  const cartSubtotal = useMemo(() => populatedCart.reduce((acc, i) => acc + i.subtotal, 0), [populatedCart]);
  const platformFee = 0; // Zero convenience charge for institutional student pilot
  const cartFinalPayable = cartSubtotal + platformFee;

  // Student's orders & transactions
  const studentOrders = useMemo(() => {
    return ecosystem.orders.filter(o => o.studentId === currentStudent.id);
  }, [ecosystem.orders, currentStudent.id]);

  const studentTransactions = useMemo(() => {
    return ecosystem.transactions.filter(t => t.studentId === currentStudent.id);
  }, [ecosystem.transactions, currentStudent.id]);

  // Parent's linked student orders & transactions
  const parentOrders = useMemo(() => {
    return ecosystem.orders.filter(o => o.studentId === parentLinkedStudent.id);
  }, [ecosystem.orders, parentLinkedStudent.id]);

  const parentTransactions = useMemo(() => {
    return ecosystem.transactions.filter(t => t.studentId === parentLinkedStudent.id);
  }, [ecosystem.transactions, parentLinkedStudent.id]);

  const parentControls = useMemo(() => {
    return ecosystem.spendingControls[parentLinkedStudent.id] || INITIAL_STATE.spendingControls["CK-2026-101"];
  }, [ecosystem.spendingControls, parentLinkedStudent.id]);

  const studentControls = useMemo(() => {
    return ecosystem.spendingControls[currentStudent.id] || INITIAL_STATE.spendingControls["CK-2026-101"];
  }, [ecosystem.spendingControls, currentStudent.id]);

  // Calculate spending totals from ledger
  const calcLedgerMetrics = (txns) => {
    let totalAdded = 0;
    let totalSpent = 0;
    let totalRefunds = 0;
    let purchaseCount = 0;
    txns.forEach(t => {
      if (t.type === 'Wallet Funding') totalAdded += t.amount;
      else if (t.type === 'Student Purchase') {
        totalSpent += Math.abs(t.amount);
        purchaseCount += 1;
      } else if (t.type === 'Refund' || (t.type === 'Adjustment' && t.amount > 0)) {
        totalRefunds += t.amount;
      } else if (t.type === 'Adjustment' && t.amount < 0) {
        totalSpent += Math.abs(t.amount);
      }
    });
    return {
      totalAdded,
      totalSpent,
      totalRefunds,
      purchaseCount,
      avgPurchase: purchaseCount > 0 ? Math.round(totalSpent / purchaseCount) : 0
    };
  };

  const studentMetrics = useMemo(() => calcLedgerMetrics(studentTransactions), [studentTransactions]);
  const parentMetrics = useMemo(() => calcLedgerMetrics(parentTransactions), [parentTransactions]);

  // Today's spending for daily limit enforcement
  const studentTodaySpend = useMemo(() => {
    return studentTransactions
      .filter(t => t.type === 'Student Purchase' && t.timestamp.startsWith('2026-11-16'))
      .reduce((acc, t) => acc + Math.abs(t.amount), 0);
  }, [studentTransactions]);

  // Analytics derivations for Parent Screen 3 & Screen 10 (derived strictly from shared orders & transactions)
  const parentCategoryChartData = useMemo(() => {
    const map = {
      'Food and Snacks': 0,
      'Beverages': 0,
      'Personal Care': 0,
      'Daily Essentials': 0,
      'Academic Supplies': 0,
      'Other Services': 0
    };
    parentOrders.forEach(ord => {
      if (ord.status === 'Cancelled') return;
      ord.items.forEach(it => {
        const cat = it.category || 'Daily Essentials';
        map[cat] = (map[cat] || 0) + it.subtotal;
      });
    });
    return Object.entries(map)
      .map(([name, value]) => ({ name, value }))
      .filter(d => d.value > 0);
  }, [parentOrders]);

  const highestSpendCategory = useMemo(() => {
    if (!parentCategoryChartData.length) return 'None';
    return [...parentCategoryChartData].sort((a, b) => b.value - a.value)[0].name;
  }, [parentCategoryChartData]);

  const parentMonthlyChartData = useMemo(() => {
    const months = ['Sep 2026', 'Oct 2026', 'Nov 2026'];
    const base = {
      'Sep 2026': { month: 'Sep 2026', funded: 0, spent: 0 },
      'Oct 2026': { month: 'Oct 2026', funded: 0, spent: 0 },
      'Nov 2026': { month: 'Nov 2026', funded: 0, spent: 0 }
    };
    parentTransactions.forEach(t => {
      const m = t.month || 'Nov 2026';
      if (!base[m]) base[m] = { month: m, funded: 0, spent: 0 };
      if (t.type === 'Wallet Funding') base[m].funded += t.amount;
      if (t.type === 'Student Purchase') base[m].spent += Math.abs(t.amount);
    });
    return months.map(m => base[m]);
  }, [parentTransactions]);

  const parentDailyTrendData = useMemo(() => {
    const days = [
      { day: 'Nov 10', amount: 0, funded: 0 },
      { day: 'Nov 12', amount: 0, funded: 0 },
      { day: 'Nov 14', amount: 0, funded: 0 },
      { day: 'Nov 15', amount: 0, funded: 0 },
      { day: 'Nov 16', amount: 0, funded: 0 }
    ];
    parentTransactions.forEach(t => {
      const datePrefix = t.timestamp.slice(5, 10); // MM-DD
      const mapDay = {
        '11-10': 'Nov 10',
        '11-12': 'Nov 12',
        '11-14': 'Nov 14',
        '11-15': 'Nov 15',
        '11-16': 'Nov 16'
      }[datePrefix];
      const target = days.find(d => d.day === mapDay);
      if (target) {
        if (t.type === 'Student Purchase') target.amount += Math.abs(t.amount);
        if (t.type === 'Wallet Funding') target.funded += t.amount;
      }
    });
    return days;
  }, [parentTransactions]);

  // ==========================================================================
  // STUDENT HANDLERS
  // ==========================================================================
  const handleValidateStudentCredentials = (e) => {
    if (e) e.preventDefault();
    setCredError('');
    const trimmedId = credIdInput.trim().toUpperCase();
    const student = ecosystem.students.find(s => s.id.toUpperCase() === trimmedId);

    if (!student) {
      setCredError('Student ID not found in CampusKart registry. Try CK-2026-101.');
      return;
    }
    if (student.institution !== ecosystem.college.name) {
      setCredError('Account does not belong to this participating institution.');
      return;
    }
    if (student.status !== 'Active') {
      setCredError(`Account ${student.id} (${student.name}) is currently Inactive. Contact Operations.`);
      return;
    }
    if (student.password !== credPassInput.trim()) {
      setCredError('Invalid student access password. Demo password for CK-2026-101 is PASS101.');
      return;
    }

    setPendingStudent(student);
    setPinInput('');
    setPinError('');
    setStudentScreen('pin');
  };

  const handleVerifyStudentPin = (e) => {
    if (e) e.preventDefault();
    if (!pendingStudent) return;
    if (pinInput.trim() !== pendingStudent.pin) {
      setPinError(`Incorrect 4-digit CampusKart PIN. Demo PIN for ${pendingStudent.firstName} is ${pendingStudent.pin}.`);
      return;
    }
    setLoggedStudentId(pendingStudent.id);
    setStudentAuthed(true);
    setPinError('');
    setStudentScreen('home');
    showToast('Session Established', `Welcome back, ${pendingStudent.name}!`, 'success');
  };

  const handleOpenProductDetail = (productId) => {
    setSelectedProductId(productId);
    setDetailQty(1);
    setRecentlyViewed(prev => [productId, ...prev.filter(id => id !== productId)].slice(0, 5));
    setStudentScreen('product_detail');
  };

  const handleAddToCart = (product, qtyToAdd = 1) => {
    if (!product.active || product.stock <= 0) {
      showToast('Unavailable', `${product.name} is currently out of stock.`, 'error');
      return;
    }
    const existing = cart.find(c => c.productId === product.id);
    const currentQty = existing ? existing.qty : 0;
    if (currentQty + qtyToAdd > product.stock) {
      showToast('Stock Limit Reached', `Only ${product.stock} units of ${product.name} available in stock.`, 'error');
      return;
    }
    if (existing) {
      setCart(cart.map(c => c.productId === product.id ? { ...c, qty: c.qty + qtyToAdd } : c));
    } else {
      setCart([...cart, { productId: product.id, qty: qtyToAdd }]);
    }
    showToast('Added to Cart', `${qtyToAdd}x ${product.name} added to your CampusKart bag.`, 'success');
  };

  const handleUpdateCartQty = (productId, delta) => {
    const product = ecosystem.products.find(p => p.id === productId);
    if (!product) return;
    setCart(prev => prev.map(item => {
      if (item.productId !== productId) return item;
      const nextQty = item.qty + delta;
      if (nextQty <= 0) return null;
      if (nextQty > product.stock) {
        showToast('Stock Limit', `Maximum available stock is ${product.stock} units.`, 'error');
        return item;
      }
      return { ...item, qty: nextQty };
    }).filter(Boolean));
  };

  const handleRemoveFromCart = (productId) => {
    setCart(prev => prev.filter(item => item.productId !== productId));
    showToast('Item Removed', 'Cart subtotal updated.', 'info');
  };

  const handleRequestParentTopUp = () => {
    const shortfall = Math.max(0, cartFinalPayable - currentStudent.walletBalance);
    const newNotif = {
      id: `NOTIF-${Date.now()}`,
      target: 'parent',
      studentId: currentStudent.id,
      title: 'Wallet Top-Up Requested by Student',
      message: `${currentStudent.name} requested ₹${shortfall > 0 ? shortfall : 500} top-up for a ₹${cartFinalPayable} order (Current Balance: ₹${currentStudent.walletBalance}).`,
      time: 'Just now',
      type: 'funding',
      read: false
    };
    setEcosystem(prev => ({
      ...prev,
      notifications: [newNotif, ...prev.notifications]
    }));
    showToast('Parent Notified', `Top-up request sent to ${currentStudent.parentName}'s Parent Portal.`, 'success');
  };

  // Validate spending limits and stock before payment
  const checkOrderBlockers = () => {
    if (currentStudent.status !== 'Active') {
      return 'Student account is inactive.';
    }
    if (populatedCart.length === 0) {
      return 'Your shopping cart is empty.';
    }
    for (const item of populatedCart) {
      if (!item.active || item.stock < item.qty) {
        return `${item.name} only has ${item.stock} left in stock.`;
      }
      if (studentControls.restrictedCategories?.includes(item.category)) {
        return `Category "${item.category}" (${item.name}) is restricted by Parent Spending Controls.`;
      }
    }
    if (currentStudent.walletBalance < cartFinalPayable) {
      return `Insufficient CampusKart Wallet balance. Need ₹${cartFinalPayable - currentStudent.walletBalance} more.`;
    }
    if (studentControls.dailyLimitEnabled && (studentTodaySpend + cartFinalPayable > studentControls.dailyLimit)) {
      return `Order exceeds Parent Daily Spending Limit of ₹${studentControls.dailyLimit} (Already spent today: ₹${studentTodaySpend}).`;
    }
    if (studentControls.monthlyLimitEnabled && (studentMetrics.totalSpent + cartFinalPayable > studentControls.monthlyLimit)) {
      return `Order exceeds Parent Monthly Spending Limit of ₹${studentControls.monthlyLimit}.`;
    }
    return null;
  };

  // Screen 10 -> Screen 11 (5-Second Payment Processing Sequence)
  const handleConfirmAndPay = () => {
    const blocker = checkOrderBlockers();
    if (blocker) {
      // Also notify parent if blocked by spending limit
      if (blocker.includes('Limit') || blocker.includes('restricted')) {
        const limitNotif = {
          id: `NOTIF-${Date.now()}`,
          target: 'parent',
          studentId: currentStudent.id,
          title: 'Spending Control Triggered',
          message: `Blocked ₹${cartFinalPayable} purchase attempt by ${currentStudent.name}: ${blocker}`,
          time: 'Just now',
          type: 'alert',
          read: false
        };
        setEcosystem(prev => ({
          ...prev,
          notifications: [limitNotif, ...prev.notifications]
        }));
      }
      showToast('Transaction Blocked', blocker, 'error');
      return;
    }

    setStudentScreen('payment_processing');
    setStudentPayStep(1); // 0-1s: Payment initiated
    setStudentPayErrorReason('');

    setTimeout(() => {
      setStudentPayStep(2); // 1-3s: Verify wallet balance & simulate debit
    }, 1200);

    setTimeout(() => {
      if (simulateFailureMode) {
        setStudentPayStep(4); // Failed state
        setStudentPayErrorReason('Simulated gateway verification timeout — Wallet was NOT debited and cart is preserved.');
        return;
      }
      setStudentPayStep(3); // 3-5s: Generate ref & finalize
    }, 3100);

    setTimeout(() => {
      if (simulateFailureMode) return;
      // Commit transaction, order, inventory deduction, and notifications to shared state
      const nowStr = "2026-11-16 " + new Date().toTimeString().slice(0, 5);
      const orderId = `ORD-2026-${Math.floor(8810 + Math.random() * 180)}`;
      const txnId = `TXN-CK-${Math.floor(90025 + Math.random() * 900)}`;
      constidemKey = activeIdempotencyKey || `IDEM-${Date.now()}`;
      if (processedIdempotencyKeys.includes(constidemKey)) return;
      setProcessedIdempotencyKeys(prev => [...prev, constidemKey]);
      const prevBalPaise = Math.round(currentStudent.walletBalance * 100);
      const payablePaise = Math.round(cartFinalPayable * 100);
      const newBalPaise = Math.max(0, prevBalPaise - payablePaise);
      const prevBal = prevBalPaise / 100;
      const newBal = newBalPaise / 100;
      const primaryCategory = populatedCart[0]?.category || 'Daily Essentials';

      const newOrder = {
        id: orderId,
        studentId: currentStudent.id,
        studentName: currentStudent.name,
        date: nowStr,
        month: "Nov 2026",
        items: populatedCart.map(i => ({
          productId: i.id,
          name: i.name,
          category: i.category,
          price: i.price,
          qty: i.qty,
          subtotal: i.subtotal
        })),
        totalAmount: cartFinalPayable,
        paymentStatus: "Paid via CampusKart Wallet",
        txnRef: txnId,
        fulfilmentMethod: fulfilmentType,
        collectionPoint: selectedCollectionPoint,
        estimatedTime: "12:45 PM – 01:30 PM Window",
        status: "Order Placed",
        previousBalance: prevBal,
        remainingBalance: newBal
      };

      const newTxn = {
        id: txnId,
        studentId: currentStudent.id,
        type: "Student Purchase",
        category: primaryCategory,
        amount: -cartFinalPayable,
        previousBalance: prevBal,
        newBalance: newBal,
        timestamp: nowStr,
        month: "Nov 2026",
        status: "Completed",
        method: "CampusKart Wallet",
        relatedOrderId: orderId,
        note: populatedCart.map(i => `${i.qty}x ${i.name}`).join(', ').slice(0, 65),
        reconciled: true
      };

      const newNotifs = [
        {
          id: `NOTIF-${Date.now()}-1`,
          target: 'both',
          studentId: currentStudent.id,
          title: `Order Confirmed (${orderId})`,
          message: `${currentStudent.name} placed an order for ₹${cartFinalPayable}. Remaining balance: ₹${newBal}.`,
          time: 'Just now',
          type: 'spend',
          read: false
        }
      ];

      if (studentControls.lowBalanceAlertEnabled && newBal <= studentControls.lowBalanceThreshold) {
        newNotifs.push({
          id: `NOTIF-${Date.now()}-2`,
          target: 'parent',
          studentId: currentStudent.id,
          title: 'Low Wallet Balance Alert',
          message: `${currentStudent.name}'s wallet balance is ₹${newBal} (below ₹${studentControls.lowBalanceThreshold} threshold).`,
          time: 'Just now',
          type: 'alert',
          read: false
        });
      }

      setEcosystem(prev => ({
        ...prev,
        students: prev.students.map(s => s.id === currentStudent.id ? { ...s, walletBalance: newBal } : s),
        products: prev.products.map(p => {
          const inCart = cart.find(c => c.productId === p.id);
          return inCart ? { ...p, stock: Math.max(0, p.stock - inCart.qty) } : p;
        }),
        orders: [newOrder, ...prev.orders],
        transactions: [newTxn, ...prev.transactions],
        notifications: [...newNotifs, ...prev.notifications]
      }));

      setLastConfirmedOrder(newOrder);
      setTrackingOrderId(orderId);
      setCart([]);
      setStudentScreen('order_confirmation');
    }, 5000);
  };

  // ==========================================================================
  // PARENT HANDLERS
  // ==========================================================================
  const handleParentLogin = (e) => {
    if (e) e.preventDefault();
    setParentAuthError('');
    const student = ecosystem.students.find(s => s.id.toUpperCase() === parentLookupStudentId.trim().toUpperCase());
    if (!student) {
      setParentAuthError('Student CampusKart ID not found. Use CK-2026-101 or CK-2026-102.');
      return;
    }
    if (student.parentPin !== parentPinInput.trim()) {
      setParentAuthError(`Invalid Parent Access PIN for ${student.parentName}. Demo PIN is ${student.parentPin}.`);
      return;
    }
    setLinkedStudentId(student.id);
    setParentAuthed(true);
    setParentScreen('dashboard');
    showToast('Parent Portal Unlocked', `Linked to ${student.name} (${student.id})`, 'success');
  };

  // Screen 6 -> Screen 7 -> Screen 8 (5-Second Parent Funding Simulation)
  const handleConfirmParentFunding = () => {
    const amt = Number(fundAmount);
    if (!amt || amt <= 0) {
      showToast('Invalid Amount', 'Please enter a valid funding amount greater than ₹0.', 'error');
      return;
    }
    setParentScreen('funding_processing');
    setParentPayStep(1); // 0-1s: Initiating payment

    setTimeout(() => {
      setParentPayStep(2); // 1-3s: Verifying payment method & simulated auth
    }, 1200);

    setTimeout(() => {
      setParentPayStep(3); // 3-5s: Confirming funding & updating student wallet
    }, 3100);

    setTimeout(() => {
      const nowStr = "2026-11-16 " + new Date().toTimeString().slice(0, 5);
      const txnId = `TXN-CK-${Math.floor(90100 + Math.random() * 899)}`;
      const prevBalPaise = Math.round(parentLinkedStudent.walletBalance * 100);
      const addPaise = Math.round(amt * 100);
      const newBalPaise = prevBalPaise + addPaise;
      const prevBal = prevBalPaise / 100;
      const newBal = newBalPaise / 100;

      const newTxn = {
        id: txnId,
        studentId: parentLinkedStudent.id,
        type: "Wallet Funding",
        category: "Parent Top-Up",
        amount: amt,
        previousBalance: prevBal,
        newBalance: newBal,
        timestamp: nowStr,
        month: "Nov 2026",
        status: "Completed",
        method: `${fundingMethod} (Simulated)`,
        relatedOrderId: null,
        note: `Parent wallet top-up by ${parentLinkedStudent.parentName}`,
        reconciled: true
      };

      const newNotif = {
        id: `NOTIF-${Date.now()}`,
        target: 'both',
        studentId: parentLinkedStudent.id,
        title: 'Wallet Funded Successfully',
        message: `₹${amt} added to ${parentLinkedStudent.name}'s wallet via ${fundingMethod}. New balance: ₹${newBal}.`,
        time: 'Just now',
        type: 'funding',
        read: false
      };

      setEcosystem(prev => ({
        ...prev,
        students: prev.students.map(s => s.id === parentLinkedStudent.id ? { ...s, walletBalance: newBal } : s),
        transactions: [newTxn, ...prev.transactions],
        notifications: [newNotif, ...prev.notifications]
      }));

      setLastFundingReceipt({
        txnId,
        studentName: parentLinkedStudent.name,
        studentId: parentLinkedStudent.id,
        amount: amt,
        method: fundingMethod,
        timestamp: nowStr,
        previousBalance: prevBal,
        newBalance: newBal
      });

      setParentScreen('funding_success');
    }, 5000);
  };

  const handleSaveSpendingControls = (updatedControls) => {
    setEcosystem(prev => ({
      ...prev,
      spendingControls: {
        ...prev.spendingControls,
        [parentLinkedStudent.id]: updatedControls
      },
      notifications: [
        {
          id: `NOTIF-${Date.now()}`,
          target: 'both',
          studentId: parentLinkedStudent.id,
          title: 'Spending Preferences Updated',
          message: `Parent updated spending controls (Daily limit: ${updatedControls.dailyLimitEnabled ? '₹' + updatedControls.dailyLimit : 'Off'}).`,
          time: 'Just now',
          type: 'alert',
          read: false
        },
        ...prev.notifications
      ]
    }));
    showToast('Controls Saved', 'Spending limits and category rules are now enforced in real time.', 'success');
  };

  // ==========================================================================
  // OPERATIONS HANDLERS
  // ==========================================================================
  const handleOpsUpdateOrderStatus = (orderId, nextStatus) => {
    const targetOrder = ecosystem.orders.find(o => o.id === orderId);
    if (!targetOrder) return;

    setEcosystem(prev => ({
      ...prev,
      orders: prev.orders.map(o => o.id === orderId ? { ...o, status: nextStatus } : o),
      notifications: [
        {
          id: `NOTIF-${Date.now()}`,
          target: 'both',
          studentId: targetOrder.studentId,
          title: `Order ${orderId} Status: ${nextStatus}`,
          message: `Your order (${orderId}) is now marked as "${nextStatus}" by CampusKart Operations.`,
          time: 'Just now',
          type: 'order',
          read: false
        },
        ...prev.notifications
      ]
    }));
    showToast('Order Status Updated', `${orderId} moved to "${nextStatus}". Student & Parent views synced.`, 'success');
  };

  const handleOpsUpdateStock = (productId, newStock, newPrice, toggleActive) => {
    setEcosystem(prev => ({
      ...prev,
      products: prev.products.map(p => {
        if (p.id !== productId) return p;
        return {
          ...p,
          stock: newStock !== undefined ? Math.max(0, Number(newStock)) : p.stock,
          price: newPrice !== undefined ? Math.max(1, Number(newPrice)) : p.price,
          active: toggleActive !== undefined ? toggleActive : p.active
        };
      })
    }));
    showToast('Catalogue Updated', `Product ${productId} inventory synced with Student Shop.`, 'success');
  };

  const handleOpsCreateProduct = (e) => {
    e.preventDefault();
    if (!newProductForm.name.trim()) {
      showToast('Missing Name', 'Please enter a product name.', 'error');
      return;
    }
    const newId = `PRD-0${ecosystem.products.length + 1}`;
    const prod = {
      id: newId,
      name: newProductForm.name.trim(),
      category: newProductForm.category,
      price: Math.max(5, Number(newProductForm.price) || 50),
      stock: Math.max(0, Number(newProductForm.stock) || 20),
      active: true,
      featured: true,
      frequent: false,
      offerTag: newProductForm.offerTag || 'Campus Special',
      description: newProductForm.description.trim() || 'Approved institutional campus product.'
    };
    setEcosystem(prev => ({
      ...prev,
      products: [prod, ...prev.products]
    }));
    setNewProductForm({ name: '', category: 'Food and Snacks', price: 50, stock: 25, offerTag: 'New Arrival', description: '' });
    showToast('Product Created', `${prod.name} (${prod.id}) is now live in the Student Catalogue.`, 'success');
  };

  const handleOpsToggleStudentStatus = (studentId) => {
    setEcosystem(prev => ({
      ...prev,
      students: prev.students.map(s => {
        if (s.id !== studentId) return s;
        const next = s.status === 'Active' ? 'Inactive' : 'Active';
        return { ...s, status: next };
      })
    }));
    showToast('Student Status Updated', `Account ${studentId} status toggled.`, 'info');
  };

  const handleOpsCreateStudent = (e) => {
    e.preventDefault();
    if (!newStudentForm.name.trim() || !newStudentForm.parentName.trim()) {
      showToast('Incomplete Form', 'Provide both student and linked parent name.', 'error');
      return;
    }
    const idx = ecosystem.students.length + 101;
    const newId = `CK-2026-${idx}`;
    const initBal = Math.max(0, Number(newStudentForm.initialWallet) || 0);
    const nowStr = "2026-11-16 " + new Date().toTimeString().slice(0, 5);

    const newStu = {
      id: newId,
      name: newStudentForm.name.trim(),
      firstName: newStudentForm.name.trim().split(' ')[0],
      password: `PASS${idx}`,
      pin: "1234",
      institution: ecosystem.college.name,
      academicYear: newStudentForm.academicYear,
      status: "Active",
      walletBalance: initBal,
      parentId: `PAR-${idx}`,
      parentName: newStudentForm.parentName.trim(),
      parentPin: "9999",
      parentPhone: "+91 90000 11223",
      notificationsPref: { sms: true, app: true, lowBalance: true }
    };

    const newTxns = initBal > 0 ? [{
      id: `TXN-CK-${Math.floor(90500 + Math.random() * 400)}`,
      studentId: newId,
      type: "Wallet Funding",
      category: "Parent Top-Up",
      amount: initBal,
      previousBalance: 0,
      newBalance: initBal,
      timestamp: nowStr,
      month: "Nov 2026",
      status: "Completed",
      method: "Onboarding Initial Credit",
      relatedOrderId: null,
      note: `Onboarding balance funded for ${newStu.name}`,
      reconciled: true
    }] : [];

    setEcosystem(prev => ({
      ...prev,
      students: [...prev.students, newStu],
      spendingControls: {
        ...prev.spendingControls,
        [newId]: {
          dailyLimitEnabled: true,
          dailyLimit: 500,
          weeklyLimitEnabled: true,
          weeklyLimit: 2000,
          monthlyLimitEnabled: true,
          monthlyLimit: 5000,
          restrictedCategories: [],
          lowBalanceAlertEnabled: true,
          lowBalanceThreshold: 150,
          instantTxnNotification: true,
          spendingAlertsEnabled: true
        }
      },
      transactions: [...newTxns, ...prev.transactions]
    }));
    setNewStudentForm({ name: '', academicYear: 'Intermediate First Year (MPC)', parentName: '', initialWallet: 500 });
    showToast('Student Enrolled', `${newStu.name} registered with ID ${newId} (Pass: PASS${idx}, PIN: 1234).`, 'success');
  };

  const handleOpsManualAdjustment = (e) => {
    e.preventDefault();
    const stu = ecosystem.students.find(s => s.id === manualAdjForm.studentId);
    if (!stu) return;
    const rawAmt = Number(manualAdjForm.amount);
    if (!rawAmt || !manualAdjForm.reason.trim()) {
      showToast('Audit Requirement', 'Reason, operator identity, and non-zero amount are mandatory.', 'error');
      return;
    }
    const prevBalPaise = Math.round(stu.walletBalance * 100);
    const deltaPaise = Math.round(rawAmt * 100);
    if (prevBalPaise + deltaPaise < 0) {
      showToast('Negative Balance Blocked', 'Wallet adjustment cannot result in a negative balance.', 'error');
      return;
    }
    const prevBal = prevBalPaise / 100;
    const nextBal = (prevBalPaise + deltaPaise) / 100;
    const nowStr = "2026-11-16 " + new Date().toTimeString().slice(0, 5);
    const txnId = `TXN-ADJ-${Math.floor(1000 + Math.random() * 9000)}`;

    const newTxn = {
      id: txnId,
      studentId: stu.id,
      type: manualAdjForm.type,
      category: "Audited Adjustment",
      amount: rawAmt,
      previousBalance: prevBal,
      newBalance: nextBal,
      timestamp: nowStr,
      month: "Nov 2026",
      status: "Completed",
      method: `Operator: ${manualAdjForm.operator}`,
      relatedOrderId: null,
      note: `[AUDIT] ${manualAdjForm.reason.trim()}`,
      reconciled: true
    };

    setEcosystem(prev => ({
      ...prev,
      students: prev.students.map(s => s.id === stu.id ? { ...s, walletBalance: nextBal } : s),
      transactions: [newTxn, ...prev.transactions],
      notifications: [
        {
          id: `NOTIF-${Date.now()}`,
          target: 'both',
          studentId: stu.id,
          title: `Audited Wallet ${manualAdjForm.type}`,
          message: `₹${rawAmt} adjustment recorded by ${manualAdjForm.operator} (${manualAdjForm.reason}). New balance: ₹${nextBal}.`,
          time: 'Just now',
          type: 'funding',
          read: false
        },
        ...prev.notifications
      ]
    }));

    setManualAdjForm({ ...manualAdjForm, amount: 50, reason: '' });
    showToast('Ledger Entry Recorded', `Audited transaction ${txnId} committed and reconciled.`, 'success');
  };

  const handleResetDemoData = () => {
    setEcosystem(INITIAL_STATE);
    setCart([]); setProcessedIdempotencyKeys([]);
    showToast('Demo State Reset', 'All portals restored to clean seeded evaluation data.', 'info');
  };

  // ==========================================================================
  // RENDER: GLOBAL ECOSYSTEM SWITCHER BAR (TOP EVALUATOR BAR)
  // ==========================================================================
  return (
    <div className="min-h-screen bg-[#FAF7F2] text-[#2C1A12] font-sans relative selection:bg-orange-500 selection:text-white">
      <ShaderBackground theme={activePortal} />

      {/* Global Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 max-w-sm w-full bg-white/95 backdrop-blur-2xl border border-stone-200/90 shadow-[0_16px_40px_-8px_rgba(44,26,18,0.14)] rounded-2xl p-4 shadow-2xl flex items-start gap-3 animate-in fade-in slide-in-from-bottom-4">
          <div className={`p-2 rounded-xl shrink-0 ${
            toast.type === 'success' ? 'bg-emerald-500/20 text-emerald-700' :
            toast.type === 'error' ? 'bg-rose-500/20 text-rose-600' :
            'bg-orange-500/15 text-orange-600'
          }`}>
            {toast.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> :
             toast.type === 'error' ? <AlertTriangle className="w-5 h-5" /> :
             <Sparkles className="w-5 h-5" />}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-[#2C1A12]">{toast.title}</p>
            <p className="text-xs text-stone-600 mt-0.5 leading-relaxed">{toast.message}</p>
          </div>
          <button onClick={() => setToast(null)} className="text-stone-500 hover:text-[#2C1A12] text-xs px-1.5 py-0.5">✕</button>
        </div>
      )}

      {/* Receipt Inspection Modal */}
      {receiptModalOrder && (
        <div className="fixed inset-0 z-50 bg-[#2C1A12]/45 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white shadow-sm border border-stone-200/90 rounded-3xl max-w-md w-full p-6 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-stone-200/80 pb-4">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-widest px-2 py-0.5 rounded bg-orange-500/15 text-orange-700">
                  Official CampusKart Receipt
                </span>
                <h3 className="text-lg font-bold text-[#2C1A12] mt-1">{receiptModalOrder.id}</h3>
              </div>
              <button
                onClick={() => setReceiptModalOrder(null)}
                className="p-2 rounded-xl bg-[#F5F0EB]/90 hover:bg-stone-200/65 text-stone-600"
              >
                ✕
              </button>
            </div>
            <div className="py-4 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2 bg-[#F5F0EB]/90 p-3 rounded-xl">
                <div>
                  <span className="text-stone-500 block">Student</span>
                  <span className="font-semibold text-[#2C1A12]">{receiptModalOrder.studentName} ({receiptModalOrder.studentId})</span>
                </div>
                <div>
                  <span className="text-stone-500 block">Date & Time</span>
                  <span className="font-semibold text-[#2C1A12]">{receiptModalOrder.date}</span>
                </div>
                <div>
                  <span className="text-stone-500 block">Transaction Ref</span>
                  <span className="font-mono text-orange-700">{receiptModalOrder.txnRef}</span>
                </div>
                <div>
                  <span className="text-stone-500 block">Status</span>
                  <span className="font-semibold text-emerald-700">{receiptModalOrder.status}</span>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-stone-500 font-medium uppercase tracking-wider text-[10px]">Purchased Items</p>
                {receiptModalOrder.items.map((it, idx) => (
                  <div key={idx} className="flex justify-between items-center py-1.5 border-b border-stone-200/60">
                    <div>
                      <p className="text-[#2C1A12] font-medium">{it.name}</p>
                      <p className="text-stone-500 text-[11px]">{it.qty} × ₹{it.price}</p>
                    </div>
                    <span className="font-semibold text-[#2C1A12]">₹{it.subtotal}</span>
                  </div>
                ))}
              </div>

              <div className="bg-cyan-50/80 border border-orange-200/90 rounded-xl p-3 space-y-1.5">
                <div className="flex justify-between text-stone-600">
                  <span>Previous Wallet Balance</span>
                  <span>₹{receiptModalOrder.previousBalance}</span>
                </div>
                <div className="flex justify-between text-[#2C1A12] font-bold text-sm">
                  <span>Total Amount Debited</span>
                  <span className="text-emerald-700">₹{receiptModalOrder.totalAmount}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Remaining Wallet Balance</span>
                  <span>₹{receiptModalOrder.remainingBalance}</span>
                </div>
              </div>

              <div className="text-[11px] text-stone-500 bg-[#F5F0EB]/90 p-2.5 rounded-xl">
                <p><strong className="text-[#3D251A]">Fulfilment:</strong> {receiptModalOrder.fulfilmentMethod}</p>
                <p><strong className="text-[#3D251A]">Collection Point:</strong> {receiptModalOrder.collectionPoint}</p>
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => {
                  showToast('Receipt Downloaded', `Saved ${receiptModalOrder.id}.pdf statement.`, 'success');
                  setReceiptModalOrder(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5"
              >
                <Download className="w-4 h-4" /> Download Receipt
              </button>
              <button
                onClick={() => setReceiptModalOrder(null)}
                className="px-4 py-2.5 rounded-xl bg-stone-200/65 hover:bg-stone-200/80 text-[#2C1A12] font-medium text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Evaluator Guide & Credentials Modal */}
      {showDemoModal && (
        <div className="fixed inset-0 z-50 bg-[#2C1A12]/45 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white shadow-sm border border-stone-200/90 rounded-3xl max-w-2xl w-full p-6 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-200/80 pb-4">
              <div className="flex items-center gap-2.5">
                <Sparkles className="w-6 h-6 text-orange-600" />
                <div>
                  <h3 className="text-lg font-bold text-[#2C1A12]">Institutional Evaluation — Demo Credentials & Scenarios</h3>
                  <p className="text-xs text-stone-500">All 4 applications share a live, synchronized ledger</p>
                </div>
              </div>
              <button onClick={() => setShowDemoModal(false)} className="p-2 rounded-xl bg-[#F5F0EB]/90 hover:bg-stone-200/65 text-stone-600">✕</button>
            </div>

            <div className="grid sm:grid-cols-2 gap-4 my-4 text-xs">
              <div className="p-4 rounded-2xl bg-orange-50/90 border border-orange-300/70 space-y-1.5">
                <span className="text-[10px] font-mono uppercase tracking-wider text-orange-700">Student Account #1 (Active)</span>
                <p className="text-sm font-bold text-[#2C1A12]">Aarav Sharma (2nd Year MPC)</p>
                <p className="text-stone-600">Student ID: <code className="text-orange-700 font-mono">CK-2026-101</code></p>
                <p className="text-stone-600">Password: <code className="text-orange-700 font-mono">PASS101</code></p>
                <p className="text-stone-600">CampusKart PIN: <code className="text-orange-700 font-mono">1234</code></p>
                <p className="text-sky-800 font-medium">Parent PIN (Rajesh Sharma): <code className="font-mono">9999</code></p>
              </div>
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-cyan-300/70 space-y-1.5">
                <span className="text-[10px] font-mono uppercase tracking-wider text-sky-800">Student Account #2 (Active)</span>
                <p className="text-sm font-bold text-[#2C1A12]">Diya Reddy (1st Year BiPC)</p>
                <p className="text-stone-600">Student ID: <code className="text-sky-800 font-mono">CK-2026-102</code></p>
                <p className="text-stone-600">Password: <code className="text-sky-800 font-mono">PASS102</code></p>
                <p className="text-stone-600">CampusKart PIN: <code className="text-sky-800 font-mono">5678</code></p>
                <p className="text-sky-800 font-medium">Parent PIN (Lakshmi Reddy): <code className="font-mono">8888</code></p>
              </div>
            </div>

            <div className="space-y-2 text-xs text-stone-600 bg-[#F5F0EB]/90 p-4 rounded-2xl border border-stone-200/80">
              <p className="font-semibold text-[#2C1A12]">Mandatory Shared-State Evaluation Checklist:</p>
              <p>1. <strong>Scenario A (Student Purchase):</strong> Log in as Aarav, add items, complete the 5-second wallet payment, and watch the balance debit and order propagate to Parent & Operations.</p>
              <p>2. <strong>Scenario B (Parent Top-Up):</strong> Switch to the <strong>Parent Portal</strong>, add ₹500 or ₹1,000 via simulated UPI/Card (5-sec flow), and see the Student Wallet balance update immediately.</p>
              <p>3. <strong>Scenario C (Order Fulfilment):</strong> Switch to <strong>Operations Dashboard</strong> → Order Management, advance an order status to Ready/Completed, and inspect the live progress tracker in the Student App.</p>
              <p>4. <strong>Scenario D (Spending Limit):</strong> In <strong>Parent Portal → Spending Controls</strong>, lower the Daily Limit to ₹100 or restrict a category, then try purchasing in the Student App to verify instant enforcement.</p>
            </div>

            <div className="flex justify-between items-center mt-5 pt-3 border-t border-stone-200/80">
              <button
                onClick={() => {
                  handleResetDemoData();
                  setShowDemoModal(false);
                }}
                className="px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-700 border border-rose-500/30 text-xs font-semibold flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Reset Seeded Demo Data
              </button>
              <button
                onClick={() => setShowDemoModal(false)}
                className="px-5 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold"
              >
                Continue Evaluation
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ====================================================================
          TOP ECOSYSTEM SWITCHER BAR (ALWAYS ACCESSIBLE FOR CONTINUOUS DEMO)
      ==================================================================== */}
      <header className="sticky top-0 z-40 bg-white/85 backdrop-blur-2xl border-b border-stone-200/90 shadow-[0_4px_24px_-6px_rgba(44,26,18,0.07)]">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-2">
          {/* Brand & Live Sync Indicator */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-orange-600 via-orange-500 to-amber-500 flex items-center justify-center shadow-lg shadow-orange-500/25 font-black text-white text-sm tracking-tighter">
              CK
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold tracking-tight text-[#2C1A12] text-sm sm:text-base">CAMPUSKART</span>
                <span className="hidden md:inline-flex items-center gap-1 text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/15 text-sky-800 border border-cyan-300/80">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Shared Ledger Live
                </span>
              </div>
              <p className="text-[11px] text-stone-500 hidden sm:block">
                Active Student Wallet ({currentStudent.firstName}): <strong className="text-[#2C1A12]">₹{currentStudent.walletBalance.toLocaleString('en-IN')}</strong> · Orders: <strong className="text-[#2C1A12]">{ecosystem.orders.length}</strong>
              </p>
            </div>
          </div>

          {/* 4-Portal Switcher Pills */}
          <div className="flex items-center gap-1 bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] p-1 rounded-2xl border border-stone-200/80 overflow-x-auto max-w-full">
            <button
              onClick={() => setActivePortal('student')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activePortal === 'student'
                  ? 'bg-gradient-to-r from-orange-600 to-amber-500 text-white shadow-lg shadow-orange-500/25'
                  : 'text-stone-500 hover:text-white hover:bg-[#F5F0EB]/90'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>1. Student App</span>
            </button>

            <button
              onClick={() => setActivePortal('parent')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activePortal === 'parent'
                  ? 'bg-gradient-to-r from-sky-600 to-cyan-600 text-white shadow-lg shadow-sky-500/25'
                  : 'text-stone-500 hover:text-white hover:bg-[#F5F0EB]/90'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>2. Parent Portal</span>
            </button>

            <button
              onClick={() => setActivePortal('ops')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activePortal === 'ops'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-slate-950 font-bold shadow-lg shadow-amber-500/30'
                  : 'text-stone-500 hover:text-white hover:bg-[#F5F0EB]/90'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>3. Operations</span>
              {ecosystem.orders.filter(o => o.status !== 'Completed' && o.status !== 'Cancelled').length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-stone-200/60 text-[10px]">
                  {ecosystem.orders.filter(o => o.status !== 'Completed' && o.status !== 'Cancelled').length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActivePortal('college')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${
                activePortal === 'college'
                  ? 'bg-gradient-to-r from-[#4A2E1B] to-[#6F4E37] text-white shadow-lg shadow-stone-700/20'
                  : 'text-stone-500 hover:text-white hover:bg-[#F5F0EB]/90'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>4. College Admin</span>
            </button>
          </div>

          {/* Evaluator Quick-Help & Demo Credentials */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowDemoModal(true)}
              className="px-3 py-1.5 rounded-xl bg-stone-200/65 hover:bg-stone-200/80 border border-stone-200/90 text-xs font-medium text-[#4A2E1B] flex items-center gap-1.5"
            >
              <HelpCircle className="w-3.5 h-3.5 text-orange-600" />
              <span className="hidden sm:inline">Evaluator Guide & Keys</span>
              <span className="sm:hidden">Keys</span>
            </button>
          </div>
        </div>
      </header>

      {/* ====================================================================
          PORTAL 1: STUDENT APPLICATION (16 SCREENS)
      ==================================================================== */}
      {activePortal === 'student' && (
        <main className="relative z-10 max-w-7xl mx-auto px-3 sm:px-6 py-6">
          {/* Student Sub-Navigation & Screen Jumper for Evaluators */}
          <div className="mb-6 bg-cyan-50/65 backdrop-blur-xl shadow-[0_8px_24px_-6px_rgba(2,132,199,0.08)] backdrop-blur-xl border border-orange-200/90 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[11px] font-mono uppercase tracking-wider px-2.5 py-1 rounded-lg bg-orange-500/15 text-orange-700 border border-orange-300/80">
                Student App
              </span>
              {studentAuthed ? (
                <div className="flex items-center gap-1 flex-wrap">
                  {[
                    { id: 'home', label: '4. Home', icon: Sparkles },
                    { id: 'shop', label: '5. Catalogue', icon: ShoppingBag },
                    { id: 'cart', label: `7. Cart (${cartItemCount})`, icon: Package },
                    { id: 'my_orders', label: `13. My Orders (${studentOrders.length})`, icon: Clock },
                    { id: 'order_tracking', label: '14. Live Tracker', icon: Truck },
                    { id: 'wallet', label: `15. Wallet (₹${currentStudent.walletBalance})`, icon: Wallet },
                    { id: 'profile', label: '16. Profile', icon: UserCheck }
                  ].map(tab => {
                    const Icon = tab.icon;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setStudentScreen(tab.id)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all flex items-center gap-1.5 ${
                          studentScreen === tab.id
                            ? 'bg-orange-600 text-white shadow-md shadow-orange-500/25'
                            : 'text-stone-600 hover:bg-stone-200/65'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                        <span>{tab.label}</span>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <span className="text-xs text-stone-500">
                  Authentication Phase ({studentScreen === 'welcome' ? 'Screen 1: Welcome' : studentScreen === 'credentials' ? 'Screen 2: Credentials' : 'Screen 3: PIN Verification'})
                </span>
              )}
            </div>

            {/* Evaluator Quick-Jump Dropdown */}
            <div className="flex items-center gap-2">
              <label className="text-[11px] text-stone-500 hidden md:inline">Jump to Screen:</label>
              <select
                value={studentScreen}
                onChange={(e) => {
                  const val = e.target.value;
                  if (!['welcome', 'credentials', 'pin'].includes(val)) {
                    setStudentAuthed(true);
                  }
                  setStudentScreen(val);
                }}
                className="bg-[#F4EFEA] border border-stone-200/90 rounded-xl px-2.5 py-1.5 text-xs text-[#3D251A] focus:outline-none focus:border-orange-500"
              >
                <option value="welcome">Screen 1 — Welcome / Login</option>
                <option value="credentials">Screen 2 — Student Credentials</option>
                <option value="pin">Screen 3 — Student PIN Verification</option>
                <option value="home">Screen 4 — Student Home Dashboard</option>
                <option value="shop">Screen 5 — Shop / Product Catalogue</option>
                <option value="product_detail">Screen 6 — Product Details</option>
                <option value="cart">Screen 7 — Shopping Cart</option>
                <option value="order_review">Screen 8 — Order Review</option>
                <option value="payment_method">Screen 9 — Select Payment Method</option>
                <option value="wallet_verify">Screen 10 — Wallet Balance Verification</option>
                <option value="payment_processing">Screen 11 — Payment Processing (5s)</option>
                <option value="order_confirmation">Screen 12 — Order Confirmation</option>
                <option value="my_orders">Screen 13 — My Orders</option>
                <option value="order_tracking">Screen 14 — Order Tracking</option>
                <option value="wallet">Screen 15 — Student Wallet Ledger</option>
                <option value="profile">Screen 16 — Student Profile & Settings</option>
              </select>
            </div>
          </div>

          {/* ----------------------------------------------------------------
              SCREEN 1: WELCOME / LOGIN
          ---------------------------------------------------------------- */}
          {studentScreen === 'welcome' && (
            <div className="max-w-xl mx-auto my-8 bg-white/85 backdrop-blur-xl shadow-[0_10px_28px_-6px_rgba(44,26,18,0.06)] backdrop-blur-2xl border border-stone-200/90 rounded-3xl p-6 sm:p-10 shadow-2xl text-center relative overflow-hidden">
              <div className="absolute -top-24 -left-24 w-56 h-56 bg-orange-600/30 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute -bottom-24 -right-24 w-56 h-56 bg-pink-600/25 rounded-full blur-3xl pointer-events-none" />

              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-orange-600 via-orange-500 to-amber-500 mx-auto flex items-center justify-center shadow-xl shadow-orange-500/25 mb-5">
                <ShoppingBag className="w-8 h-8 text-[#2C1A12]" />
              </div>

              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-orange-500/12 text-orange-700 border border-orange-300/80 mb-3">
                <MapPin className="w-3.5 h-3.5" /> {ecosystem.college.name}
              </span>

              <h1 className="text-2xl sm:text-3xl font-extrabold text-[#2C1A12] tracking-tight">
                Welcome to CampusKart
              </h1>
              <p className="text-sm text-stone-600 mt-2 max-w-md mx-auto leading-relaxed">
                Your campus commerce and student wallet platform. Browse approved campus snacks, beverages, academic supplies, and daily essentials with zero cash friction.
              </p>

              <div className="grid grid-cols-3 gap-3 my-6 text-left">
                <div className="p-3 rounded-2xl bg-[#F5F0EB]/90 border border-stone-200/80">
                  <Wallet className="w-5 h-5 text-orange-600 mb-1.5" />
                  <p className="text-xs font-semibold text-[#2C1A12]">Pre-Funded Wallet</p>
                  <p className="text-[11px] text-stone-500">Instant parent top-ups, no bank PINs required.</p>
                </div>
                <div className="p-3 rounded-2xl bg-[#F5F0EB]/90 border border-stone-200/80">
                  <Clock className="w-5 h-5 text-sky-600 mb-1.5" />
                  <p className="text-xs font-semibold text-[#2C1A12]">Break Pickup</p>
                  <p className="text-[11px] text-stone-500">Skip long queues during lunch & dispersal.</p>
                </div>
                <div className="p-3 rounded-2xl bg-[#F5F0EB]/90 border border-stone-200/80">
                  <Shield className="w-5 h-5 text-orange-600 mb-1.5" />
                  <p className="text-xs font-semibold text-[#2C1A12]">Campus Verified</p>
                  <p className="text-[11px] text-stone-500">100% college-approved inventory & pricing.</p>
                </div>
              </div>

              <button
                onClick={() => setStudentScreen('credentials')}
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-orange-600 via-orange-500 to-amber-500 hover:from-orange-700 hover:to-amber-600 text-white font-bold text-sm shadow-xl shadow-orange-500/25 flex items-center justify-center gap-2 transition-all"
              >
                <span>Continue to Login</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="mt-6 pt-4 border-t border-stone-200/80 flex items-center justify-between text-xs text-stone-500">
                <span>Institution ID: <strong className="text-[#3D251A] font-mono">{ecosystem.college.code}</strong></span>
                <button
                  onClick={() => setShowDemoModal(true)}
                  className="text-orange-600 hover:text-orange-700 font-medium flex items-center gap-1"
                >
                  <HelpCircle className="w-3.5 h-3.5" /> Need Support / Demo IDs?
                </button>
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              SCREEN 2: STUDENT CREDENTIALS
          ---------------------------------------------------------------- */}
          {studentScreen === 'credentials' && (
            <div className="max-w-md mx-auto my-8 bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] backdrop-blur-2xl border border-stone-200/90 rounded-3xl p-6 sm:p-8 shadow-2xl">
              <button
                onClick={() => setStudentScreen('welcome')}
                className="text-xs text-stone-500 hover:text-[#2C1A12] flex items-center gap-1 mb-4"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back to Welcome
              </button>

              <div className="flex items-center gap-3 mb-6">
                <div className="p-3 rounded-2xl bg-orange-500/15 border border-orange-300/80 text-orange-700">
                  <KeyRound className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-orange-600">Step 1 of 2</span>
                  <h2 className="text-xl font-bold text-[#2C1A12]">Student Credentials</h2>
                  <p className="text-xs text-stone-500">{ecosystem.college.name}</p>
                </div>
              </div>

              <form onSubmit={handleValidateStudentCredentials} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-stone-600 mb-1.5">
                    1. CampusKart Student ID
                  </label>
                  <input
                    type="text"
                    value={credIdInput}
                    onChange={(e) => setCredIdInput(e.target.value)}
                    placeholder="e.g. CK-2026-101"
                    className="w-full px-4 py-3 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12] text-sm font-mono focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-600 mb-1.5">
                    2. Assigned Access Password
                  </label>
                  <input
                    type="password"
                    value={credPassInput}
                    onChange={(e) => setCredPassInput(e.target.value)}
                    placeholder="Enter access credential"
                    className="w-full px-4 py-3 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12] text-sm font-mono focus:outline-none focus:border-orange-500"
                  />
                </div>

                {credError && (
                  <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-700 text-xs flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{credError}</span>
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-sm shadow-lg shadow-orange-500/25 transition-all flex items-center justify-center gap-2"
                >
                  <span>Validate Credentials</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>

              {/* Quick Demo Account Selector */}
              <div className="mt-6 pt-4 border-t border-stone-200/80">
                <p className="text-[11px] text-stone-500 mb-2 font-medium">Evaluator Quick-Fill Demo Accounts:</p>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => { setCredIdInput('CK-2026-101'); setCredPassInput('PASS101'); setCredError(''); }}
                    className="p-2 rounded-xl bg-[#F5F0EB]/90 hover:bg-stone-200/65 border border-stone-200/80 text-left text-[11px]"
                  >
                    <p className="font-bold text-[#2C1A12]">Aarav (Active)</p>
                    <p className="text-orange-700 font-mono">CK-2026-101</p>
                  </button>
                  <button
                    type="button"
                    onClick={() => { setCredIdInput('CK-2026-102'); setCredPassInput('PASS102'); setCredError(''); }}
                    className="p-2 rounded-xl bg-[#F5F0EB]/90 hover:bg-stone-200/65 border border-stone-200/80 text-left text-[11px]"
                  >
                    <p className="font-bold text-[#2C1A12]">Diya (Active)</p>
                    <p className="text-sky-800 font-mono">CK-2026-102</p>
                  </button>
                  <button
                    type="button"
                    onClick={() => { setCredIdInput('CK-2026-103'); setCredPassInput('PASS103'); setCredError(''); }}
                    className="p-2 rounded-xl bg-[#F5F0EB]/90 hover:bg-stone-200/65 border border-stone-200/80 text-left text-[11px]"
                  >
                    <p className="font-bold text-rose-700">Rohan (Inactive)</p>
                    <p className="text-stone-500 font-mono">CK-2026-103</p>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              SCREEN 3: STUDENT PIN VERIFICATION
          ---------------------------------------------------------------- */}
          {studentScreen === 'pin' && (
            <div className="max-w-md mx-auto my-8 bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] backdrop-blur-2xl border border-stone-200/90 rounded-3xl p-6 sm:p-8 shadow-2xl">
              <button
                onClick={() => setStudentScreen('credentials')}
                className="text-xs text-stone-500 hover:text-[#2C1A12] flex items-center gap-1 mb-4"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Change Student ID
              </button>

              {(() => {
                const stu = pendingStudent || currentStudent;
                return (
                  <>
                    <div className="p-4 rounded-2xl bg-orange-50/90 border border-orange-300/70 mb-5 flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-orange-600 flex items-center justify-center font-bold text-white text-base">
                        {stu.firstName[0]}
                      </div>
                      <div>
                        <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-700 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> Identity Confirmed
                        </span>
                        <h3 className="text-base font-bold text-[#2C1A12]">{stu.name}</h3>
                        <p className="text-xs text-stone-600">{stu.id} · {stu.academicYear}</p>
                      </div>
                    </div>

                    <h2 className="text-lg font-bold text-[#2C1A12] mb-1">Enter CampusKart Session PIN</h2>
                    <p className="text-xs text-stone-500 mb-4">
                      This 4-digit PIN authenticates your kiosk/web session. It is not a bank or UPI credential.
                    </p>

                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-stone-600 font-medium">4-Digit Numeric PIN</span>
                        <button
                          type="button"
                          onClick={() => setPinMasked(!pinMasked)}
                          className="text-xs text-orange-600 hover:text-orange-700 flex items-center gap-1"
                        >
                          {pinMasked ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                          <span>{pinMasked ? 'Show Digits' : 'Mask Digits'}</span>
                        </button>
                      </div>

                      <div className="grid grid-cols-4 gap-3 my-3">
                        {[0, 1, 2, 3].map(idx => {
                          const char = pinInput[idx] || '';
                          return (
                            <div
                              key={idx}
                              className={`h-14 rounded-2xl border flex items-center justify-center text-xl font-mono font-bold ${
                                char
                                  ? 'bg-orange-500/15 border-orange-500 text-white'
                                  : 'bg-[#F4EFEA] border-stone-200/90 text-slate-600'
                              }`}
                            >
                              {char ? (pinMasked ? '●' : char) : '–'}
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Numeric Keypad */}
                    <div className="grid grid-cols-3 gap-2.5 mb-4">
                      {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(digit => (
                        <button
                          key={digit}
                          type="button"
                          onClick={() => {
                            if (pinInput.length < 4) {
                              setPinInput(prev => prev + digit);
                              setPinError('');
                            }
                          }}
                          className="py-3 rounded-xl bg-[#F5F0EB]/90 hover:bg-stone-200/80 border border-stone-200/80 text-[#2C1A12] font-bold text-base transition-all active:scale-95"
                        >
                          {digit}
                        </button>
                      ))}
                      <button
                        type="button"
                        onClick={() => { setPinInput(''); setPinError(''); }}
                        className="py-3 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-700 font-semibold text-xs"
                      >
                        Clear / Retry
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (pinInput.length < 4) {
                            setPinInput(prev => prev + '0');
                            setPinError('');
                          }
                        }}
                        className="py-3 rounded-xl bg-[#F5F0EB]/90 hover:bg-stone-200/80 border border-stone-200/80 text-[#2C1A12] font-bold text-base"
                      >
                        0
                      </button>
                      <button
                        type="button"
                        onClick={() => setPinInput(stu.pin)}
                        className="py-3 rounded-xl bg-orange-500/15 hover:bg-orange-500/30 border border-orange-300/80 text-orange-700 font-semibold text-xs"
                      >
                        Auto-Fill ({stu.pin})
                      </button>
                    </div>

                    {pinError && (
                      <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-700 text-xs mb-4 flex items-center justify-between">
                        <span>{pinError}</span>
                        <button
                          type="button"
                          onClick={() => { setPinInput(''); setPinError(''); }}
                          className="underline font-semibold ml-2 shrink-0"
                        >
                          Retry
                        </button>
                      </div>
                    )}

                    <button
                      type="button"
                      onClick={handleVerifyStudentPin}
                      className="w-full py-3.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-700 hover:to-amber-600 text-white font-bold text-sm shadow-lg shadow-orange-500/25"
                    >
                      Verify PIN & Enter Dashboard
                    </button>
                  </>
                );
              })()}
            </div>
          )}

          {/* ----------------------------------------------------------------
              SCREEN 4: STUDENT HOME DASHBOARD
          ---------------------------------------------------------------- */}
          {studentScreen === 'home' && (
            <div className="space-y-6">
              {/* Personalized Header Bar */}
              <div className="bg-gradient-to-r from-white via-orange-50/85 to-cyan-50/75 backdrop-blur-xl border border-orange-300/80 rounded-3xl p-5 sm:p-7 shadow-2xl flex flex-col lg:flex-row lg:items-center justify-between gap-5">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-orange-500/15 text-orange-700 border border-orange-300/80">
                      {currentStudent.institution}
                    </span>
                    <span className="text-xs text-stone-500 font-mono">{currentStudent.id} · {currentStudent.academicYear}</span>
                  </div>
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-[#2C1A12]">
                    Hey {currentStudent.firstName}, ready for your break?
                  </h1>
                  <p className="text-xs sm:text-sm text-stone-600 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-orange-600 shrink-0" />
                    <span><strong>Upcoming Pickup Window:</strong> {ecosystem.college.pilotWindow}</span>
                  </p>
                </div>

                {/* Live Wallet Card & Quick Actions */}
                <div className="flex flex-wrap items-center gap-3">
                  <div className="bg-[#F5F0EB] border border-stone-200/90 rounded-2xl px-5 py-3.5 flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-gradient-to-br from-orange-500 to-amber-500 text-white shadow-lg">
                      <Wallet className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-[11px] text-stone-500 uppercase tracking-wider block">Available Wallet Balance</span>
                      <span className="text-2xl font-black text-[#2C1A12]">₹{currentStudent.walletBalance.toLocaleString('en-IN')}</span>
                    </div>
                    <button
                      onClick={() => setStudentScreen('wallet')}
                      className="ml-2 px-3 py-1.5 rounded-xl bg-stone-200/65 hover:bg-stone-200/80 text-xs font-semibold text-orange-700"
                    >
                      Ledger →
                    </button>
                  </div>

                  <button
                    onClick={() => setStudentScreen('profile')}
                    className="p-3.5 rounded-2xl bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] hover:bg-slate-800 border border-stone-200/90 text-[#3D251A]"
                    title="Student Profile"
                  >
                    <UserCheck className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Current Offers & Order Tracking Shortcut Banner */}
              <div className="grid md:grid-cols-3 gap-4">
                <div className="md:col-span-2 bg-gradient-to-r from-orange-100/80 via-amber-50/75 to-cyan-100/75 border border-orange-300/80 rounded-2xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-orange-500/15 text-orange-700 border border-orange-300/70">
                      Current Campus Offer
                    </span>
                    <h3 className="text-lg font-bold text-[#2C1A12] mt-1.5">Zero Convenience Fee + 15% Off Insulated Flasks</h3>
                    <p className="text-xs text-stone-600 mt-0.5">
                      Pre-order before 12:30 PM for express priority pickup at Block A & Block B Smart Kiosks.
                    </p>
                  </div>
                  <button
                    onClick={() => setStudentScreen('shop')}
                    className="px-4 py-2.5 rounded-xl bg-white text-slate-950 font-bold text-xs shrink-0 hover:bg-indigo-50 transition-all"
                  >
                    Explore Catalogue →
                  </button>
                </div>

                {/* Live Order Tracking Shortcut */}
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-cyan-300/80 rounded-2xl p-5 flex flex-col justify-between">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-700 flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5" /> Live Order Tracker
                    </span>
                    <span className="text-xs font-semibold text-[#2C1A12]">{studentOrders[0]?.id || 'No Active Order'}</span>
                  </div>
                  {studentOrders[0] ? (
                    <div className="my-2">
                      <p className="text-sm font-bold text-[#2C1A12]">{studentOrders[0].status}</p>
                      <p className="text-xs text-stone-500 truncate">{studentOrders[0].collectionPoint}</p>
                    </div>
                  ) : (
                    <p className="text-xs text-stone-500 my-2">Place an order to track real-time preparation.</p>
                  )}
                  <button
                    onClick={() => {
                      if (studentOrders[0]) setTrackingOrderId(studentOrders[0].id);
                      setStudentScreen('order_tracking');
                    }}
                    className="w-full py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-sky-800 border border-cyan-300/80 text-xs font-semibold"
                  >
                    Track My Order →
                  </button>
                </div>
              </div>

              {/* Shop by Category */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-base font-bold text-[#2C1A12]">Shop by Category</h2>
                  <button
                    onClick={() => { setShopCategory('All'); setStudentScreen('shop'); }}
                    className="text-xs text-orange-600 hover:text-orange-700 font-medium"
                  >
                    View Full Catalogue ({ecosystem.products.length} items) →
                  </button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                  {CATEGORIES.filter(c => c !== 'All').map(cat => (
                    <button
                      key={cat}
                      onClick={() => {
                        setShopCategory(cat);
                        setStudentScreen('shop');
                      }}
                      className="p-3.5 rounded-2xl bg-white/85 backdrop-blur-xl shadow-[0_10px_28px_-6px_rgba(44,26,18,0.06)] hover:bg-orange-50/80 border border-stone-200/80 hover:border-orange-400/70 text-left transition-all group"
                    >
                      <p className="text-xs font-bold text-[#2C1A12] group-hover:text-orange-700">{cat}</p>
                      <p className="text-[11px] text-stone-500 mt-0.5">
                        {ecosystem.products.filter(p => p.category === cat && p.active).length} products
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Featured Products */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-base font-bold text-[#2C1A12] flex items-center gap-2">
                    <Star className="w-4 h-4 text-orange-600" /> Featured Campus Products
                  </h2>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {ecosystem.products.filter(p => p.featured && p.active).slice(0, 4).map(prod => (
                    <div
                      key={prod.id}
                      className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 hover:border-orange-400/70 rounded-2xl p-3.5 flex flex-col justify-between transition-all"
                    >
                      <div>
                        <div className="cursor-pointer" onClick={() => handleOpenProductDetail(prod.id)}>
                          <ProductArtwork category={prod.category} id={prod.id} className="w-full h-32" />
                        </div>
                        <div className="flex items-center justify-between mt-3">
                          <span className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-[#F5F0EB]/90 text-stone-600">
                            {prod.category}
                          </span>
                          <span className="text-[10px] font-semibold text-orange-600">{prod.offerTag}</span>
                        </div>
                        <h3
                          onClick={() => handleOpenProductDetail(prod.id)}
                          className="text-sm font-bold text-[#2C1A12] mt-1.5 cursor-pointer hover:text-orange-700 line-clamp-1"
                        >
                          {prod.name}
                        </h3>
                        <p className="text-xs text-stone-500 mt-1 line-clamp-2">{prod.description}</p>
                      </div>

                      <div className="flex items-center justify-between mt-4 pt-3 border-t border-stone-200/80">
                        <div>
                          <span className="text-base font-extrabold text-[#2C1A12]">₹{prod.price}</span>
                          <span className="block text-[10px] text-emerald-700">{prod.stock} in stock</span>
                        </div>
                        <button
                          onClick={() => handleAddToCart(prod, 1)}
                          className="px-3 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold flex items-center gap-1"
                        >
                          <Plus className="w-3.5 h-3.5" /> Add
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Frequently Purchased & Recent Orders Grid */}
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Frequently Purchased */}
                <div className="bg-white/85 backdrop-blur-xl shadow-[0_10px_28px_-6px_rgba(44,26,18,0.06)] border border-stone-200/80 rounded-2xl p-5">
                  <h3 className="text-sm font-bold text-[#2C1A12] mb-3 flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 text-orange-600" /> Frequently Purchased by {currentStudent.firstName}
                  </h3>
                  <div className="space-y-2.5">
                    {ecosystem.products.filter(p => p.frequent && p.active).slice(0, 4).map(prod => (
                      <div key={prod.id} className="flex items-center justify-between p-2.5 rounded-xl bg-[#F5F0EB]/90 border border-stone-200/60">
                        <div className="min-w-0 pr-3">
                          <p
                            onClick={() => handleOpenProductDetail(prod.id)}
                            className="text-xs font-semibold text-[#2C1A12] truncate cursor-pointer hover:text-orange-700"
                          >
                            {prod.name}
                          </p>
                          <p className="text-[11px] text-stone-500">{prod.category} · ₹{prod.price}</p>
                        </div>
                        <button
                          onClick={() => handleAddToCart(prod, 1)}
                          className="px-3 py-1.5 rounded-lg bg-orange-500/15 hover:bg-orange-500/30 text-orange-700 text-xs font-semibold shrink-0"
                        >
                          + Reorder
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Recent Orders & Help */}
                <div className="bg-white/85 backdrop-blur-xl shadow-[0_10px_28px_-6px_rgba(44,26,18,0.06)] border border-stone-200/80 rounded-2xl p-5 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-sm font-bold text-[#2C1A12] flex items-center gap-2">
                        <Package className="w-4 h-4 text-emerald-700" /> Recent Orders
                      </h3>
                      <button
                        onClick={() => setStudentScreen('my_orders')}
                        className="text-xs text-orange-600 hover:text-orange-700"
                      >
                        See All →
                      </button>
                    </div>
                    <div className="space-y-2.5">
                      {studentOrders.slice(0, 3).map(ord => (
                        <div key={ord.id} className="flex items-center justify-between p-2.5 rounded-xl bg-[#F5F0EB]/90 border border-stone-200/60 text-xs">
                          <div>
                            <p className="font-bold text-[#2C1A12]">{ord.id} <span className="text-stone-500 font-normal">({ord.items.length} items)</span></p>
                            <p className="text-[11px] text-stone-500">{ord.date} · {ord.status}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-[#2C1A12]">₹{ord.totalAmount}</span>
                            <button
                              onClick={() => { setTrackingOrderId(ord.id); setStudentScreen('order_tracking'); }}
                              className="px-2.5 py-1 rounded-lg bg-stone-200/65 hover:bg-stone-200/80 text-[#2C1A12] text-[11px]"
                            >
                              Track
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-stone-200/80 flex items-center justify-between text-xs text-stone-500">
                    <span>Campus Kiosk Support Helpline: Ext #402</span>
                    <button onClick={() => setShowDemoModal(true)} className="text-orange-600 hover:underline">
                      Help & Support
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              SCREEN 5: SHOP / PRODUCT CATALOGUE
          ---------------------------------------------------------------- */}
          {studentScreen === 'shop' && (
            <div className="space-y-6">
              {/* Search, Filter & Sort Toolbar */}
              <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-2xl p-4 space-y-4">
                <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-stone-500 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      value={shopSearch}
                      onChange={(e) => setShopSearch(e.target.value)}
                      placeholder="Search snacks, notebooks, beverages, hygiene kits..."
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-xs sm:text-sm text-[#2C1A12] focus:outline-none focus:border-orange-500"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <select
                      value={shopSort}
                      onChange={(e) => setShopSort(e.target.value)}
                      className="bg-[#F4EFEA] border border-stone-200/90 rounded-xl px-3 py-2.5 text-xs text-[#3D251A]"
                    >
                      <option value="featured">Sort: Featured First</option>
                      <option value="price_asc">Price: Low to High</option>
                      <option value="price_desc">Price: High to Low</option>
                      <option value="stock">Availability: High Stock</option>
                    </select>
                    <button
                      onClick={() => setStudentScreen('cart')}
                      className="px-4 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold flex items-center gap-1.5 shrink-0"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      <span>Cart ({cartItemCount}) · ₹{cartSubtotal}</span>
                    </button>
                  </div>
                </div>

                {/* Category Pills */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                  {CATEGORIES.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setShopCategory(cat)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                        shopCategory === cat
                          ? 'bg-orange-600 text-white'
                          : 'bg-[#F5F0EB]/90 text-stone-600 hover:bg-stone-200/65'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Product Catalogue Grid */}
              {(() => {
                let filtered = ecosystem.products.filter(p => p.active);
                if (shopCategory !== 'All') {
                  filtered = filtered.filter(p => p.category === shopCategory);
                }
                if (shopSearch.trim()) {
                  const q = shopSearch.toLowerCase();
                  filtered = filtered.filter(p =>
                    p.name.toLowerCase().includes(q) ||
                    p.description.toLowerCase().includes(q) ||
                    p.category.toLowerCase().includes(q)
                  );
                }
                if (shopSort === 'price_asc') filtered = [...filtered].sort((a, b) => a.price - b.price);
                if (shopSort === 'price_desc') filtered = [...filtered].sort((a, b) => b.price - a.price);
                if (shopSort === 'stock') filtered = [...filtered].sort((a, b) => b.stock - a.stock);

                return (
                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {filtered.map(prod => {
                      const inCartItem = cart.find(c => c.productId === prod.id);
                      const isRestricted = studentControls.restrictedCategories?.includes(prod.category);
                      return (
                        <div
                          key={prod.id}
                          className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 hover:border-orange-400/70 rounded-2xl p-4 flex flex-col justify-between transition-all"
                        >
                          <div>
                            <div className="cursor-pointer" onClick={() => handleOpenProductDetail(prod.id)}>
                              <ProductArtwork category={prod.category} id={prod.id} className="w-full h-36" />
                            </div>
                            <div className="flex items-center justify-between mt-3">
                              <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-[#F5F0EB]/90 text-stone-600">
                                {prod.category}
                              </span>
                              {prod.stock === 0 ? (
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-500/20 text-rose-700">
                                  Out of Stock
                                </span>
                              ) : prod.stock <= 5 ? (
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-800">
                                  Only {prod.stock} left
                                </span>
                              ) : (
                                <span className="text-[10px] font-medium text-emerald-700">
                                  In Stock ({prod.stock})
                                </span>
                              )}
                            </div>

                            <h3
                              onClick={() => handleOpenProductDetail(prod.id)}
                              className="text-sm font-bold text-[#2C1A12] mt-2 cursor-pointer hover:text-orange-700"
                            >
                              {prod.name}
                            </h3>
                            <p className="text-xs text-stone-500 mt-1 line-clamp-2">{prod.description}</p>
                            {isRestricted && (
                              <p className="text-[10px] text-rose-600 mt-1.5 font-medium flex items-center gap-1">
                                <Lock className="w-3 h-3" /> Restricted by Parent Control
                              </p>
                            )}
                          </div>

                          <div className="mt-4 pt-3 border-t border-stone-200/80 flex items-center justify-between gap-2">
                            <div>
                              <span className="text-lg font-extrabold text-[#2C1A12]">₹{prod.price}</span>
                              <button
                                onClick={() => handleOpenProductDetail(prod.id)}
                                className="block text-[11px] text-orange-600 hover:underline"
                              >
                                View Details →
                              </button>
                            </div>

                            {inCartItem ? (
                              <div className="flex items-center gap-2 bg-[#F4EFEA] border border-orange-400/70 rounded-xl px-2 py-1">
                                <button
                                  onClick={() => handleUpdateCartQty(prod.id, -1)}
                                  className="p-1 rounded-lg hover:bg-stone-200/65 text-[#3D251A]"
                                >
                                  <Minus className="w-3.5 h-3.5" />
                                </button>
                                <span className="text-xs font-bold text-[#2C1A12] w-5 text-center">{inCartItem.qty}</span>
                                <button
                                  onClick={() => handleUpdateCartQty(prod.id, 1)}
                                  className="p-1 rounded-lg hover:bg-stone-200/65 text-[#3D251A]"
                                >
                                  <Plus className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : (
                              <button
                                disabled={prod.stock <= 0}
                                onClick={() => handleAddToCart(prod, 1)}
                                className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 ${
                                  prod.stock <= 0
                                    ? 'bg-[#F5F0EB]/90 text-slate-500 cursor-not-allowed'
                                    : 'bg-orange-600 hover:bg-orange-700 text-white shadow-md shadow-orange-500/20'
                                }`}
                              >
                                <Plus className="w-3.5 h-3.5" /> Add to Cart
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}

              {/* Recently Viewed Products */}
              {recentlyViewed.length > 0 && (
                <div className="bg-cyan-50/65 backdrop-blur-xl shadow-[0_8px_24px_-6px_rgba(2,132,199,0.08)] border border-stone-200/80 rounded-2xl p-4">
                  <h3 className="text-xs font-mono uppercase tracking-wider text-stone-500 mb-3">Recently Viewed Products</h3>
                  <div className="flex flex-wrap gap-2">
                    {recentlyViewed.map(id => {
                      const p = ecosystem.products.find(x => x.id === id);
                      if (!p) return null;
                      return (
                        <button
                          key={id}
                          onClick={() => handleOpenProductDetail(id)}
                          className="px-3 py-1.5 rounded-xl bg-[#F5F0EB]/90 hover:bg-stone-200/65 border border-stone-200/80 text-xs text-[#3D251A] flex items-center gap-2"
                        >
                          <span>{p.name}</span>
                          <span className="text-orange-600 font-bold">₹{p.price}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ----------------------------------------------------------------
              SCREEN 6: PRODUCT DETAILS
          ---------------------------------------------------------------- */}
          {studentScreen === 'product_detail' && (() => {
            const product = ecosystem.products.find(p => p.id === selectedProductId) || ecosystem.products[0];
            const inCart = cart.find(c => c.productId === product.id);
            return (
              <div className="max-w-4xl mx-auto bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-6 sm:p-8 shadow-2xl">
                <div className="flex items-center justify-between mb-6">
                  <button
                    onClick={() => setStudentScreen('shop')}
                    className="text-xs text-stone-600 hover:text-[#2C1A12] flex items-center gap-1.5 bg-[#F5F0EB]/90 px-3 py-1.5 rounded-xl"
                  >
                    <ArrowLeft className="w-4 h-4" /> Back to Catalogue
                  </button>
                  <button
                    onClick={() => setStudentScreen('cart')}
                    className="text-xs text-orange-700 hover:text-white flex items-center gap-1.5 bg-orange-500/15 border border-orange-300/80 px-3.5 py-1.5 rounded-xl font-semibold"
                  >
                    <ShoppingBag className="w-4 h-4" /> Cart ({cartItemCount} items · ₹{cartSubtotal})
                  </button>
                </div>

                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <ProductArtwork category={product.category} id={product.id} className="w-full h-64 sm:h-72" />

                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 rounded-lg bg-orange-500/15 text-orange-700 text-xs font-semibold">
                        {product.category}
                      </span>
                      <span className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-800 text-xs font-semibold">
                        {product.offerTag}
                      </span>
                    </div>

                    <h1 className="text-2xl font-extrabold text-[#2C1A12]">{product.name}</h1>
                    <p className="text-sm text-stone-600 leading-relaxed">{product.description}</p>

                    <div className="p-4 rounded-2xl bg-[#F5F0EB] border border-stone-200/80 flex items-center justify-between">
                      <div>
                        <span className="text-xs text-stone-500 block">Campus Price</span>
                        <span className="text-3xl font-black text-[#2C1A12]">₹{product.price}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-xs text-stone-500 block">Availability</span>
                        {product.stock > 0 ? (
                          <span className="text-sm font-bold text-emerald-700">{product.stock} Units Available</span>
                        ) : (
                          <span className="text-sm font-bold text-rose-600">Out of Stock</span>
                        )}
                      </div>
                    </div>

                    {/* Quantity Selector */}
                    <div className="flex items-center justify-between pt-2">
                      <span className="text-xs font-semibold text-stone-600">Select Quantity:</span>
                      <div className="flex items-center gap-3 bg-[#F4EFEA] border border-stone-200/90 rounded-xl px-3 py-1.5">
                        <button
                          onClick={() => setDetailQty(Math.max(1, detailQty - 1))}
                          className="p-1 rounded-lg hover:bg-stone-200/65 text-[#2C1A12]"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="text-sm font-bold text-[#2C1A12] w-6 text-center">{detailQty}</span>
                        <button
                          onClick={() => {
                            if (detailQty < product.stock) setDetailQty(detailQty + 1);
                            else showToast('Stock Cap', `Maximum available stock is ${product.stock}.`, 'error');
                          }}
                          className="p-1 rounded-lg hover:bg-stone-200/65 text-[#2C1A12]"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {inCart && (
                      <p className="text-xs text-orange-700">
                        Currently in your cart: <strong>{inCart.qty} unit(s)</strong> (Subtotal: ₹{inCart.qty * product.price})
                      </p>
                    )}

                    <div className="flex gap-3 pt-2">
                      <button
                        disabled={product.stock <= 0}
                        onClick={() => handleAddToCart(product, detailQty)}
                        className={`flex-1 py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 ${
                          product.stock <= 0
                            ? 'bg-[#F5F0EB]/90 text-slate-500 cursor-not-allowed'
                            : 'bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-700 hover:to-amber-600 text-white shadow-lg shadow-orange-500/25'
                        }`}
                      >
                        <ShoppingBag className="w-4 h-4" />
                        <span>Add {detailQty} to Cart (₹{product.price * detailQty})</span>
                      </button>
                      <button
                        onClick={() => setStudentScreen('cart')}
                        className="px-5 py-3.5 rounded-xl bg-stone-200/65 hover:bg-stone-200/80 text-[#2C1A12] font-semibold text-sm"
                      >
                        Go to Cart
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* ----------------------------------------------------------------
              SCREEN 7: SHOPPING CART
          ---------------------------------------------------------------- */}
          {studentScreen === 'cart' && (
            <div className="max-w-4xl mx-auto space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-2xl font-extrabold text-[#2C1A12]">Your CampusKart Shopping Bag</h1>
                  <p className="text-xs text-stone-500">Contents are preserved across screens</p>
                </div>
                <button
                  onClick={() => setStudentScreen('shop')}
                  className="px-4 py-2 rounded-xl bg-stone-200/65 hover:bg-stone-200/80 text-xs font-semibold text-[#2C1A12] flex items-center gap-1.5"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> Continue Shopping
                </button>
              </div>

              {populatedCart.length === 0 ? (
                <div className="bg-white/85 backdrop-blur-xl shadow-[0_10px_28px_-6px_rgba(44,26,18,0.06)] border border-stone-200/80 rounded-3xl p-12 text-center space-y-4">
                  <ShoppingBag className="w-12 h-12 text-slate-500 mx-auto" />
                  <h3 className="text-lg font-bold text-[#2C1A12]">Your cart is empty</h3>
                  <p className="text-xs text-stone-500 max-w-sm mx-auto">
                    Browse the student catalogue to add snacks, beverages, academic supplies, or daily essentials.
                  </p>
                  <button
                    onClick={() => setStudentScreen('shop')}
                    className="px-6 py-3 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold"
                  >
                    Browse Products
                  </button>
                </div>
              ) : (
                <div className="grid lg:grid-cols-3 gap-6">
                  {/* Cart Items List */}
                  <div className="lg:col-span-2 space-y-3">
                    {populatedCart.map(item => (
                      <div
                        key={item.id}
                        className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                      >
                        <div className="flex items-center gap-3.5">
                          <ProductArtwork category={item.category} id={item.id} className="w-20 h-20 shrink-0" />
                          <div>
                            <span className="text-[10px] text-orange-600 font-medium">{item.category}</span>
                            <h3 className="text-sm font-bold text-[#2C1A12]">{item.name}</h3>
                            <p className="text-xs text-stone-500 mt-0.5">Unit Price: ₹{item.price} · Stock: {item.stock}</p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between sm:justify-end w-full sm:w-auto gap-4">
                          <div className="flex items-center gap-2 bg-[#F4EFEA] border border-stone-200/90 rounded-xl px-2.5 py-1">
                            <button
                              onClick={() => handleUpdateCartQty(item.id, -1)}
                              className="p-1 text-stone-600 hover:text-[#2C1A12]"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="text-xs font-bold text-[#2C1A12] w-5 text-center">{item.qty}</span>
                            <button
                              onClick={() => handleUpdateCartQty(item.id, 1)}
                              className="p-1 text-stone-600 hover:text-[#2C1A12]"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          <div className="text-right min-w-[60px]">
                            <span className="text-sm font-extrabold text-[#2C1A12]">₹{item.subtotal}</span>
                          </div>

                          <button
                            onClick={() => handleRemoveFromCart(item.id)}
                            className="p-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-600"
                            title="Remove item"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Cart Summary Card */}
                  <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-orange-300/80 rounded-2xl p-5 space-y-4 h-fit">
                    <h3 className="text-base font-bold text-[#2C1A12] border-b border-stone-200/80 pb-3">Cart Summary</h3>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between text-stone-600">
                        <span>Total Item Count</span>
                        <span className="font-semibold text-[#2C1A12]">{cartItemCount} items</span>
                      </div>
                      <div className="flex justify-between text-stone-600">
                        <span>Items Subtotal</span>
                        <span className="font-semibold text-[#2C1A12]">₹{cartSubtotal}</span>
                      </div>
                      <div className="flex justify-between text-stone-600">
                        <span>Campus Pilot Handling Charge</span>
                        <span className="text-emerald-700 font-semibold">₹0 (Waived)</span>
                      </div>
                      <div className="pt-2 border-t border-stone-200/80 flex justify-between text-sm font-extrabold text-[#2C1A12]">
                        <span>Final Payable Amount</span>
                        <span className="text-orange-600 text-base">₹{cartFinalPayable}</span>
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-[#F5F0EB]/90 border border-stone-200/80 text-xs flex justify-between items-center">
                      <span className="text-stone-500">Your Wallet Balance:</span>
                      <span className={`font-bold ${currentStudent.walletBalance >= cartFinalPayable ? 'text-emerald-700' : 'text-rose-600'}`}>
                        ₹{currentStudent.walletBalance}
                      </span>
                    </div>

                    <button
                      onClick={() => setStudentScreen('order_review')}
                      className="w-full py-3.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-700 hover:to-amber-600 text-white font-bold text-sm shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2"
                    >
                      <span>Proceed to Checkout</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => setStudentScreen('shop')}
                      className="w-full py-2.5 rounded-xl bg-[#F5F0EB]/90 hover:bg-stone-200/65 text-stone-600 text-xs font-semibold"
                    >
                      Continue Shopping
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ----------------------------------------------------------------
              SCREEN 8: ORDER REVIEW
          ---------------------------------------------------------------- */}
          {studentScreen === 'order_review' && (
            <div className="max-w-3xl mx-auto bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
              <div className="flex items-center justify-between border-b border-stone-200/80 pb-4">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-orange-600">Phase 3 — Checkout Step 1</span>
                  <h2 className="text-xl font-extrabold text-[#2C1A12]">Order Review & Fulfilment</h2>
                </div>
                <button
                  onClick={() => setStudentScreen('cart')}
                  className="text-xs text-stone-500 hover:text-[#2C1A12] flex items-center gap-1"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> Edit Cart
                </button>
              </div>

              {/* Section 1: Order Details */}
              <div className="space-y-2">
                <h3 className="text-xs font-mono uppercase tracking-wider text-stone-500">1. Selected Products</h3>
                <div className="bg-[#F5F0EB] border border-stone-200/80 rounded-2xl divide-y divide-stone-200/70">
                  {populatedCart.map(item => (
                    <div key={item.id} className="p-3.5 flex items-center justify-between text-xs">
                      <div>
                        <p className="font-bold text-[#2C1A12]">{item.name}</p>
                        <p className="text-stone-500">Qty: {item.qty} × ₹{item.price}</p>
                      </div>
                      <span className="font-bold text-[#2C1A12]">₹{item.subtotal}</span>
                    </div>
                  ))}
                  <div className="p-3.5 flex items-center justify-between text-sm font-extrabold text-[#2C1A12] bg-orange-50/70">
                    <span>Total Order Value</span>
                    <span className="text-orange-700">₹{cartFinalPayable}</span>
                  </div>
                </div>
              </div>

              {/* Section 2: Fulfilment Details */}
              <div className="space-y-3">
                <h3 className="text-xs font-mono uppercase tracking-wider text-stone-500">2. Campus Fulfilment Configuration</h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  {['Campus Kiosk Pickup', 'Hostel Delivery Counter'].map(method => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setFulfilmentType(method)}
                      className={`p-3.5 rounded-2xl border text-left transition-all ${
                        fulfilmentType === method
                          ? 'bg-orange-500/15 border-orange-500 text-white'
                          : 'bg-[#F7F3EE] border-stone-200/80 text-stone-600'
                      }`}
                    >
                      <p className="text-xs font-bold">{method}</p>
                      <p className="text-[11px] text-stone-500 mt-0.5">
                        {method === 'Campus Kiosk Pickup' ? 'Instant QR/PIN collection during break' : 'Delivered to hostel gate dispensary'}
                      </p>
                    </button>
                  ))}
                </div>

                <div>
                  <label className="block text-xs text-stone-600 mb-1.5">Designated Campus Collection Point:</label>
                  <select
                    value={selectedCollectionPoint}
                    onChange={(e) => setSelectedCollectionPoint(e.target.value)}
                    className="w-full bg-[#F4EFEA] border border-stone-200/90 rounded-xl px-3.5 py-2.5 text-xs text-[#2C1A12]"
                  >
                    {ecosystem.college.collectionPoints.map(cp => (
                      <option key={cp} value={cp}>{cp}</option>
                    ))}
                  </select>
                </div>

                <div className="p-3 rounded-xl bg-[#F5F0EB]/90 border border-stone-200/80 text-xs text-stone-600 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-orange-600 shrink-0" />
                  <span><strong>Ordering & Collection Window:</strong> {ecosystem.college.pilotWindow}</span>
                </div>
              </div>

              {/* Section 3: Payment Summary */}
              <div className="space-y-2">
                <h3 className="text-xs font-mono uppercase tracking-wider text-stone-500">3. Wallet & Payment Summary</h3>
                <div className="bg-[#F4EFEA] border border-orange-300/80 rounded-2xl p-4 space-y-2 text-xs">
                  <div className="flex justify-between text-stone-600">
                    <span>Current CampusKart Wallet Balance</span>
                    <span className="font-bold text-[#2C1A12]">₹{currentStudent.walletBalance}</span>
                  </div>
                  <div className="flex justify-between text-stone-600">
                    <span>Total Payable Amount</span>
                    <span className="font-bold text-amber-800">₹{cartFinalPayable}</span>
                  </div>
                  <div className="pt-2 border-t border-stone-200/80 flex justify-between text-sm font-bold">
                    <span className="text-[#2C1A12]">Remaining Balance After Purchase</span>
                    <span className={currentStudent.walletBalance - cartFinalPayable >= 0 ? 'text-emerald-700' : 'text-rose-600'}>
                      ₹{currentStudent.walletBalance - cartFinalPayable}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setStudentScreen('payment_method')}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-700 hover:to-amber-600 text-white font-bold text-sm shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2"
              >
                <span>Continue to Payment</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* ----------------------------------------------------------------
              SCREEN 9: SELECT PAYMENT METHOD
          ---------------------------------------------------------------- */}
          {studentScreen === 'payment_method' && (() => {
            const sufficient = currentStudent.walletBalance >= cartFinalPayable;
            const shortfall = Math.max(0, cartFinalPayable - currentStudent.walletBalance);
            return (
              <div className="max-w-2xl mx-auto bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
                <div className="flex items-center justify-between border-b border-stone-200/80 pb-4">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-widest text-orange-600">Phase 3 — Checkout Step 2</span>
                    <h2 className="text-xl font-extrabold text-[#2C1A12]">Select Payment Method</h2>
                  </div>
                  <button
                    onClick={() => setStudentScreen('order_review')}
                    className="text-xs text-stone-500 hover:text-[#2C1A12] flex items-center gap-1"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" /> Back
                  </button>
                </div>

                <div className="p-3.5 rounded-2xl bg-orange-50/90 border border-orange-200/90 text-xs text-[#4A2E1B] flex items-center gap-2.5">
                  <ShieldCheck className="w-5 h-5 text-orange-600 shrink-0" />
                  <span>Students are never asked for parent bank passwords, UPI PINs, or card numbers.</span>
                </div>

                {/* Payment Method Cards */}
                <div className="space-y-3">
                  <div
                    onClick={() => setSelectedPaymentMethod('CampusKart Wallet')}
                    className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                      selectedPaymentMethod === 'CampusKart Wallet'
                        ? 'bg-orange-500/15 border-orange-500'
                        : 'bg-[#F7F3EE] border-stone-200/80'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 rounded-xl bg-orange-600 text-white">
                          <Wallet className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-[#2C1A12]">CampusKart Student Wallet (Default)</p>
                          <p className="text-xs text-stone-500">Instant zero-PIN deduction from parent-funded balance</p>
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/20 text-sky-800">
                        Active Pilot Default
                      </span>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl border border-stone-200/60 bg-stone-100/60 opacity-60 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 rounded-xl bg-[#F5F0EB]/90 text-stone-500">
                        <CreditCard className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-stone-600">External UPI / Direct Bank Cards</p>
                        <p className="text-xs text-slate-500">Disabled for student kiosk pilot — Parent Portal only</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500">Parent Only</span>
                  </div>
                </div>

                {/* Wallet Balance Breakdown Table */}
                <div className="bg-[#F4EFEA] border border-stone-200/90 rounded-2xl overflow-hidden">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="bg-[#F5F0EB]/90 text-stone-500 border-b border-stone-200/80">
                        <th className="text-left py-2.5 px-4 font-semibold">Description</th>
                        <th className="text-right py-2.5 px-4 font-semibold">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-200/70">
                      <tr>
                        <td className="py-3 px-4 text-stone-600">Available wallet balance</td>
                        <td className="py-3 px-4 text-right font-bold text-[#2C1A12]">₹{currentStudent.walletBalance}</td>
                      </tr>
                      <tr>
                        <td className="py-3 px-4 text-stone-600">Order amount</td>
                        <td className="py-3 px-4 text-right font-bold text-orange-600">₹{cartFinalPayable}</td>
                      </tr>
                      <tr className="bg-[#F5F0EB]/90">
                        <td className="py-3 px-4 font-bold text-[#2C1A12]">Remaining balance</td>
                        <td className={`py-3 px-4 text-right font-extrabold text-sm ${sufficient ? 'text-emerald-700' : 'text-rose-600'}`}>
                          {sufficient ? `₹${currentStudent.walletBalance - cartFinalPayable}` : `-₹${shortfall} (Insufficient)`}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* Insufficient Balance Handler */}
                {!sufficient ? (
                  <div className="p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 space-y-3">
                    <div className="flex items-start gap-2.5 text-rose-700 text-xs">
                      <AlertTriangle className="w-5 h-5 shrink-0 text-rose-600" />
                      <div>
                        <p className="font-bold text-sm text-[#2C1A12]">Insufficient CampusKart Wallet Balance</p>
                        <p className="mt-0.5">
                          You need an additional <strong>₹{shortfall}</strong> to complete this ₹{cartFinalPayable} order. Payment cannot proceed until your wallet is topped up.
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={handleRequestParentTopUp}
                        className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
                      >
                        Request Parent Wallet Top-Up (₹{shortfall})
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setLinkedStudentId(currentStudent.id);
                          setParentAuthed(true);
                          setFundAmount(Math.max(500, shortfall));
                          setCustomFundInput(String(Math.max(500, shortfall)));
                          setParentScreen('add_money');
                          setActivePortal('parent');
                        }}
                        className="px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold"
                      >
                        Switch to Parent Portal to Fund Now →
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => setStudentScreen('wallet_verify')}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-orange-600 to-amber-500 hover:from-orange-700 hover:to-amber-600 text-white font-bold text-sm shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2"
                  >
                    <span>Proceed to Wallet Verification</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            );
          })()}

          {/* ----------------------------------------------------------------
              SCREEN 10: WALLET BALANCE VERIFICATION
          ---------------------------------------------------------------- */}
          {studentScreen === 'wallet_verify' && (
            <div className="max-w-xl mx-auto bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
              <div className="flex items-center justify-between border-b border-stone-200/80 pb-4">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-700">Phase 3 — Final Confirmation</span>
                  <h2 className="text-xl font-extrabold text-[#2C1A12]">Wallet Balance Verification</h2>
                </div>
                <button
                  onClick={() => setStudentScreen('payment_method')}
                  className="text-xs text-stone-500 hover:text-[#2C1A12] flex items-center gap-1"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> Back
                </button>
              </div>

              <div className="bg-[#F4EFEA] border border-stone-200/80 rounded-2xl p-5 space-y-3 text-xs">
                <div className="flex justify-between py-1.5 border-b border-stone-200/60">
                  <span className="text-stone-500">Student Name</span>
                  <span className="font-bold text-[#2C1A12]">{currentStudent.name}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-stone-200/60">
                  <span className="text-stone-500">CampusKart Student ID</span>
                  <span className="font-mono font-bold text-orange-700">{currentStudent.id}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-stone-200/60">
                  <span className="text-stone-500">Selected Payment Method</span>
                  <span className="font-semibold text-[#2C1A12]">{selectedPaymentMethod}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-stone-200/60">
                  <span className="text-stone-500">Current Wallet Balance</span>
                  <span className="font-bold text-[#2C1A12]">₹{currentStudent.walletBalance}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-stone-200/60">
                  <span className="text-stone-500">Order Amount to Debit</span>
                  <span className="font-bold text-orange-600">-₹{cartFinalPayable}</span>
                </div>
                <div className="flex justify-between pt-2 text-sm">
                  <span className="font-bold text-[#2C1A12]">Remaining Wallet Balance</span>
                  <span className="font-extrabold text-emerald-700">₹{currentStudent.walletBalance - cartFinalPayable}</span>
                </div>
              </div>

              {/* Evaluator Test Toggle for Failed Payment Scenario */}
              <div className="p-3 rounded-xl bg-[#F5F0EB]/90 border border-stone-200/80 flex items-center justify-between text-xs">
                <div>
                  <p className="font-semibold text-[#3D251A]">Evaluator Test Mode: Simulate Payment Failure?</p>
                  <p className="text-[11px] text-stone-500">Tests that failed transactions preserve the cart and do not debit the wallet.</p>
                </div>
                <input
                  type="checkbox"
                  checked={simulateFailureMode}
                  onChange={(e) => setSimulateFailureMode(e.target.checked)}
                  className="w-4 h-4 accent-indigo-600 rounded cursor-pointer"
                />
              </div>

              <button
                onClick={handleConfirmAndPay}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 text-white font-extrabold text-sm shadow-xl shadow-sky-500/25 flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-5 h-5" />
                <span>Confirm and Pay ₹{cartFinalPayable}</span>
              </button>
            </div>
          )}

          {/* ----------------------------------------------------------------
              SCREEN 11: PAYMENT PROCESSING (5-SECOND DEMONSTRATION SEQUENCE)
          ---------------------------------------------------------------- */}
          {studentScreen === 'payment_processing' && (
            <div className="max-w-lg mx-auto my-10 bg-white shadow-sm/95 border border-stone-200/90 rounded-3xl p-8 text-center shadow-2xl space-y-6">
              <span className="inline-block text-[10px] font-mono uppercase tracking-widest px-3 py-1 rounded-full bg-amber-500/15 text-amber-800 border border-orange-300/80">
                Simulated Prototype Payment Engine — No Real Bank Transfer
              </span>

              {studentPayStep !== 4 ? (
                <>
                  <div className="w-20 h-20 rounded-full border-4 border-orange-300/80 border-t-indigo-400 animate-spin mx-auto flex items-center justify-center">
                    <Wallet className="w-8 h-8 text-orange-700 animate-pulse" />
                  </div>

                  <div className="space-y-2">
                    <h2 className="text-xl font-extrabold text-[#2C1A12]">
                      {studentPayStep === 1 && '0–1s: Payment Initiated...'}
                      {studentPayStep === 2 && '1–3s: Verifying Wallet & Authorizing Debit...'}
                      {studentPayStep === 3 && '3–5s: Generating Ledger Reference & Finalizing Order...'}
                    </h2>
                    <p className="text-xs text-stone-500">
                      Please wait while the 5-second demonstration payment sequence completes.
                    </p>
                  </div>

                  {/* Step Progress Bar */}
                  <div className="space-y-2.5 text-left bg-[#F4EFEA] p-4 rounded-2xl border border-stone-200/80 text-xs">
                    <div className="flex items-center gap-2.5">
                      <CheckCircle2 className={`w-4 h-4 ${studentPayStep >= 1 ? 'text-emerald-700' : 'text-slate-600'}`} />
                      <span className={studentPayStep >= 1 ? 'text-white font-medium' : 'text-slate-500'}>
                        Step 1 (0–1s): Initiate CampusKart Wallet transaction
                      </span>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <CheckCircle2 className={`w-4 h-4 ${studentPayStep >= 2 ? 'text-emerald-700' : 'text-slate-600'}`} />
                      <span className={studentPayStep >= 2 ? 'text-white font-medium' : 'text-slate-500'}>
                        Step 2 (1–3s): Validate ₹{cartFinalPayable} against balance & spending limits
                      </span>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <CheckCircle2 className={`w-4 h-4 ${studentPayStep >= 3 ? 'text-emerald-700' : 'text-slate-600'}`} />
                      <span className={studentPayStep >= 3 ? 'text-white font-medium' : 'text-slate-500'}>
                        Step 3 (3–5s): Commit ledger debit & dispatch order to Operations
                      </span>
                    </div>
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <div className="w-16 h-16 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-600 mx-auto flex items-center justify-center">
                    <XCircle className="w-10 h-10" />
                  </div>
                  <h2 className="text-xl font-extrabold text-[#2C1A12]">Simulated Transaction Failed</h2>
                  <p className="text-xs text-rose-700 bg-rose-500/10 p-3.5 rounded-xl border border-rose-500/25">
                    {studentPayErrorReason}
                  </p>
                  <div className="flex gap-3">
                    <button
                      onClick={() => {
                        setSimulateFailureMode(false);
                        setStudentScreen('wallet_verify');
                      }}
                      className="flex-1 py-3 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold"
                    >
                      Retry Payment (Normal Mode)
                    </button>
                    <button
                      onClick={() => setStudentScreen('cart')}
                      className="px-4 py-3 rounded-xl bg-stone-200/65 text-[#2C1A12] text-xs font-semibold"
                    >
                      Return to Preserved Cart
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ----------------------------------------------------------------
              SCREEN 12: ORDER CONFIRMATION
          ---------------------------------------------------------------- */}
          {studentScreen === 'order_confirmation' && (() => {
            const ord = lastConfirmedOrder || studentOrders[0];
            if (!ord) return null;
            return (
              <div className="max-w-2xl mx-auto bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-cyan-300/80 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
                <div className="text-center space-y-2">
                  <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-cyan-400/80 text-emerald-700 mx-auto flex items-center justify-center shadow-lg shadow-cyan-500/20">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                  <span className="text-[10px] font-mono uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-sky-800">
                    Simulated Wallet Debit Complete
                  </span>
                  <h1 className="text-2xl font-extrabold text-[#2C1A12]">Order Confirmed!</h1>
                  <p className="text-xs text-stone-600">
                    Your order has been dispatched to the CampusKart Operations Dashboard and your Parent Portal has been updated.
                  </p>
                </div>

                <div className="grid sm:grid-cols-2 gap-3 bg-[#F5F0EB] p-4 rounded-2xl border border-stone-200/80 text-xs">
                  <div>
                    <span className="text-stone-500 block">Order ID</span>
                    <span className="font-mono font-bold text-[#2C1A12] text-sm">{ord.id}</span>
                  </div>
                  <div>
                    <span className="text-stone-500 block">Transaction Reference</span>
                    <span className="font-mono font-bold text-orange-700">{ord.txnRef}</span>
                  </div>
                  <div>
                    <span className="text-stone-500 block">Student Name & ID</span>
                    <span className="font-semibold text-[#2C1A12]">{ord.studentName} ({ord.studentId})</span>
                  </div>
                  <div>
                    <span className="text-stone-500 block">Order Date & Time</span>
                    <span className="font-semibold text-[#2C1A12]">{ord.date}</span>
                  </div>
                  <div>
                    <span className="text-stone-500 block">Fulfilment Method</span>
                    <span className="font-semibold text-sky-800">{ord.fulfilmentMethod}</span>
                  </div>
                  <div>
                    <span className="text-stone-500 block">Collection Point & Window</span>
                    <span className="font-semibold text-[#2C1A12]">{ord.collectionPoint} ({ord.estimatedTime})</span>
                  </div>
                </div>

                {/* Purchased Items */}
                <div className="bg-[#F7F3EE] border border-stone-200/80 rounded-2xl p-4 space-y-2 text-xs">
                  <p className="font-mono uppercase text-[10px] text-stone-500">Purchased Products</p>
                  {ord.items.map((it, i) => (
                    <div key={i} className="flex justify-between py-1 border-b border-stone-200/60">
                      <span className="text-[#2C1A12]">{it.qty}× {it.name}</span>
                      <span className="font-bold text-[#2C1A12]">₹{it.subtotal}</span>
                    </div>
                  ))}
                  <div className="pt-2 flex justify-between text-stone-600">
                    <span>Previous Wallet Balance</span>
                    <span>₹{ord.previousBalance}</span>
                  </div>
                  <div className="flex justify-between text-sm font-extrabold text-[#2C1A12]">
                    <span>Total Amount Paid</span>
                    <span className="text-emerald-700">₹{ord.totalAmount}</span>
                  </div>
                  <div className="flex justify-between text-stone-600">
                    <span>Remaining Wallet Balance</span>
                    <span className="font-bold text-orange-700">₹{ord.remainingBalance}</span>
                  </div>
                </div>

                <div className="grid sm:grid-cols-3 gap-3">
                  <button
                    onClick={() => {
                      setTrackingOrderId(ord.id);
                      setStudentScreen('order_tracking');
                    }}
                    className="py-3 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs flex items-center justify-center gap-1.5"
                  >
                    <Truck className="w-4 h-4" /> Track My Order
                  </button>
                  <button
                    onClick={() => setReceiptModalOrder(ord)}
                    className="py-3 rounded-xl bg-stone-200/65 hover:bg-stone-200/80 text-[#2C1A12] font-semibold text-xs flex items-center justify-center gap-1.5"
                  >
                    <FileText className="w-4 h-4" /> View Receipt
                  </button>
                  <button
                    onClick={() => setStudentScreen('home')}
                    className="py-3 rounded-xl bg-[#F5F0EB]/90 hover:bg-stone-200/65 text-[#3D251A] font-semibold text-xs"
                  >
                    Return to Home
                  </button>
                </div>
              </div>
            );
          })()}

          {/* ----------------------------------------------------------------
              SCREEN 13: MY ORDERS
          ---------------------------------------------------------------- */}
          {studentScreen === 'my_orders' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h1 className="text-2xl font-extrabold text-[#2C1A12]">My CampusKart Orders</h1>
                  <p className="text-xs text-stone-500">Synchronized in real time with CampusKart Operations</p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {['All Orders', 'Order Placed', 'Accepted', 'Preparing', 'Ready for Collection', 'Completed', 'Cancelled'].map(st => (
                    <button
                      key={st}
                      onClick={() => setOrderFilter(st)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-medium ${
                        orderFilter === st
                          ? 'bg-orange-600 text-white'
                          : 'bg-white shadow-sm text-stone-600 hover:bg-stone-200/65 border border-stone-200/80'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                {studentOrders
                  .filter(o => orderFilter === 'All Orders' || o.status === orderFilter)
                  .map(ord => (
                    <div key={ord.id} className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5 flex flex-col justify-between gap-4">
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="font-mono font-bold text-sm text-[#2C1A12]">{ord.id}</span>
                          <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                            ord.status === 'Completed' ? 'bg-emerald-500/20 text-sky-800' :
                            ord.status === 'Ready for Collection' ? 'bg-amber-500/20 text-amber-800' :
                            'bg-orange-500/15 text-orange-700'
                          }`}>
                            {ord.status}
                          </span>
                        </div>
                        <p className="text-xs text-stone-500 mt-1">{ord.date} · {ord.collectionPoint}</p>
                        <div className="mt-3 space-y-1">
                          {ord.items.map((it, idx) => (
                            <p key={idx} className="text-xs text-[#3D251A]">
                              {it.qty}× {it.name} <span className="text-stone-500">(₹{it.subtotal})</span>
                            </p>
                          ))}
                        </div>
                      </div>

                      <div className="pt-3 border-t border-stone-200/80 flex items-center justify-between">
                        <div>
                          <span className="text-[11px] text-stone-500 block">{ord.items.reduce((a, b) => a + b.qty, 0)} units</span>
                          <span className="text-base font-extrabold text-[#2C1A12]">₹{ord.totalAmount}</span>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setReceiptModalOrder(ord)}
                            className="px-3 py-1.5 rounded-xl bg-[#F5F0EB]/90 hover:bg-stone-200/65 text-xs text-[#3D251A]"
                          >
                            Receipt
                          </button>
                          <button
                            onClick={() => {
                              setTrackingOrderId(ord.id);
                              setStudentScreen('order_tracking');
                            }}
                            className="px-3.5 py-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-xs font-semibold text-white"
                          >
                            View Details & Track →
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              SCREEN 14: ORDER TRACKING
          ---------------------------------------------------------------- */}
          {studentScreen === 'order_tracking' && (() => {
            const ord = ecosystem.orders.find(o => o.id === trackingOrderId) || studentOrders[0];
            if (!ord) return null;
            const currentStepIdx = Math.max(0, ORDER_STATUS_STEPS.indexOf(ord.status));

            return (
              <div className="max-w-3xl mx-auto bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-200/80 pb-4">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-widest text-orange-600">Live Fulfilment Tracker</span>
                    <h2 className="text-xl font-extrabold text-[#2C1A12]">Order {ord.id}</h2>
                    <p className="text-xs text-stone-500">{ord.collectionPoint} · Placed at {ord.date}</p>
                  </div>
                  <select
                    value={ord.id}
                    onChange={(e) => setTrackingOrderId(e.target.value)}
                    className="bg-[#F4EFEA] border border-stone-200/90 rounded-xl px-3 py-2 text-xs text-[#2C1A12]"
                  >
                    {studentOrders.map(o => (
                      <option key={o.id} value={o.id}>{o.id} — {o.status} (₹{o.totalAmount})</option>
                    ))}
                  </select>
                </div>

                {/* 6-Stage Visual Progress Tracker */}
                <div className="space-y-3 py-2">
                  {ORDER_STATUS_STEPS.map((stepName, index) => {
                    const done = index <= currentStepIdx || stepName === 'Payment Confirmed';
                    const isCurrent = index === currentStepIdx;
                    return (
                      <div
                        key={stepName}
                        className={`p-3.5 rounded-2xl border flex items-center justify-between transition-all ${
                          isCurrent
                            ? 'bg-orange-500/15 border-orange-500 text-white'
                            : done
                            ? 'bg-emerald-500/10 border-cyan-300/80 text-sky-900'
                            : 'bg-stone-100/80 border-stone-200/60 text-slate-500'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                            done ? 'bg-emerald-500 text-slate-950' : 'bg-stone-200/65 text-stone-500'
                          }`}>
                            {done ? '✓' : index + 1}
                          </div>
                          <div>
                            <p className="text-xs sm:text-sm font-bold">{stepName}</p>
                            <p className="text-[11px] opacity-75">
                              {index === 0 && `Order received by CampusKart kiosk queue`}
                              {index === 1 && `Ref ${ord.txnRef} verified — ₹${ord.totalAmount} debited`}
                              {index === 2 && `Accepted by campus fulfilment team`}
                              {index === 3 && `Items being packed & verified`}
                              {index === 4 && `Ready at ${ord.collectionPoint}`}
                              {index === 5 && `Handed over to ${ord.studentName}`}
                            </p>
                          </div>
                        </div>
                        {isCurrent && (
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono uppercase bg-orange-500 text-white">
                            Current Stage
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>

                <div className="p-4 rounded-2xl bg-amber-500/10 border border-orange-300/70 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                  <div>
                    <p className="font-bold text-amber-800">Evaluator Tip: Test Live Operations Sync</p>
                    <p className="text-stone-600">Switch to Operations Dashboard to advance this order's status and watch it update here.</p>
                  </div>
                  <button
                    onClick={() => {
                      setOpsScreen('orders');
                      setActivePortal('ops');
                    }}
                    className="px-3.5 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold shrink-0"
                  >
                    Open Operations Order Queue →
                  </button>
                </div>
              </div>
            );
          })()}

          {/* ----------------------------------------------------------------
              SCREEN 15: STUDENT WALLET LEDGER
          ---------------------------------------------------------------- */}
          {studentScreen === 'wallet' && (
            <div className="space-y-6">
              <div className="grid sm:grid-cols-3 gap-4">
                <div className="bg-gradient-to-br from-orange-100/85 to-cyan-50/80 border border-orange-400/70 rounded-2xl p-5">
                  <span className="text-xs text-[#4A2E1B]">Current Reconciled Balance</span>
                  <p className="text-3xl font-black text-[#2C1A12] mt-1">₹{currentStudent.walletBalance.toLocaleString('en-IN')}</p>
                  <p className="text-[11px] text-stone-600 mt-1">Student cannot independently create funds</p>
                </div>
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                  <span className="text-xs text-stone-500">Total Funds Received (Parent + Refunds)</span>
                  <p className="text-2xl font-extrabold text-emerald-700 mt-1">
                    +₹{(studentMetrics.totalAdded + studentMetrics.totalRefunds).toLocaleString('en-IN')}
                  </p>
                  <p className="text-[11px] text-stone-500 mt-1">Funded by {currentStudent.parentName}</p>
                </div>
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                  <span className="text-xs text-stone-500">Total Campus Expenditure</span>
                  <p className="text-2xl font-extrabold text-rose-600 mt-1">
                    -₹{studentMetrics.totalSpent.toLocaleString('en-IN')}
                  </p>
                  <p className="text-[11px] text-stone-500 mt-1">Across {studentMetrics.purchaseCount} verified orders</p>
                </div>
              </div>

              <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-bold text-[#2C1A12]">Complete Student Wallet Ledger</h3>
                  <button
                    onClick={handleRequestParentTopUp}
                    className="px-3.5 py-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold"
                  >
                    Request Parent Top-Up
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-left text-stone-500 border-b border-stone-200/80">
                        <th className="py-2.5 px-3">Ref ID</th>
                        <th className="py-2.5 px-3">Date & Time</th>
                        <th className="py-2.5 px-3">Type</th>
                        <th className="py-2.5 px-3">Details / Linked Order</th>
                        <th className="py-2.5 px-3 text-right">Amount</th>
                        <th className="py-2.5 px-3 text-right">Balance After</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-200/70">
                      {studentTransactions.map(t => (
                        <tr key={t.id} className="hover:bg-[#F5F0EB]/90">
                          <td className="py-3 px-3 font-mono text-orange-700">{t.id}</td>
                          <td className="py-3 px-3 text-stone-600">{t.timestamp}</td>
                          <td className="py-3 px-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                              t.amount > 0 ? 'bg-emerald-500/20 text-sky-800' : 'bg-rose-500/20 text-rose-700'
                            }`}>
                              {t.type}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-stone-600">
                            {t.note} {t.relatedOrderId && <span className="font-mono text-orange-600">({t.relatedOrderId})</span>}
                          </td>
                          <td className={`py-3 px-3 text-right font-bold ${t.amount > 0 ? 'text-emerald-700' : 'text-white'}`}>
                            {t.amount > 0 ? `+₹${t.amount}` : `-₹${Math.abs(t.amount)}`}
                          </td>
                          <td className="py-3 px-3 text-right font-mono text-[#3D251A]">₹{t.newBalance}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              SCREEN 16: STUDENT PROFILE & SETTINGS
          ---------------------------------------------------------------- */}
          {studentScreen === 'profile' && (
            <div className="max-w-2xl mx-auto bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-6 sm:p-8 space-y-6">
              <div className="flex items-center justify-between border-b border-stone-200/80 pb-4">
                <div className="flex items-center gap-3.5">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-orange-600 to-[#6F4E37] flex items-center justify-center font-black text-xl text-white">
                    {currentStudent.firstName[0]}
                  </div>
                  <div>
                    <h2 className="text-xl font-extrabold text-[#2C1A12]">{currentStudent.name}</h2>
                    <p className="text-xs text-stone-500 font-mono">{currentStudent.id} · {currentStudent.status}</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setStudentAuthed(false);
                    setStudentScreen('welcome');
                    showToast('Logged Out', 'Student session closed safely.', 'info');
                  }}
                  className="px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-700 text-xs font-bold flex items-center gap-1.5"
                >
                  <LogOut className="w-4 h-4" /> Logout
                </button>
              </div>

              <div className="grid sm:grid-cols-2 gap-4 text-xs">
                <div className="p-4 rounded-2xl bg-[#F5F0EB] border border-stone-200/80">
                  <span className="text-stone-500 block">Participating Institution</span>
                  <span className="font-bold text-[#2C1A12] mt-0.5 block">{currentStudent.institution}</span>
                </div>
                <div className="p-4 rounded-2xl bg-[#F5F0EB] border border-stone-200/80">
                  <span className="text-stone-500 block">Academic Year & Stream</span>
                  <span className="font-bold text-[#2C1A12] mt-0.5 block">{currentStudent.academicYear}</span>
                </div>
                <div className="p-4 rounded-2xl bg-[#F5F0EB] border border-stone-200/80">
                  <span className="text-stone-500 block">Linked Parent / Guardian Account</span>
                  <span className="font-bold text-emerald-700 mt-0.5 block">
                    {currentStudent.parentName} ({currentStudent.parentId}) — Verified
                  </span>
                </div>
                <div className="p-4 rounded-2xl bg-[#F5F0EB] border border-stone-200/80">
                  <span className="text-stone-500 block">Active Parent Daily Spend Cap</span>
                  <span className="font-bold text-[#2C1A12] mt-0.5 block">
                    {studentControls.dailyLimitEnabled ? `₹${studentControls.dailyLimit} / day` : 'No Daily Cap'}
                  </span>
                </div>
              </div>

              {/* Switch Demo Student Profile Quickly */}
              <div className="p-4 rounded-2xl bg-orange-50/90 border border-orange-300/70 space-y-2">
                <p className="text-xs font-bold text-[#2C1A12]">Switch Active Student Account:</p>
                <div className="flex flex-wrap gap-2">
                  {ecosystem.students.map(s => (
                    <button
                      key={s.id}
                      onClick={() => {
                        setLoggedStudentId(s.id);
                        showToast('Switched Student', `Now viewing ${s.name} (${s.id})`, 'info');
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
                        s.id === currentStudent.id ? 'bg-orange-600 text-white' : 'bg-stone-200/65 text-stone-600'
                      }`}
                    >
                      {s.name} (₹{s.walletBalance})
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </main>
      )}

      {/* ====================================================================
          PORTAL 2: PARENT APPLICATION (14 SCREENS — FINANCIAL OVERSIGHT)
      ==================================================================== */}
      {activePortal === 'parent' && (
        <main className="relative z-10 max-w-7xl mx-auto px-3 sm:px-6 py-6">
          {/* Parent Top Navigation Bar */}
          <div className="mb-6 bg-white/85 backdrop-blur-xl shadow-[0_10px_28px_-6px_rgba(44,26,18,0.06)] backdrop-blur-xl border border-cyan-300/70 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[11px] font-mono uppercase tracking-wider px-2.5 py-1 rounded-lg bg-emerald-500/20 text-sky-800 border border-cyan-300/80">
                Parent FinTech Portal
              </span>
              {parentAuthed ? (
                [
                  { id: 'dashboard', label: '3. Overview' },
                  { id: 'add_money', label: '4. Add Money' },
                  { id: 'transactions', label: '9. Transactions' },
                  { id: 'analytics', label: '10. Spending Analytics' },
                  { id: 'controls', label: '11. Spending Controls' },
                  { id: 'orders', label: '12. Student Orders' },
                  { id: 'notifications', label: `13. Alerts (${ecosystem.notifications.filter(n => n.studentId === parentLinkedStudent.id).length})` },
                  { id: 'statements', label: '14. Statements & Receipts' }
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setParentScreen(tab.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                      parentScreen === tab.id
                        ? 'bg-sky-600 text-white shadow-md shadow-sky-500/25'
                        : 'text-stone-600 hover:bg-stone-200/65'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))
              ) : (
                <span className="text-xs text-stone-500">Parent Authentication Flow (Screens 1–2)</span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <select
                value={parentScreen}
                onChange={(e) => {
                  const val = e.target.value;
                  if (!['welcome', 'login'].includes(val)) setParentAuthed(true);
                  setParentScreen(val);
                }}
                className="bg-[#F4EFEA] border border-cyan-300/80 rounded-xl px-2.5 py-1.5 text-xs text-[#3D251A]"
              >
                <option value="welcome">Screen 1 — Parent Portal Welcome</option>
                <option value="login">Screen 2 — Parent Login</option>
                <option value="dashboard">Screen 3 — Parent Dashboard Overview</option>
                <option value="add_money">Screen 4 — Add Money</option>
                <option value="funding_method">Screen 5 — Select Funding Method</option>
                <option value="funding_confirm">Screen 6 — Funding Confirmation</option>
                <option value="funding_processing">Screen 7 — Parent Payment Processing (5s)</option>
                <option value="funding_success">Screen 8 — Wallet Funding Success</option>
                <option value="transactions">Screen 9 — Transaction History</option>
                <option value="analytics">Screen 10 — Spending Analytics</option>
                <option value="controls">Screen 11 — Spending Controls</option>
                <option value="orders">Screen 12 — Linked Student Orders</option>
                <option value="notifications">Screen 13 — Parent Notifications</option>
                <option value="statements">Screen 14 — Monthly Statements & Receipts</option>
              </select>
            </div>
          </div>

          {/* ----------------------------------------------------------------
              PARENT SCREEN 1: WELCOME
          ---------------------------------------------------------------- */}
          {parentScreen === 'welcome' && (
            <div className="max-w-xl mx-auto my-8 bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-cyan-300/80 rounded-3xl p-8 text-center shadow-2xl space-y-5">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-600 to-cyan-500 mx-auto flex items-center justify-center shadow-lg shadow-sky-500/25">
                <ShieldCheck className="w-8 h-8 text-[#2C1A12]" />
              </div>
              <span className="text-[11px] font-mono uppercase tracking-widest px-3 py-1 rounded-full bg-emerald-500/15 text-sky-800">
                CampusKart Guardian Financial Suite
              </span>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-[#2C1A12]">
                Transparent Student Wallet Oversight
              </h1>
              <p className="text-sm text-stone-600 leading-relaxed">
                Instantly fund your child’s CampusKart wallet, inspect item-level receipts, analyze monthly nutrition and stationary expenditure, and set automated daily or category spending rules.
              </p>
              <button
                onClick={() => setParentScreen('login')}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-sky-600 to-cyan-600 hover:from-sky-700 hover:to-cyan-700 text-white font-bold text-sm shadow-xl shadow-sky-500/25"
              >
                Access Parent Dashboard →
              </button>
            </div>
          )}

          {/* ----------------------------------------------------------------
              PARENT SCREEN 2: PARENT LOGIN
          ---------------------------------------------------------------- */}
          {parentScreen === 'login' && (
            <div className="max-w-md mx-auto my-8 bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-cyan-300/80 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-5">
              <h2 className="text-xl font-bold text-[#2C1A12]">Parent Account Verification</h2>
              <p className="text-xs text-stone-500">
                Enter your child's CampusKart ID and your dedicated Parent Access PIN (never shares the student's password).
              </p>

              <form onSubmit={handleParentLogin} className="space-y-4">
                <div>
                  <label className="block text-xs text-stone-600 mb-1">Linked Student CampusKart ID</label>
                  <input
                    type="text"
                    value={parentLookupStudentId}
                    onChange={(e) => setParentLookupStudentId(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12] text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs text-stone-600 mb-1">Parent Verification PIN</label>
                  <input
                    type="password"
                    value={parentPinInput}
                    onChange={(e) => setParentPinInput(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12] text-sm font-mono"
                  />
                </div>

                {parentAuthError && (
                  <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-700 text-xs">
                    {parentAuthError}
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-sm"
                >
                  Secure Parent Login
                </button>
              </form>

              <div className="pt-3 border-t border-stone-200/80 grid grid-cols-2 gap-2 text-xs">
                <button
                  onClick={() => { setParentLookupStudentId('CK-2026-101'); setParentPinInput('9999'); }}
                  className="p-2 rounded-xl bg-[#F5F0EB]/90 hover:bg-stone-200/65 text-left"
                >
                  <p className="font-bold text-[#2C1A12]">Rajesh (Aarav's Parent)</p>
                  <p className="text-emerald-700 font-mono text-[11px]">ID: CK-2026-101 | PIN: 9999</p>
                </button>
                <button
                  onClick={() => { setParentLookupStudentId('CK-2026-102'); setParentPinInput('8888'); }}
                  className="p-2 rounded-xl bg-[#F5F0EB]/90 hover:bg-stone-200/65 text-left"
                >
                  <p className="font-bold text-[#2C1A12]">Lakshmi (Diya's Parent)</p>
                  <p className="text-emerald-700 font-mono text-[11px]">ID: CK-2026-102 | PIN: 8888</p>
                </button>
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              PARENT SCREEN 3: PARENT DASHBOARD OVERVIEW
          ---------------------------------------------------------------- */}
          {parentScreen === 'dashboard' && (
            <div className="space-y-6">
              {/* Top Linked Student Financial Banner */}
              <div className="bg-gradient-to-r from-white via-cyan-50/85 to-sky-50/80 border border-cyan-300/80 rounded-3xl p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-5 shadow-2xl">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono uppercase bg-emerald-500/20 text-sky-800 border border-cyan-300/80">
                      Guardian Account: {parentLinkedStudent.parentName}
                    </span>
                    <select
                      value={linkedStudentId}
                      onChange={(e) => setLinkedStudentId(e.target.value)}
                      className="bg-[#F4EFEA] border border-stone-200/90 rounded-lg px-2 py-0.5 text-xs text-sky-800 font-mono"
                    >
                      {ecosystem.students.map(s => (
                        <option key={s.id} value={s.id}>Linked Student: {s.name} ({s.id})</option>
                      ))}
                    </select>
                  </div>
                  <h1 className="text-2xl font-extrabold text-[#2C1A12]">
                    {parentLinkedStudent.name} — Financial Activity Overview
                  </h1>
                  <p className="text-xs text-stone-600">
                    {parentLinkedStudent.institution} · {parentLinkedStudent.academicYear}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <div className="bg-cyan-50/70 backdrop-blur-md border border-cyan-300/80 rounded-2xl px-5 py-3">
                    <span className="text-[10px] font-mono uppercase text-stone-500 block">Current Student Wallet</span>
                    <span className="text-2xl font-black text-emerald-700">₹{parentLinkedStudent.walletBalance.toLocaleString('en-IN')}</span>
                  </div>
                  <button
                    onClick={() => setParentScreen('add_money')}
                    className="px-5 py-3.5 rounded-2xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold text-xs shadow-lg shadow-orange-500/25 flex items-center gap-2"
                  >
                    <PlusCircle className="w-4 h-4" /> Add Money to Wallet
                  </button>
                </div>
              </div>

              {/* 4 Financial Metric Cards */}
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-4">
                  <span className="text-xs text-stone-500">Available Wallet Balance</span>
                  <p className="text-2xl font-black text-[#2C1A12] mt-1">₹{parentLinkedStudent.walletBalance}</p>
                  <span className="text-[11px] text-emerald-700">Reconciled with ledger</span>
                </div>
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-4">
                  <span className="text-xs text-stone-500">Total Funds Added</span>
                  <p className="text-2xl font-black text-emerald-700 mt-1">₹{parentMetrics.totalAdded}</p>
                  <span className="text-[11px] text-stone-500">Parent wallet top-ups</span>
                </div>
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-4">
                  <span className="text-xs text-stone-500">Total Student Expenditure</span>
                  <p className="text-2xl font-black text-orange-600 mt-1">₹{parentMetrics.totalSpent}</p>
                  <span className="text-[11px] text-stone-500">{parentMetrics.purchaseCount} campus orders</span>
                </div>
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-4">
                  <span className="text-xs text-stone-500">Daily Limit Status</span>
                  <p className="text-2xl font-black text-cyan-700 mt-1">
                    {parentControls.dailyLimitEnabled ? `₹${parentControls.dailyLimit}/day` : 'Unrestricted'}
                  </p>
                  <button onClick={() => setParentScreen('controls')} className="text-[11px] text-emerald-700 hover:underline">
                    Configure Limits →
                  </button>
                </div>
              </div>

              {/* Financial Visualizations Row */}
              <div className="grid lg:grid-cols-2 gap-6">
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-bold text-[#2C1A12]">Spending by Category (Live Shared Data)</h3>
                    <button onClick={() => setParentScreen('analytics')} className="text-xs text-emerald-700 hover:underline">
                      Full Analytics →
                    </button>
                  </div>
                  <div className="relative h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={parentCategoryChartData}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          innerRadius={55}
                          outerRadius={85}
                          paddingAngle={4}
                        >
                          {parentCategoryChartData.map((_, i) => (
                            <Cell key={i} fill={['#10b981', '#06b6d4', '#6366f1', '#f59e0b', '#ec4899', '#8b5cf6'][i % 6]} />
                          ))}
                        </Pie>
                        <Tooltip
                          contentStyle={{ backgroundColor: '#FFFFFF', borderColor: '#E7E0D6', color: '#2C1A12', borderRadius: '12px', fontSize: '12px' }}
                          formatter={(val) => [`₹${val}`, 'Spent']}
                        />
                        <Legend wrapperStyle={{ fontSize: '11px' }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-bold text-[#2C1A12]">Wallet Funding vs. Expenditure</h3>
                    <span className="text-xs text-stone-500">Monthly Comparison</span>
                  </div>
                  <div className="relative h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={parentMonthlyChartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#E7E0D6" />
                        <XAxis dataKey="month" stroke="#6F4E37" fontSize={11} />
                        <YAxis stroke="#6F4E37" fontSize={11} />
                        <Tooltip
                          contentStyle={{ backgroundColor: '#FFFFFF', borderColor: '#E7E0D6', color: '#2C1A12', borderRadius: '12px', fontSize: '12px' }}
                        />
                        <Legend wrapperStyle={{ fontSize: '11px' }} />
                        <Bar dataKey="funded" name="Wallet Funded (₹)" fill="#10b981" radius={[6, 6, 0, 0]} />
                        <Bar dataKey="spent" name="Student Spend (₹)" fill="#f59e0b" radius={[6, 6, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Recent Purchases & Notifications */}
              <div className="grid lg:grid-cols-2 gap-6">
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-bold text-[#2C1A12]">Recent Student Purchases</h3>
                    <button onClick={() => setParentScreen('orders')} className="text-xs text-emerald-700 hover:underline">
                      Inspect All Orders →
                    </button>
                  </div>
                  <div className="space-y-2.5">
                    {parentOrders.slice(0, 3).map(ord => (
                      <div key={ord.id} className="p-3 rounded-xl bg-[#F5F0EB]/90 border border-stone-200/60 flex items-center justify-between text-xs">
                        <div>
                          <p className="font-bold text-[#2C1A12]">{ord.id} — {ord.items.map(i => i.name).join(', ').slice(0, 42)}...</p>
                          <p className="text-[11px] text-stone-500">{ord.date} · Status: {ord.status}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-orange-600">-₹{ord.totalAmount}</span>
                          <button
                            onClick={() => setReceiptModalOrder(ord)}
                            className="px-2.5 py-1 rounded-lg bg-stone-200/65 hover:bg-stone-200/80 text-[#2C1A12]"
                          >
                            Receipt
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-bold text-[#2C1A12]">Recent Guardian Notifications</h3>
                    <button onClick={() => setParentScreen('notifications')} className="text-xs text-emerald-700 hover:underline">
                      All Alerts →
                    </button>
                  </div>
                  <div className="space-y-2.5">
                    {ecosystem.notifications
                      .filter(n => n.studentId === parentLinkedStudent.id)
                      .slice(0, 3)
                      .map(n => (
                        <div key={n.id} className="p-3 rounded-xl bg-[#F5F0EB]/90 border border-stone-200/60 text-xs">
                          <div className="flex justify-between">
                            <span className="font-bold text-sky-800">{n.title}</span>
                            <span className="text-[10px] text-stone-500">{n.time}</span>
                          </div>
                          <p className="text-stone-600 mt-1">{n.message}</p>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              PARENT SCREEN 4: ADD MONEY
          ---------------------------------------------------------------- */}
          {parentScreen === 'add_money' && (
            <div className="max-w-xl mx-auto bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-cyan-300/80 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-widest text-emerald-700">Phase 2 — Wallet Top-Up</span>
                <h2 className="text-2xl font-extrabold text-[#2C1A12] mt-1">Add Funds to Student Wallet</h2>
                <p className="text-xs text-stone-500">Linked Student: {parentLinkedStudent.name} ({parentLinkedStudent.id})</p>
              </div>

              <div className="grid grid-cols-5 gap-2">
                {[250, 500, 1000, 2000].map(preset => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => { setFundAmount(preset); setCustomFundInput(String(preset)); }}
                    className={`py-3 rounded-xl text-xs font-bold border transition-all ${
                      Number(fundAmount) === preset
                        ? 'bg-sky-600 border-emerald-400 text-white'
                        : 'bg-[#F4EFEA] border-stone-200/80 text-stone-600 hover:bg-[#F5F0EB]/90'
                    }`}
                  >
                    +₹{preset}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => { setFundAmount(750); setCustomFundInput('750'); }}
                  className="py-3 rounded-xl text-xs font-bold border bg-[#F4EFEA] border-stone-200/80 text-sky-800"
                >
                  Custom
                </button>
              </div>

              <div>
                <label className="block text-xs text-stone-600 mb-1.5">Enter Funding Amount (₹)</label>
                <input
                  type="number"
                  min="50"
                  max="25000"
                  value={customFundInput}
                  onChange={(e) => {
                    setCustomFundInput(e.target.value);
                    setFundAmount(Math.max(0, Number(e.target.value) || 0));
                  }}
                  className="w-full px-4 py-3.5 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12] text-lg font-extrabold focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="bg-[#F4EFEA] border border-stone-200/80 rounded-2xl p-4 space-y-2 text-xs">
                <div className="flex justify-between text-stone-600">
                  <span>Existing Student Wallet Balance</span>
                  <span className="font-bold text-[#2C1A12]">₹{parentLinkedStudent.walletBalance}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Amount Being Added</span>
                  <span className="font-bold text-emerald-700">+₹{fundAmount}</span>
                </div>
                <div className="pt-2 border-t border-stone-200/80 flex justify-between text-sm font-extrabold text-[#2C1A12]">
                  <span>New Projected Wallet Balance</span>
                  <span className="text-sky-800">₹{parentLinkedStudent.walletBalance + Number(fundAmount)}</span>
                </div>
              </div>

              <button
                onClick={() => setParentScreen('funding_method')}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-sky-600 to-cyan-600 hover:from-sky-700 hover:to-cyan-700 text-white font-bold text-sm"
              >
                Continue to Payment →
              </button>
            </div>
          )}

          {/* ----------------------------------------------------------------
              PARENT SCREEN 5: SELECT FUNDING METHOD
          ---------------------------------------------------------------- */}
          {parentScreen === 'funding_method' && (
            <div className="max-w-xl mx-auto bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-cyan-300/80 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-extrabold text-[#2C1A12]">Select Parent Funding Method</h2>
                <button onClick={() => setParentScreen('add_money')} className="text-xs text-stone-500 hover:text-[#2C1A12]">
                  ← Back
                </button>
              </div>
              <p className="text-xs text-stone-500">
                Simulated prototype payment options — no real bank credentials or card numbers are collected.
              </p>

              <div className="space-y-3">
                {[
                  { id: 'UPI', desc: 'Instant UPI AutoPay / QR Verification (Zero Fee)', icon: Smartphone },
                  { id: 'Debit Card', desc: 'RuPay / Visa / Mastercard Domestic Debit Card', icon: CreditCard },
                  { id: 'Credit Card', desc: 'Instant Campus Wallet Reload via Credit Card', icon: CreditCard },
                  { id: 'Net Banking', desc: 'Direct Institutional NEFT / IMPS Portal', icon: Landmark }
                ].map(m => {
                  const Icon = m.icon;
                  return (
                    <div
                      key={m.id}
                      onClick={() => setFundingMethod(m.id)}
                      className={`p-4 rounded-2xl border cursor-pointer flex items-center justify-between transition-all ${
                        fundingMethod === m.id
                          ? 'bg-cyan-500/15 border-sky-500 text-white'
                          : 'bg-[#F7F3EE] border-stone-200/80 text-stone-600'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className="w-5 h-5 text-emerald-700" />
                        <div>
                          <p className="text-sm font-bold">{m.id}</p>
                          <p className="text-xs text-stone-500">{m.desc}</p>
                        </div>
                      </div>
                      <div className={`w-4 h-4 rounded-full border ${fundingMethod === m.id ? 'bg-emerald-400 border-emerald-400' : 'border-slate-500'}`} />
                    </div>
                  );
                })}
              </div>

              <button
                onClick={() => setParentScreen('funding_confirm')}
                className="w-full py-3.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-sm"
              >
                Review Funding Confirmation →
              </button>
            </div>
          )}

          {/* ----------------------------------------------------------------
              PARENT SCREEN 6: FUNDING CONFIRMATION
          ---------------------------------------------------------------- */}
          {parentScreen === 'funding_confirm' && (
            <div className="max-w-xl mx-auto bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-cyan-300/80 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-extrabold text-[#2C1A12]">Funding Confirmation</h2>
                <button onClick={() => setParentScreen('funding_method')} className="text-xs text-stone-500 hover:text-[#2C1A12]">
                  ← Change Method
                </button>
              </div>

              <div className="bg-[#F4EFEA] border border-stone-200/90 rounded-2xl overflow-hidden">
                <table className="w-full text-xs">
                  <tbody className="divide-y divide-stone-200/70">
                    <tr>
                      <td className="py-3 px-4 text-stone-500">Parent Account</td>
                      <td className="py-3 px-4 text-right font-bold text-[#2C1A12]">{parentLinkedStudent.parentName} ({parentLinkedStudent.parentId})</td>
                    </tr>
                    <tr>
                      <td className="py-3 px-4 text-stone-500">Linked Student</td>
                      <td className="py-3 px-4 text-right font-bold text-[#2C1A12]">{parentLinkedStudent.name} ({parentLinkedStudent.id})</td>
                    </tr>
                    <tr>
                      <td className="py-3 px-4 text-stone-500">Selected Payment Method</td>
                      <td className="py-3 px-4 text-right font-semibold text-sky-800">{fundingMethod} (Simulated)</td>
                    </tr>
                    <tr>
                      <td className="py-3 px-4 text-stone-500">Existing wallet balance</td>
                      <td className="py-3 px-4 text-right font-bold text-[#2C1A12]">₹{parentLinkedStudent.walletBalance}</td>
                    </tr>
                    <tr>
                      <td className="py-3 px-4 text-stone-500">Amount to add</td>
                      <td className="py-3 px-4 text-right font-bold text-emerald-700">+₹{fundAmount}</td>
                    </tr>
                    <tr className="bg-cyan-50/90">
                      <td className="py-3.5 px-4 font-bold text-[#2C1A12]">New projected balance</td>
                      <td className="py-3.5 px-4 text-right font-extrabold text-base text-sky-800">
                        ₹{parentLinkedStudent.walletBalance + Number(fundAmount)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <button
                onClick={handleConfirmParentFunding}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-sky-600 to-cyan-600 hover:from-sky-700 hover:to-cyan-700 text-white font-extrabold text-sm shadow-xl shadow-sky-500/25"
              >
                Confirm Simulated Payment (₹{fundAmount})
              </button>
            </div>
          )}

          {/* ----------------------------------------------------------------
              PARENT SCREEN 7: PARENT PAYMENT PROCESSING (5-SECOND SEQUENCE)
          ---------------------------------------------------------------- */}
          {parentScreen === 'funding_processing' && (
            <div className="max-w-lg mx-auto my-10 bg-white shadow-sm/95 border border-cyan-300/80 rounded-3xl p-8 text-center shadow-2xl space-y-6">
              <span className="inline-block text-[10px] font-mono uppercase tracking-widest px-3 py-1 rounded-full bg-emerald-500/15 text-sky-800">
                Simulated Parent Funding Sequence — No Real Money Collected
              </span>
              <div className="w-20 h-20 rounded-full border-4 border-cyan-300/80 border-t-emerald-400 animate-spin mx-auto flex items-center justify-center">
                <ShieldCheck className="w-8 h-8 text-sky-800" />
              </div>
              <h2 className="text-xl font-extrabold text-[#2C1A12]">
                {parentPayStep === 1 && '0–1s: Initiating Simulated Funding...'}
                {parentPayStep === 2 && `1–3s: Verifying ${fundingMethod} & Authorizing...`}
                {parentPayStep === 3 && '3–5s: Crediting Student Wallet & Generating Ledger Entry...'}
              </h2>
              <div className="text-left bg-[#F4EFEA] p-4 rounded-2xl border border-stone-200/80 space-y-2 text-xs">
                <p className={parentPayStep >= 1 ? 'text-sky-800 font-semibold' : 'text-slate-500'}>
                  ✓ 0–1s: Initiating ₹{fundAmount} top-up request
                </p>
                <p className={parentPayStep >= 2 ? 'text-sky-800 font-semibold' : 'text-slate-500'}>
                  ✓ 1–3s: Simulated {fundingMethod} authorization verified
                </p>
                <p className={parentPayStep >= 3 ? 'text-sky-800 font-semibold' : 'text-slate-500'}>
                  ✓ 3–5s: Updating {parentLinkedStudent.name}'s wallet in shared ecosystem state
                </p>
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              PARENT SCREEN 8: WALLET FUNDING SUCCESS
          ---------------------------------------------------------------- */}
          {parentScreen === 'funding_success' && (() => {
            const rec = lastFundingReceipt || {
              txnId: 'TXN-CK-90012',
              studentName: parentLinkedStudent.name,
              studentId: parentLinkedStudent.id,
              amount: fundAmount,
              method: fundingMethod,
              timestamp: '2026-11-16 14:00',
              previousBalance: parentLinkedStudent.walletBalance - Number(fundAmount),
              newBalance: parentLinkedStudent.walletBalance
            };
            return (
              <div className="max-w-xl mx-auto bg-white shadow-sm/95 border border-cyan-400/80 rounded-3xl p-8 text-center shadow-2xl space-y-6">
                <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-cyan-400/80 text-emerald-700 mx-auto flex items-center justify-center">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h2 className="text-2xl font-extrabold text-[#2C1A12]">Wallet Funded Successfully!</h2>
                <p className="text-xs text-stone-600">
                  The Student Application wallet balance has been updated immediately via shared state.
                </p>

                <div className="bg-[#F4EFEA] border border-stone-200/80 rounded-2xl p-4 text-left space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-stone-500">Funding Transaction ID</span>
                    <span className="font-mono font-bold text-sky-800">{rec.txnId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Student Name</span>
                    <span className="font-bold text-[#2C1A12]">{rec.studentName} ({rec.studentId})</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Payment Method</span>
                    <span className="text-[#2C1A12]">{rec.method}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Date & Time</span>
                    <span className="text-[#2C1A12]">{rec.timestamp}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Previous Wallet Balance</span>
                    <span className="text-[#2C1A12]">₹{rec.previousBalance}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Amount Added</span>
                    <span className="font-bold text-emerald-700">+₹{rec.amount}</span>
                  </div>
                  <div className="pt-2 border-t border-stone-200/80 flex justify-between text-sm font-extrabold text-[#2C1A12]">
                    <span>New Student Wallet Balance</span>
                    <span className="text-sky-800">₹{rec.newBalance}</span>
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => setParentScreen('dashboard')}
                    className="flex-1 py-3 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs"
                  >
                    Return to Parent Dashboard
                  </button>
                  <button
                    onClick={() => {
                      setLoggedStudentId(parentLinkedStudent.id);
                      setStudentAuthed(true);
                      setStudentScreen('home');
                      setActivePortal('student');
                    }}
                    className="px-4 py-3 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs"
                  >
                    Verify in Student App →
                  </button>
                </div>
              </div>
            );
          })()}

          {/* ----------------------------------------------------------------
              PARENT SCREEN 9: TRANSACTION HISTORY
          ---------------------------------------------------------------- */}
          {parentScreen === 'transactions' && (
            <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-6 space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-extrabold text-[#2C1A12]">Parent Transaction Ledger</h2>
                  <p className="text-xs text-stone-500">Every funding credit, purchase debit, refund, and adjustment for {parentLinkedStudent.name}</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {['All', 'Money Added', 'Purchases', 'Refunds'].map(f => (
                    <button
                      key={f}
                      onClick={() => setParentTxnFilter(f)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
                        parentTxnFilter === f ? 'bg-sky-600 text-white' : 'bg-[#F5F0EB]/90 text-stone-600'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                  <select
                    value={parentDateRange}
                    onChange={(e) => setParentDateRange(e.target.value)}
                    className="bg-[#F4EFEA] border border-stone-200/90 rounded-xl px-3 py-1.5 text-xs text-[#2C1A12]"
                  >
                    <option value="All Time">Date: All Time</option>
                    <option value="Nov 2026">Date: Nov 2026</option>
                    <option value="Oct 2026">Date: Oct 2026</option>
                  </select>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-left text-stone-500 border-b border-stone-200/80">
                      <th className="py-3 px-3">Transaction ID</th>
                      <th className="py-3 px-3">Date & Time</th>
                      <th className="py-3 px-3">Type</th>
                      <th className="py-3 px-3">Description / Linked Order</th>
                      <th className="py-3 px-3">Status</th>
                      <th className="py-3 px-3 text-right">Amount</th>
                      <th className="py-3 px-3 text-right">Wallet Balance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-200/70">
                    {parentTransactions
                      .filter(t => {
                        if (parentDateRange !== 'All Time' && t.month !== parentDateRange) return false;
                        if (parentTxnFilter === 'Money Added') return t.type === 'Wallet Funding';
                        if (parentTxnFilter === 'Purchases') return t.type === 'Student Purchase';
                        if (parentTxnFilter === 'Refunds') return t.type === 'Refund' || t.type === 'Adjustment';
                        return true;
                      })
                      .map(t => (
                        <tr key={t.id} className="hover:bg-[#F5F0EB]/90">
                          <td className="py-3 px-3 font-mono text-sky-800">{t.id}</td>
                          <td className="py-3 px-3 text-stone-600">{t.timestamp}</td>
                          <td className="py-3 px-3 font-semibold text-[#2C1A12]">{t.type}</td>
                          <td className="py-3 px-3 text-stone-600">
                            {t.note}
                            {t.relatedOrderId && (
                              <button
                                onClick={() => {
                                  const ord = ecosystem.orders.find(o => o.id === t.relatedOrderId);
                                  if (ord) setReceiptModalOrder(ord);
                                }}
                                className="ml-2 text-orange-600 hover:underline font-mono"
                              >
                                [{t.relatedOrderId}]
                              </button>
                            )}
                          </td>
                          <td className="py-3 px-3">
                            <span className="px-2 py-0.5 rounded bg-emerald-500/15 text-sky-800 text-[10px]">
                              {t.status}
                            </span>
                          </td>
                          <td className={`py-3 px-3 text-right font-bold ${t.amount > 0 ? 'text-emerald-700' : 'text-orange-600'}`}>
                            {t.amount > 0 ? `+₹${t.amount}` : `-₹${Math.abs(t.amount)}`}
                          </td>
                          <td className="py-3 px-3 text-right font-mono text-[#2C1A12]">₹{t.newBalance}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              PARENT SCREEN 10: SPENDING ANALYTICS
          ---------------------------------------------------------------- */}
          {parentScreen === 'analytics' && (
            <div className="space-y-6">
              {/* 5 Summary KPIs */}
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-4">
                  <span className="text-[11px] text-stone-500">Total Expenditure</span>
                  <p className="text-xl font-black text-[#2C1A12] mt-1">₹{parentMetrics.totalSpent}</p>
                </div>
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-4">
                  <span className="text-[11px] text-stone-500">Avg Transaction</span>
                  <p className="text-xl font-black text-cyan-700 mt-1">₹{parentMetrics.avgPurchase}</p>
                </div>
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-4">
                  <span className="text-[11px] text-stone-500">Number of Purchases</span>
                  <p className="text-xl font-black text-orange-600 mt-1">{parentMetrics.purchaseCount} Orders</p>
                </div>
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-4">
                  <span className="text-[11px] text-stone-500">Highest Spend Category</span>
                  <p className="text-base font-extrabold text-orange-600 mt-1 truncate">{highestSpendCategory}</p>
                </div>
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-4">
                  <span className="text-[11px] text-stone-500">Remaining Wallet Balance</span>
                  <p className="text-xl font-black text-emerald-700 mt-1">₹{parentLinkedStudent.walletBalance}</p>
                </div>
              </div>

              <div className="grid lg:grid-cols-2 gap-6">
                {/* Pie Chart */}
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                  <h3 className="text-sm font-bold text-[#2C1A12] mb-3">1. Category Distribution (Pie Chart)</h3>
                  <div className="relative h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={parentCategoryChartData}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          outerRadius={85}
                          label={({ name, value }) => `${name}: ₹${value}`}
                        >
                          {parentCategoryChartData.map((_, i) => (
                            <Cell key={i} fill={['#10b981', '#06b6d4', '#6366f1', '#f59e0b', '#ec4899', '#8b5cf6'][i % 6]} />
                          ))}
                        </Pie>
                        <Tooltip contentStyle={{ backgroundColor: '#FFFFFF', borderColor: '#E7E0D6', color: '#2C1A12', fontSize: '12px' }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Bar Chart */}
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                  <h3 className="text-sm font-bold text-[#2C1A12] mb-3">2. Monthly Funding vs. Spending (Bar Chart)</h3>
                  <div className="relative h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={parentMonthlyChartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#E7E0D6" />
                        <XAxis dataKey="month" stroke="#6F4E37" fontSize={11} />
                        <YAxis stroke="#6F4E37" fontSize={11} />
                        <Tooltip contentStyle={{ backgroundColor: '#FFFFFF', borderColor: '#E7E0D6', color: '#2C1A12', fontSize: '12px' }} />
                        <Legend wrapperStyle={{ fontSize: '11px' }} />
                        <Bar dataKey="funded" name="Wallet Funded (₹)" fill="#10b981" radius={[6, 6, 0, 0]} />
                        <Bar dataKey="spent" name="Total Spent (₹)" fill="#6366f1" radius={[6, 6, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Line Chart */}
                <div className="lg:col-span-2 bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                  <h3 className="text-sm font-bold text-[#2C1A12] mb-3">3. Daily Spending & Top-Up Trend (Line Chart)</h3>
                  <div className="relative h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={parentDailyTrendData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#E7E0D6" />
                        <XAxis dataKey="day" stroke="#6F4E37" fontSize={11} />
                        <YAxis stroke="#6F4E37" fontSize={11} />
                        <Tooltip contentStyle={{ backgroundColor: '#FFFFFF', borderColor: '#E7E0D6', color: '#2C1A12', fontSize: '12px' }} />
                        <Legend wrapperStyle={{ fontSize: '11px' }} />
                        <Line type="monotone" dataKey="amount" name="Daily Spend (₹)" stroke="#f59e0b" strokeWidth={3} />
                        <Line type="monotone" dataKey="funded" name="Wallet Funded (₹)" stroke="#10b981" strokeWidth={3} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              PARENT SCREEN 11: SPENDING CONTROLS
          ---------------------------------------------------------------- */}
          {parentScreen === 'controls' && (
            <div className="max-w-3xl mx-auto bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-cyan-300/80 rounded-3xl p-6 sm:p-8 space-y-6">
              <div>
                <h2 className="text-xl font-extrabold text-[#2C1A12]">Guardian Spending Controls & Alerts</h2>
                <p className="text-xs text-stone-500">
                  Rules saved here are enforced immediately during {parentLinkedStudent.name}'s checkout in the Student App.
                </p>
              </div>

              <div className="space-y-4">
                {/* Daily Limit */}
                <div className="p-4 rounded-2xl bg-[#F5F0EB] border border-stone-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={parentControls.dailyLimitEnabled}
                        onChange={(e) => handleSaveSpendingControls({ ...parentControls, dailyLimitEnabled: e.target.checked })}
                        className="w-4 h-4 accent-emerald-500"
                      />
                      <span className="text-sm font-bold text-[#2C1A12]">Daily Spending Limit</span>
                    </div>
                    <p className="text-xs text-stone-500 mt-0.5">Blocks student purchases exceeding this daily cap.</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-stone-500">Max ₹ / Day:</span>
                    <input
                      type="number"
                      value={parentControls.dailyLimit}
                      onChange={(e) => handleSaveSpendingControls({ ...parentControls, dailyLimit: Math.max(50, Number(e.target.value) || 0) })}
                      className="w-28 px-3 py-1.5 rounded-xl bg-white shadow-sm border border-stone-200/90 text-[#2C1A12] text-sm font-bold"
                    />
                  </div>
                </div>

                {/* Weekly Limit */}
                <div className="p-4 rounded-2xl bg-[#F5F0EB] border border-stone-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={parentControls.weeklyLimitEnabled}
                        onChange={(e) => handleSaveSpendingControls({ ...parentControls, weeklyLimitEnabled: e.target.checked })}
                        className="w-4 h-4 accent-emerald-500"
                      />
                      <span className="text-sm font-bold text-[#2C1A12]">Weekly Spending Limit</span>
                    </div>
                    <p className="text-xs text-stone-500 mt-0.5">Caps cumulative 7-day student wallet spend.</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-stone-500">Max ₹ / Week:</span>
                    <input
                      type="number"
                      value={parentControls.weeklyLimit}
                      onChange={(e) => handleSaveSpendingControls({ ...parentControls, weeklyLimit: Math.max(100, Number(e.target.value) || 0) })}
                      className="w-28 px-3 py-1.5 rounded-xl bg-white shadow-sm border border-stone-200/90 text-[#2C1A12] text-sm font-bold"
                    />
                  </div>
                </div>

                {/* Monthly Limit */}
                <div className="p-4 rounded-2xl bg-[#F5F0EB] border border-stone-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={parentControls.monthlyLimitEnabled}
                        onChange={(e) => handleSaveSpendingControls({ ...parentControls, monthlyLimitEnabled: e.target.checked })}
                        className="w-4 h-4 accent-emerald-500"
                      />
                      <span className="text-sm font-bold text-[#2C1A12]">Monthly Allowance Limit</span>
                    </div>
                    <p className="text-xs text-stone-500 mt-0.5">Enforces monthly budget discipline.</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-stone-500">Max ₹ / Month:</span>
                    <input
                      type="number"
                      value={parentControls.monthlyLimit}
                      onChange={(e) => handleSaveSpendingControls({ ...parentControls, monthlyLimit: Math.max(200, Number(e.target.value) || 0) })}
                      className="w-28 px-3 py-1.5 rounded-xl bg-white shadow-sm border border-stone-200/90 text-[#2C1A12] text-sm font-bold"
                    />
                  </div>
                </div>

                {/* Category Restrictions */}
                <div className="p-4 rounded-2xl bg-[#F5F0EB] border border-stone-200/80 space-y-3">
                  <p className="text-sm font-bold text-[#2C1A12]">Category-Based Restrictions (Click to Block/Allow)</p>
                  <div className="flex flex-wrap gap-2">
                    {CATEGORIES.filter(c => c !== 'All').map(cat => {
                      const blocked = parentControls.restrictedCategories?.includes(cat);
                      return (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => {
                            const cur = parentControls.restrictedCategories || [];
                            const next = blocked ? cur.filter(x => x !== cat) : [...cur, cat];
                            handleSaveSpendingControls({ ...parentControls, restrictedCategories: next });
                          }}
                          className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                            blocked
                              ? 'bg-rose-500/20 border-rose-500 text-rose-700'
                              : 'bg-emerald-500/15 border-cyan-300/80 text-sky-800'
                          }`}
                        >
                          {blocked ? `✕ Blocked: ${cat}` : `✓ Allowed: ${cat}`}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Notification Toggles */}
                <div className="grid sm:grid-cols-3 gap-3 text-xs">
                  <label className="p-3.5 rounded-2xl bg-[#F5F0EB] border border-stone-200/80 flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={parentControls.lowBalanceAlertEnabled}
                      onChange={(e) => handleSaveSpendingControls({ ...parentControls, lowBalanceAlertEnabled: e.target.checked })}
                      className="accent-emerald-500"
                    />
                    <span>Low-Balance Alert (&lt;₹{parentControls.lowBalanceThreshold})</span>
                  </label>
                  <label className="p-3.5 rounded-2xl bg-[#F5F0EB] border border-stone-200/80 flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={parentControls.instantTxnNotification}
                      onChange={(e) => handleSaveSpendingControls({ ...parentControls, instantTxnNotification: e.target.checked })}
                      className="accent-emerald-500"
                    />
                    <span>Instant Purchase Alerts</span>
                  </label>
                  <label className="p-3.5 rounded-2xl bg-[#F5F0EB] border border-stone-200/80 flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={parentControls.spendingAlertsEnabled}
                      onChange={(e) => handleSaveSpendingControls({ ...parentControls, spendingAlertsEnabled: e.target.checked })}
                      className="accent-emerald-500"
                    />
                    <span>Limit Violation Alerts</span>
                  </label>
                </div>
              </div>

              <button
                onClick={() => handleSaveSpendingControls({ ...parentControls })}
                className="w-full py-3.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-sm"
              >
                Save Spending Preferences
              </button>
            </div>
          )}

          {/* ----------------------------------------------------------------
              PARENT SCREEN 12: LINKED STUDENT ORDERS
          ---------------------------------------------------------------- */}
          {parentScreen === 'orders' && (
            <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-6 space-y-5">
              <div>
                <h2 className="text-xl font-extrabold text-[#2C1A12]">Linked Student Order History ({parentLinkedStudent.name})</h2>
                <p className="text-xs text-stone-500">Inspect item-level receipts and live fulfilment statuses</p>
              </div>
              <div className="space-y-3">
                {parentOrders.map(ord => (
                  <div key={ord.id} className="p-4 rounded-2xl bg-[#F5F0EB] border border-stone-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-[#2C1A12] text-sm">{ord.id}</span>
                        <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-sky-800 font-semibold">{ord.status}</span>
                        <span className="text-stone-500">{ord.date}</span>
                      </div>
                      <p className="text-[#3D251A] mt-1">
                        {ord.items.map(i => `${i.qty}× ${i.name}`).join(', ')}
                      </p>
                      <p className="text-[11px] text-stone-500 mt-0.5">
                        Payment: {ord.paymentStatus} (Ref: {ord.txnRef}) · Point: {ord.collectionPoint}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-base font-extrabold text-[#2C1A12]">₹{ord.totalAmount}</span>
                      <button
                        onClick={() => setReceiptModalOrder(ord)}
                        className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold"
                      >
                        Inspect Receipt
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              PARENT SCREEN 13: NOTIFICATIONS
          ---------------------------------------------------------------- */}
          {parentScreen === 'notifications' && (
            <div className="max-w-3xl mx-auto bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-6 space-y-4">
              <h2 className="text-xl font-extrabold text-[#2C1A12]">Parent Real-Time Notifications</h2>
              <div className="space-y-2.5">
                {ecosystem.notifications
                  .filter(n => n.studentId === parentLinkedStudent.id)
                  .map(n => (
                    <div key={n.id} className="p-4 rounded-2xl bg-[#F5F0EB] border border-stone-200/80 text-xs flex items-start justify-between gap-3">
                      <div>
                        <p className="font-bold text-sky-800 text-sm">{n.title}</p>
                        <p className="text-stone-600 mt-1">{n.message}</p>
                      </div>
                      <span className="text-[11px] text-stone-500 shrink-0">{n.time}</span>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              PARENT SCREEN 14: MONTHLY STATEMENTS & RECEIPTS
          ---------------------------------------------------------------- */}
          {parentScreen === 'statements' && (
            <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-6 space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-200/80 pb-4">
                <div>
                  <h2 className="text-xl font-extrabold text-[#2C1A12]">Monthly Wallet Statements & Reconciled Summary</h2>
                  <p className="text-xs text-stone-500">Account: {parentLinkedStudent.name} ({parentLinkedStudent.id}) — November 2026</p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => showToast('Statement Downloaded', `CampusKart_Statement_${parentLinkedStudent.id}_Nov2026.pdf downloaded.`, 'success')}
                    className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold flex items-center gap-1.5"
                  >
                    <Download className="w-4 h-4" /> Download PDF Statement
                  </button>
                  <button
                    onClick={() => showToast('Print Job Prepared', 'Formatted monthly statement ready for printing.', 'info')}
                    className="px-4 py-2 rounded-xl bg-stone-200/65 hover:bg-stone-200/80 text-[#2C1A12] text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Printer className="w-4 h-4" /> Print Statement
                  </button>
                </div>
              </div>

              <div className="grid sm:grid-cols-4 gap-4 text-xs">
                <div className="p-4 rounded-2xl bg-[#F4EFEA] border border-stone-200/80">
                  <span className="text-stone-500">Total Credits (Funding)</span>
                  <p className="text-lg font-extrabold text-emerald-700 mt-1">+₹{parentMetrics.totalAdded}</p>
                </div>
                <div className="p-4 rounded-2xl bg-[#F4EFEA] border border-stone-200/80">
                  <span className="text-stone-500">Total Debits (Purchases)</span>
                  <p className="text-lg font-extrabold text-orange-600 mt-1">-₹{parentMetrics.totalSpent}</p>
                </div>
                <div className="p-4 rounded-2xl bg-[#F4EFEA] border border-stone-200/80">
                  <span className="text-stone-500">Refunds & Adjustments</span>
                  <p className="text-lg font-extrabold text-cyan-700 mt-1">+₹{parentMetrics.totalRefunds}</p>
                </div>
                <div className="p-4 rounded-2xl bg-[#F4EFEA] border border-stone-200/80">
                  <span className="text-stone-500">Closing Reconciled Balance</span>
                  <p className="text-lg font-extrabold text-[#2C1A12] mt-1">₹{parentLinkedStudent.walletBalance}</p>
                </div>
              </div>

              <div className="bg-[#F4EFEA] border border-stone-200/80 rounded-2xl p-4">
                <h3 className="text-xs font-mono uppercase tracking-wider text-stone-500 mb-3">Category-Wise Statement Breakdown</h3>
                <div className="grid sm:grid-cols-3 gap-3 text-xs">
                  {parentCategoryChartData.map(c => (
                    <div key={c.name} className="p-3 rounded-xl bg-[#F5F0EB]/90 flex justify-between">
                      <span className="text-stone-600">{c.name}</span>
                      <span className="font-bold text-[#2C1A12]">₹{c.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </main>
      )}

      {/* ====================================================================
          PORTAL 3: OPERATIONS DASHBOARD (5 SCREENS — INTERNAL PLATFORM)
      ==================================================================== */}
      {activePortal === 'ops' && (
        <main className="relative z-10 max-w-7xl mx-auto px-3 sm:px-6 py-6">
          {/* Operations Navigation */}
          <div className="mb-6 bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-orange-300/80 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[11px] font-mono uppercase tracking-wider px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-800 border border-orange-300/80">
                Operations Control Center
              </span>
              {[
                { id: 'overview', label: '1. Operations Overview' },
                { id: 'orders', label: `2. Order Management (${ecosystem.orders.length})` },
                { id: 'inventory', label: `3. Inventory Management (${ecosystem.products.length})` },
                { id: 'students', label: `4. Student Management (${ecosystem.students.length})` },
                { id: 'reconciliation', label: '5. Wallet & Ledger Reconciliation' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setOpsScreen(tab.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    opsScreen === tab.id
                      ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                      : 'text-stone-600 hover:bg-stone-200/65'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* ----------------------------------------------------------------
              OPS SCREEN 1: OPERATIONS OVERVIEW
          ---------------------------------------------------------------- */}
          {opsScreen === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-4">
                  <span className="text-xs text-stone-500">Total Registered Students</span>
                  <p className="text-2xl font-black text-[#2C1A12] mt-1">{ecosystem.students.length}</p>
                  <span className="text-[11px] text-emerald-700">
                    {ecosystem.students.filter(s => s.status === 'Active').length} Active Accounts
                  </span>
                </div>
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-4">
                  <span className="text-xs text-stone-500">Total Orders</span>
                  <p className="text-2xl font-black text-orange-600 mt-1">{ecosystem.orders.length}</p>
                  <span className="text-[11px] text-stone-500">
                    {ecosystem.orders.filter(o => o.status !== 'Completed' && o.status !== 'Cancelled').length} Pending / Active
                  </span>
                </div>
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-4">
                  <span className="text-xs text-stone-500">Completed vs. Cancelled</span>
                  <p className="text-2xl font-black text-emerald-700 mt-1">
                    {ecosystem.orders.filter(o => o.status === 'Completed').length} / {ecosystem.orders.filter(o => o.status === 'Cancelled').length}
                  </p>
                  <span className="text-[11px] text-stone-500">Fulfilment completion</span>
                </div>
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-4">
                  <span className="text-xs text-stone-500">Total Demo Transaction Value</span>
                  <p className="text-2xl font-black text-orange-600 mt-1">
                    ₹{ecosystem.transactions.reduce((acc, t) => acc + Math.abs(t.amount), 0).toLocaleString('en-IN')}
                  </p>
                  <span className="text-[11px] text-emerald-700">100% Ledger Reconciled</span>
                </div>
              </div>

              {/* Inventory Status & Pending Fulfilment Queue */}
              <div className="grid lg:grid-cols-2 gap-6">
                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-bold text-[#2C1A12]">Live Incoming Orders Queue</h3>
                    <button onClick={() => setOpsScreen('orders')} className="text-xs text-orange-600 hover:underline">
                      Manage All Orders →
                    </button>
                  </div>
                  <div className="space-y-2.5">
                    {ecosystem.orders.slice(0, 4).map(ord => (
                      <div key={ord.id} className="p-3 rounded-xl bg-[#F4EFEA] border border-stone-200/80 flex items-center justify-between text-xs">
                        <div>
                          <p className="font-bold text-[#2C1A12]">{ord.id} — {ord.studentName} ({ord.studentId})</p>
                          <p className="text-stone-500">{ord.items.length} items · ₹{ord.totalAmount} · {ord.fulfilmentMethod}</p>
                        </div>
                        <span className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-800 font-semibold">
                          {ord.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-bold text-[#2C1A12]">Inventory Low-Stock Alerts</h3>
                    <button onClick={() => setOpsScreen('inventory')} className="text-xs text-orange-600 hover:underline">
                      Manage Catalogue →
                    </button>
                  </div>
                  <div className="space-y-2.5">
                    {ecosystem.products.filter(p => p.stock <= 15).map(p => (
                      <div key={p.id} className="p-3 rounded-xl bg-[#F4EFEA] border border-stone-200/80 flex items-center justify-between text-xs">
                        <div>
                          <p className="font-bold text-[#2C1A12]">{p.name} ({p.id})</p>
                          <p className="text-stone-500">{p.category} · ₹{p.price}</p>
                        </div>
                        <span className={`px-2.5 py-1 rounded-lg font-bold ${
                          p.stock === 0 ? 'bg-rose-500/20 text-rose-700' : 'bg-amber-500/20 text-amber-800'
                        }`}>
                          {p.stock === 0 ? 'Out of Stock (0)' : `Low Stock (${p.stock})`}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              OPS SCREEN 2: ORDER MANAGEMENT (LIVE STATUS PROPAGATION)
          ---------------------------------------------------------------- */}
          {opsScreen === 'orders' && (
            <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-6 space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-extrabold text-[#2C1A12]">Real-Time Order Fulfilment Queue</h2>
                  <p className="text-xs text-stone-500">
                    Updating any order status immediately propagates to Student Order Tracking & Parent Linked Orders
                  </p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {['All', 'Order Placed', 'Accepted', 'Preparing', 'Ready for Collection', 'Completed'].map(f => (
                    <button
                      key={f}
                      onClick={() => setOpsOrderFilter(f)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
                        opsOrderFilter === f ? 'bg-amber-500 text-slate-950' : 'bg-[#F5F0EB]/90 text-stone-600'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                {ecosystem.orders
                  .filter(o => opsOrderFilter === 'All' || o.status === opsOrderFilter)
                  .map(ord => (
                    <div key={ord.id} className="p-4 rounded-2xl bg-[#F4EFEA] border border-stone-200/80 space-y-3 text-xs">
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-200/60 pb-2.5">
                        <div className="flex items-center gap-2.5">
                          <span className="font-mono font-bold text-[#2C1A12] text-sm">{ord.id}</span>
                          <span className="text-orange-700 font-semibold">{ord.studentName} ({ord.studentId})</span>
                          <span className="text-stone-500">{ord.date}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-emerald-700">₹{ord.totalAmount} ({ord.paymentStatus})</span>
                          <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-800 font-bold">
                            {ord.status}
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                        <div>
                          <p className="text-[#3D251A] font-medium">
                            Items: {ord.items.map(i => `${i.qty}× ${i.name}`).join(' | ')}
                          </p>
                          <p className="text-stone-500 mt-0.5">
                            Fulfilment: {ord.fulfilmentMethod} — {ord.collectionPoint}
                          </p>
                        </div>

                        {/* One-Click Fulfilment Workflow Buttons */}
                        <div className="flex flex-wrap items-center gap-1.5">
                          {['Order Placed', 'Accepted', 'Preparing', 'Ready for Collection', 'Completed'].map(st => (
                            <button
                              key={st}
                              onClick={() => handleOpsUpdateOrderStatus(ord.id, st)}
                              className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold transition-all ${
                                ord.status === st
                                  ? 'bg-amber-500 text-slate-950 font-bold'
                                  : 'bg-[#F5F0EB]/90 hover:bg-stone-200/80 text-stone-600'
                              }`}
                            >
                              {st}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              OPS SCREEN 3: INVENTORY MANAGEMENT
          ---------------------------------------------------------------- */}
          {opsScreen === 'inventory' && (
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Create New Product Form */}
              <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-5 h-fit space-y-4">
                <h3 className="text-base font-bold text-[#2C1A12]">Add New Campus Product</h3>
                <form onSubmit={handleOpsCreateProduct} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-stone-500 mb-1">Product Name</label>
                    <input
                      type="text"
                      value={newProductForm.name}
                      onChange={(e) => setNewProductForm({ ...newProductForm, name: e.target.value })}
                      placeholder="e.g. Millet Protein Sandwich"
                      className="w-full px-3 py-2 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12]"
                    />
                  </div>
                  <div>
                    <label className="block text-stone-500 mb-1">Category</label>
                    <select
                      value={newProductForm.category}
                      onChange={(e) => setNewProductForm({ ...newProductForm, category: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12]"
                    >
                      {CATEGORIES.filter(c => c !== 'All').map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-500 mb-1">Price (₹)</label>
                      <input
                        type="number"
                        value={newProductForm.price}
                        onChange={(e) => setNewProductForm({ ...newProductForm, price: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12]"
                      />
                    </div>
                    <div>
                      <label className="block text-stone-500 mb-1">Initial Stock</label>
                      <input
                        type="number"
                        value={newProductForm.stock}
                        onChange={(e) => setNewProductForm({ ...newProductForm, stock: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12]"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-stone-500 mb-1">Short Description</label>
                    <textarea
                      rows={2}
                      value={newProductForm.description}
                      onChange={(e) => setNewProductForm({ ...newProductForm, description: e.target.value })}
                      placeholder="Approved campus specification..."
                      className="w-full px-3 py-2 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12]"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                  >
                    + Publish to Student Catalogue
                  </button>
                </form>
              </div>

              {/* Inventory Table */}
              <div className="lg:col-span-2 bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-5 space-y-4">
                <h3 className="text-base font-bold text-[#2C1A12]">Live Campus Inventory & Stock Controls</h3>
                <div className="space-y-2.5">
                  {ecosystem.products.map(p => (
                    <div key={p.id} className="p-3.5 rounded-2xl bg-[#F4EFEA] border border-stone-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-orange-600 font-bold">{p.id}</span>
                          <span className="font-bold text-[#2C1A12]">{p.name}</span>
                          {!p.active && <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-700">Deactivated</span>}
                        </div>
                        <p className="text-stone-500 mt-0.5">{p.category} · Price: ₹{p.price}</p>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleOpsUpdateStock(p.id, Math.max(0, p.stock - 5), undefined, undefined)}
                          className="px-2.5 py-1 rounded-lg bg-[#F5F0EB]/90 hover:bg-stone-200/65 text-stone-600"
                        >
                          -5
                        </button>
                        <span className={`px-3 py-1 rounded-lg font-mono font-bold ${
                          p.stock === 0 ? 'bg-rose-500/20 text-rose-700' : 'bg-emerald-500/15 text-sky-800'
                        }`}>
                          Stock: {p.stock}
                        </span>
                        <button
                          onClick={() => handleOpsUpdateStock(p.id, p.stock + 10, undefined, undefined)}
                          className="px-2.5 py-1 rounded-lg bg-[#F5F0EB]/90 hover:bg-stone-200/65 text-stone-600"
                        >
                          +10
                        </button>
                        <button
                          onClick={() => handleOpsUpdateStock(p.id, 0, undefined, undefined)}
                          className="px-2.5 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-700"
                          title="Set Out of Stock to test student blocker"
                        >
                          Set 0
                        </button>
                        <button
                          onClick={() => handleOpsUpdateStock(p.id, undefined, undefined, !p.active)}
                          className={`px-2.5 py-1 rounded-lg font-semibold ${
                            p.active ? 'bg-stone-200/65 text-[#3D251A]' : 'bg-sky-600 text-white'
                          }`}
                        >
                          {p.active ? 'Hide' : 'Activate'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              OPS SCREEN 4: STUDENT MANAGEMENT
          ---------------------------------------------------------------- */}
          {opsScreen === 'students' && (
            <div className="grid lg:grid-cols-3 gap-6">
              <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-5 h-fit space-y-4">
                <h3 className="text-base font-bold text-[#2C1A12]">Enroll New Pilot Student</h3>
                <form onSubmit={handleOpsCreateStudent} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-stone-500 mb-1">Student Full Name</label>
                    <input
                      type="text"
                      value={newStudentForm.name}
                      onChange={(e) => setNewStudentForm({ ...newStudentForm, name: e.target.value })}
                      placeholder="e.g. Ananya Rao"
                      className="w-full px-3 py-2 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12]"
                    />
                  </div>
                  <div>
                    <label className="block text-stone-500 mb-1">Academic Year</label>
                    <select
                      value={newStudentForm.academicYear}
                      onChange={(e) => setNewStudentForm({ ...newStudentForm, academicYear: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12]"
                    >
                      <option value="Intermediate First Year (MPC)">Intermediate First Year (MPC)</option>
                      <option value="Intermediate First Year (BiPC)">Intermediate First Year (BiPC)</option>
                      <option value="Intermediate Second Year (MPC)">Intermediate Second Year (MPC)</option>
                      <option value="Intermediate Second Year (BiPC)">Intermediate Second Year (BiPC)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-stone-500 mb-1">Linked Parent / Guardian Name</label>
                    <input
                      type="text"
                      value={newStudentForm.parentName}
                      onChange={(e) => setNewStudentForm({ ...newStudentForm, parentName: e.target.value })}
                      placeholder="e.g. Suresh Rao"
                      className="w-full px-3 py-2 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12]"
                    />
                  </div>
                  <div>
                    <label className="block text-stone-500 mb-1">Initial Onboarding Wallet Credit (₹)</label>
                    <input
                      type="number"
                      value={newStudentForm.initialWallet}
                      onChange={(e) => setNewStudentForm({ ...newStudentForm, initialWallet: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12]"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                  >
                    + Register Student Account
                  </button>
                </form>
              </div>

              <div className="lg:col-span-2 bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-5 space-y-4">
                <h3 className="text-base font-bold text-[#2C1A12]">Registered Student Directory (Access-Controlled)</h3>
                <div className="space-y-3">
                  {ecosystem.students.map(s => (
                    <div key={s.id} className="p-4 rounded-2xl bg-[#F4EFEA] border border-stone-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-orange-600">{s.id}</span>
                          <span className="font-bold text-[#2C1A12] text-sm">{s.name}</span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            s.status === 'Active' ? 'bg-emerald-500/20 text-sky-800' : 'bg-rose-500/20 text-rose-700'
                          }`}>
                            {s.status}
                          </span>
                        </div>
                        <p className="text-stone-500 mt-1">{s.institution} · {s.academicYear}</p>
                        <p className="text-stone-500">Linked Parent: <strong className="text-[#3D251A]">{s.parentName} ({s.parentId})</strong> · PIN: Masked (****)</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <span className="text-stone-500 block">Wallet Balance</span>
                          <span className="text-base font-extrabold text-[#2C1A12]">₹{s.walletBalance}</span>
                        </div>
                        <button
                          onClick={() => handleOpsToggleStudentStatus(s.id)}
                          className={`px-3 py-2 rounded-xl font-bold ${
                            s.status === 'Active'
                              ? 'bg-rose-500/20 text-rose-700 hover:bg-rose-500/30'
                              : 'bg-sky-600 text-white hover:bg-emerald-500'
                          }`}
                        >
                          {s.status === 'Active' ? 'Deactivate' : 'Activate'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ----------------------------------------------------------------
              OPS SCREEN 5: WALLET & TRANSACTION RECONCILIATION
          ---------------------------------------------------------------- */}
          {opsScreen === 'reconciliation' && (
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Audited Manual Adjustment Form */}
              <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-orange-300/80 rounded-3xl p-5 h-fit space-y-4">
                <div>
                  <span className="text-[10px] font-mono uppercase text-orange-600">Strict Audit Trail Required</span>
                  <h3 className="text-base font-bold text-[#2C1A12] mt-0.5">Record Audited Wallet Adjustment</h3>
                  <p className="text-xs text-stone-500 mt-0.5">
                    Operators cannot silently alter balances. Every manual credit/refund requires a reason, timestamp, and operator ID.
                  </p>
                </div>

                <form onSubmit={handleOpsManualAdjustment} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-stone-500 mb-1">Target Student Account</label>
                    <select
                      value={manualAdjForm.studentId}
                      onChange={(e) => setManualAdjForm({ ...manualAdjForm, studentId: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12]"
                    >
                      {ecosystem.students.map(s => (
                        <option key={s.id} value={s.id}>{s.name} ({s.id}) — Bal: ₹{s.walletBalance}</option>
                      ))}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-stone-500 mb-1">Entry Type</label>
                      <select
                        value={manualAdjForm.type}
                        onChange={(e) => setManualAdjForm({ ...manualAdjForm, type: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12]"
                      >
                        <option value="Refund">Refund (+)</option>
                        <option value="Adjustment">Adjustment (+/-)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-stone-500 mb-1">Amount (₹)</label>
                      <input
                        type="number"
                        value={manualAdjForm.amount}
                        onChange={(e) => setManualAdjForm({ ...manualAdjForm, amount: e.target.value })}
                        className="w-full px-3 py-2 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12]"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-stone-500 mb-1">Authorized Operator Identity</label>
                    <input
                      type="text"
                      value={manualAdjForm.operator}
                      onChange={(e) => setManualAdjForm({ ...manualAdjForm, operator: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12] font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-stone-500 mb-1">Mandatory Audit Reason</label>
                    <input
                      type="text"
                      value={manualAdjForm.reason}
                      onChange={(e) => setManualAdjForm({ ...manualAdjForm, reason: e.target.value })}
                      placeholder="e.g. Damaged item replacement refund"
                      className="w-full px-3 py-2 rounded-xl bg-[#F4EFEA] border border-stone-200/90 text-[#2C1A12]"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                  >
                    Commit Audited Ledger Entry
                  </button>
                </form>
              </div>

              {/* Master Reconciliation Ledger */}
              <div className="lg:col-span-2 bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-[#2C1A12]">Master Wallet & Transaction Reconciliation</h3>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-sky-800 text-xs font-bold">
                    ✓ All Student Balances Reconcile with Ledger
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-left text-stone-500 border-b border-stone-200/80">
                        <th className="py-2.5 px-2">Ref ID</th>
                        <th className="py-2.5 px-2">Student</th>
                        <th className="py-2.5 px-2">Type</th>
                        <th className="py-2.5 px-2">Audit Note / Method</th>
                        <th className="py-2.5 px-2 text-right">Prev → New</th>
                        <th className="py-2.5 px-2 text-right">Delta</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-200/70">
                      {ecosystem.transactions.map(t => (
                        <tr key={t.id} className="hover:bg-[#F5F0EB]/90">
                          <td className="py-2.5 px-2 font-mono text-amber-800">{t.id}</td>
                          <td className="py-2.5 px-2 font-mono text-[#2C1A12]">{t.studentId}</td>
                          <td className="py-2.5 px-2 text-stone-600">{t.type}</td>
                          <td className="py-2.5 px-2 text-stone-500">
                            {t.note} <span className="text-slate-500">({t.method})</span>
                          </td>
                          <td className="py-2.5 px-2 text-right font-mono text-stone-600">
                            ₹{t.previousBalance} → ₹{t.newBalance}
                          </td>
                          <td className={`py-2.5 px-2 text-right font-bold ${t.amount > 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                            {t.amount > 0 ? `+₹${t.amount}` : `-₹${Math.abs(t.amount)}`}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </main>
      )}

      {/* ====================================================================
          PORTAL 4: OPTIONAL COLLEGE ADMINISTRATION DASHBOARD (AGGREGATED ONLY)
      ==================================================================== */}
      {activePortal === 'college' && (
        <main className="relative z-10 max-w-7xl mx-auto px-3 sm:px-6 py-6 space-y-6">
          <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-[#8B5A3C]/40 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Building2 className="w-6 h-6 text-[#6F4E37]" />
              <div>
                <h2 className="text-base font-bold text-[#2C1A12]">{ecosystem.college.name} — Institutional Reporting Portal</h2>
                <p className="text-xs text-stone-500">
                  Privacy-Preserving View: Displays aggregated campus metrics only. Zero administrative burden on college staff.
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setCollegeScreen('overview')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold ${
                  collegeScreen === 'overview' ? 'bg-[#4A2E1B] text-white' : 'bg-[#F5F0EB]/90 text-stone-600'
                }`}
              >
                1. Aggregated Overview
              </button>
              <button
                onClick={() => setCollegeScreen('reports')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold ${
                  collegeScreen === 'reports' ? 'bg-[#4A2E1B] text-white' : 'bg-[#F5F0EB]/90 text-stone-600'
                }`}
              >
                2. Consolidated Invoices & Reports
              </button>
            </div>
          </div>

          {collegeScreen === 'overview' && (() => {
            const totalOrderVal = ecosystem.orders.reduce((acc, o) => acc + o.totalAmount, 0);
            const totalFundedVal = ecosystem.transactions
              .filter(t => t.type === 'Wallet Funding')
              .reduce((acc, t) => acc + t.amount, 0);

            const aggCatMap = {};
            ecosystem.orders.forEach(o => {
              o.items.forEach(it => {
                aggCatMap[it.category] = (aggCatMap[it.category] || 0) + it.subtotal;
              });
            });
            const aggCatData = Object.entries(aggCatMap).map(([name, value]) => ({ name, value }));

            return (
              <div className="space-y-6">
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                    <span className="text-xs text-stone-500">Participating Pilot Students</span>
                    <p className="text-3xl font-black text-[#2C1A12] mt-1">{ecosystem.students.length}</p>
                    <span className="text-[11px] text-emerald-700">
                      {ecosystem.students.filter(s => s.status === 'Active').length} Active Pilot Participants
                    </span>
                  </div>
                  <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                    <span className="text-xs text-stone-500">Total Campus Orders Processed</span>
                    <p className="text-3xl font-black text-[#6F4E37] mt-1">{ecosystem.orders.length}</p>
                    <span className="text-[11px] text-stone-500">100% digital kiosk/web fulfilment</span>
                  </div>
                  <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                    <span className="text-xs text-stone-500">Aggregate Order Volume</span>
                    <p className="text-3xl font-black text-emerald-700 mt-1">₹{totalOrderVal.toLocaleString('en-IN')}</p>
                    <span className="text-[11px] text-stone-500">Reconciled across all categories</span>
                  </div>
                  <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                    <span className="text-xs text-stone-500">Aggregate Parent Wallet Inflow</span>
                    <p className="text-3xl font-black text-orange-600 mt-1">₹{totalFundedVal.toLocaleString('en-IN')}</p>
                    <span className="text-[11px] text-stone-500">Zero cash handled by college</span>
                  </div>
                </div>

                <div className="grid lg:grid-cols-2 gap-6">
                  <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5">
                    <h3 className="text-sm font-bold text-[#2C1A12] mb-3">Aggregate Product Category Distribution</h3>
                    <div className="relative h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={aggCatData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#E7E0D6" />
                          <XAxis dataKey="name" stroke="#6F4E37" fontSize={10} />
                          <YAxis stroke="#6F4E37" fontSize={11} />
                          <Tooltip contentStyle={{ backgroundColor: '#FFFFFF', borderColor: '#E7E0D6', color: '#2C1A12', fontSize: '12px' }} />
                          <Bar dataKey="value" name="Aggregate Spend (₹)" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/80 rounded-2xl p-5 flex flex-col justify-between">
                    <div className="space-y-3">
                      <span className="px-2.5 py-1 rounded-full bg-emerald-500/15 text-sky-800 text-xs font-semibold">
                        Institutional Privacy Compliance Active
                      </span>
                      <h3 className="text-lg font-bold text-[#2C1A12]">Zero Administrative Overhead & Student Privacy</h3>
                      <p className="text-xs text-stone-600 leading-relaxed">
                        In accordance with CampusKart’s institutional governance model, individual student purchases, personal wallet balances, and parent financial credentials are strictly isolated from college administration screens.
                      </p>
                      <div className="space-y-2 pt-2 text-xs text-stone-600">
                        <p>✓ <strong>Kiosk Turnaround Efficiency:</strong> 98.4% orders fulfilled within break window</p>
                        <p>✓ <strong>Collection Points Active:</strong> {ecosystem.college.collectionPoints.length} Campus Zones</p>
                        <p>✓ <strong>Reconciliation Status:</strong> 100% Automated Ledger Match</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setCollegeScreen('reports')}
                      className="w-full py-3 rounded-xl bg-[#4A2E1B] hover:bg-[#2C1A12] text-white font-bold text-xs mt-4"
                    >
                      View Monthly Consolidated Invoices & Reports →
                    </button>
                  </div>
                </div>
              </div>
            );
          })()}

          {collegeScreen === 'reports' && (
            <div className="bg-white/90 backdrop-blur-xl shadow-[0_10px_30px_-6px_rgba(44,26,18,0.07)] border border-stone-200/90 rounded-3xl p-6 space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-extrabold text-[#2C1A12]">Consolidated Institutional Reports & Invoices</h2>
                  <p className="text-xs text-stone-500">Aggregated monthly summaries reconciled directly with the shared transaction ledger</p>
                </div>
                <button
                  onClick={() => showToast('Consolidated Report Exported', 'Downloaded SCNA_Consolidated_Pilot_Report_Nov2026.pdf', 'success')}
                  className="px-4 py-2.5 rounded-xl bg-[#4A2E1B] hover:bg-[#2C1A12] text-white text-xs font-bold flex items-center gap-1.5"
                >
                  <Download className="w-4 h-4" /> Export Consolidated Monthly Invoice
                </button>
              </div>

              <div className="grid sm:grid-cols-3 gap-4 text-xs">
                {[
                  {
                    id: 'INV-SCNA-2026-11',
                    title: 'November 2026 Consolidated Pilot Statement',
                    orders: ecosystem.orders.length,
                    volume: ecosystem.orders.reduce((a, b) => a + b.totalAmount, 0),
                    status: 'Live Reconciled'
                  },
                  {
                    id: 'RPT-USAGE-2026-11',
                    title: 'Aggregated Category & Kiosk Utilization Report',
                    orders: ecosystem.orders.length,
                    volume: ecosystem.transactions.filter(t => t.type === 'Wallet Funding').reduce((a, b) => a + b.amount, 0),
                    status: 'Verified'
                  },
                  {
                    id: 'RPT-SLA-2026-11',
                    title: 'Operational SLA & Break-Window Performance Audit',
                    orders: ecosystem.products.length,
                    volume: ecosystem.products.reduce((a, b) => a + b.stock, 0),
                    status: '99.1% SLA Met'
                  }
                ].map(rep => (
                  <div key={rep.id} className="p-4 rounded-2xl bg-[#F4EFEA] border border-stone-200/80 space-y-2">
                    <span className="font-mono text-[#6F4E37] font-bold">{rep.id}</span>
                    <h3 className="text-sm font-bold text-[#2C1A12]">{rep.title}</h3>
                    <p className="text-stone-500">Reconciled Records: {rep.orders} · Metric Total: ₹{rep.volume}</p>
                    <div className="pt-2 flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-sky-800 text-[10px] font-bold">{rep.status}</span>
                      <button
                        onClick={() => showToast('Report Downloaded', `${rep.id}.pdf saved.`, 'success')}
                        className="text-[#4A2E1B] hover:underline font-semibold"
                      >
                        Download PDF →
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      )}
    </div>
  );
}